import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"

/** What the platform account of ElevenLabs holds: the API key, from the instance's custody env `NIVO_MEDIA_ELEVENLABS_API_KEY` (never typed in a workspace). */
export const ElevenLabsFields = z.strictObject({
    /** The public name of the account (the identity): the instance writes "platform". */
    account: z.string().min(1),
    apiKey: z.string().min(1),
})

export type ElevenLabsAccount = z.infer<typeof ElevenLabsFields>

/** `elevenlabs`: text to speech for `voice.speak` on the models that speak Vietnamese. A platform account: NIVO's key, metered in NIVO credit. The key travels in the header `xi-api-key`. See README.md. */
export class ElevenLabsProvider implements Provider<typeof ElevenLabsFields, z.ZodObject<{}>, {}> {
    readonly key = "elevenlabs"
    readonly version = 1
    readonly title = { vi: "ElevenLabs", en: "ElevenLabs" }
    readonly description = {
        vi: "Đọc văn bản thành giọng nói tự nhiên, có tiếng Việt (mô hình v3).",
        en: "Reads text aloud in natural voices, with Vietnamese (v3 model).",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = ElevenLabsFields
    readonly secrets = ["apiKey"] as const
    readonly form = {
        account: { label: { vi: "Tên tài khoản", en: "Account name" }, help: { vi: "Tên hiển thị của tài khoản nền tảng.", en: "The display name of the platform account." }, kind: "text", order: 0 },
        apiKey: { label: { vi: "Khoá API", en: "API key" }, help: { vi: "Do nền tảng giữ; không nhập trong không gian làm việc.", en: "Held by the platform; never entered in a workspace." }, kind: "secret", order: 1 },
    } as const
    readonly identityField = "account"
    readonly kind = "base"
    readonly accountOwner = "platform"
    readonly base = { fixed: "https://api.elevenlabs.io" }
    readonly auth = { scheme: "header", name: "xi-api-key", secretField: "apiKey" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly dataTypes = {}
}
