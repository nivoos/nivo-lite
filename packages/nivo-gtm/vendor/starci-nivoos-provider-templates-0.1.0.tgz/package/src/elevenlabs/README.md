# elevenlabs

ElevenLabs text to speech for `voice.speak` (spec A section 0, 1.6 and P4, lane gm-p-voice). Pages read 2026-11-18: https://elevenlabs.io/docs/api-reference/text-to-speech/convert and https://elevenlabs.io/docs/api-reference/voices/search. Models and price come from spec A (https://elevenlabs.io/docs/overview/models, https://elevenlabs.io/pricing/api), not re-read. Anything not on a cited page is marked UNVERIFIED.

## What it is
- Provider `elevenlabs`, `accountOwner: "platform"`, base `https://api.elevenlabs.io`. Account field `apiKey` (secret), from the instance custody variable for the ElevenLabs key. A workspace never sees it. No real key was entered.
- `elevenlabs.tts.speak` implements `voice.speak`. `elevenlabs.voices.list` is a read. Logo: neutral monogram.
- Not built: `elevenlabs.voices.clone` (owner decision O3: stock voices only).

## Auth
Header `xi-api-key`: shown in the code examples of the page, not in its parameter reference. Declared as `auth: header, name xi-api-key`.

## Speak
- `POST /v1/text-to-speech/{voice_id}`, query `output_format` (default `mp3_44100_128`), JSON body `{ text, model_id, language_code, voice_settings }`. Response 200: the audio file; the page states no content type.
- `model_id`: only `eleven_v3` (up to 5000 characters) is sent. `eleven_multilingual_v2` has no Vietnamese and the page says `language_code` is not supported for it. `eleven_flash_v2_5` (40 000 characters, spec A) is not needed while the capability caps the text at 5000.
- `language_code: "vi"` by default (`en` when asked).
- `wav` maps to `output_format=wav_44100`: UNVERIFIED (the page names WAV only as a Pro-tier format).
- `speed` -3..3 maps to `voice_settings.speed` 0.7..1.3 (`1 + 0.1 x speed`): UNVERIFIED (the page gives the default 1 and no range).
- The voice id must be one from `elevenlabs.voices.list`; it goes in the path unescaped (UNVERIFIED: the engine path checks).
- Job: `job.sync`, 120 s, `outputs: { path: "", as: "binary" }` (the whole body is the file). `usage`: the operation answers `{ characters }` = length of `text`; the engine bills it.

## Errors
- 422: `{ detail: [{ loc, msg, type }] }` (page) -> `statusRefusals 422 = input_invalid`.
- UNVERIFIED (not on the page, the known shape of the vendor): `{ detail: { status, message } }`. `errorField = detail.status`; `quota_exceeded` -> `quota_exceeded`, `content_against_policy` -> `content_refused`. 401 and 429 fall to the engine table; rate limits are UNVERIFIED so no `transientCodes` are declared. TODO with a real key.

## Voices list
`GET /v2/voices?page_size=100[&search=]` -> `{ voices: [{ voice_id, name, category, preview_url, labels, ... }], has_more, total_count, next_page_token }`. The walk is `wire.paging` (cursor `next_page_token`, 100 a page, 5 pages at most), the operation maps one page.

## Price
Unit `characters`. $0.08 per 1000 characters on v3, $0.04 on flash (spec A): `usdPerUnit` 0.00008 per character.

## Recorded exchanges
No real key: `be/src/tests/fixtures/e2e/providers/elevenlabs/` is built from the documented shapes and marked `documented`: a success (binary audio), a refusal per operation, and a voices page. A sync job has no pending sequence.
