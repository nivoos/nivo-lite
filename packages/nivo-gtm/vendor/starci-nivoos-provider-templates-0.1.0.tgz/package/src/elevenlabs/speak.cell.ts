import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { VoiceSpeak, VoiceSpeakInput } from "../media/capabilities/voice-speak.capability.ts"
import { mediaRefusals } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import type { ElevenLabsAccount } from "./elevenlabs.provider.cell.ts"

export const SpeakOutput = z.strictObject({
    /** The characters billed, the unit of `job.usage`. */
    characters: z.number().int().nonnegative(),
})

type In = z.infer<typeof VoiceSpeakInput>
type Out = z.infer<typeof SpeakOutput>

/** The `output_format` of each format asked for. `wav_44100` is UNVERIFIED (the page lists WAV only as a paid-tier format, README). */
const OUTPUT_FORMAT: Readonly<Record<string, string>> = { mp3: "mp3_44100_128", wav: "wav_44100" }

/**
 * `elevenlabs.tts.speak`: `POST /v1/text-to-speech/{voice}?output_format=...` with `{ text, model_id: "eleven_v3", language_code }`. The answer is the audio itself, so the engine makes the long call and keeps the body as the
 * file (`job.sync`, `outputs.as: "binary"`). Only `eleven_v3` is used: the capability caps the text at 5000 characters, which v3 takes; `eleven_multilingual_v2` has no Vietnamese and `eleven_flash_v2_5` (40 000 characters)
 * is not needed below that cap. The speed goes in `voice_settings.speed` (UNVERIFIED mapping of -3..3 to 0.7..1.2, README).
 */
export class ElevenLabsTtsSpeak implements Operation<typeof VoiceSpeakInput, typeof SpeakOutput, ElevenLabsAccount, MediaRefusal> {
    readonly key = "elevenlabs.tts.speak"
    readonly version = 1
    readonly title = { vi: "Đọc thành giọng nói (ElevenLabs)", en: "Speak text (ElevenLabs)" }
    readonly input = VoiceSpeakInput
    readonly output = SpeakOutput
    // $0.08 per 1000 characters on v3 (spec A, https://elevenlabs.io/pricing/api, not re-read): 0.00008 per character
    readonly semantics = { mutates: true, timeoutMs: 120_000, metered: { usage: "units", price: { usdPerUnit: 0.00008 }, estimate: { units: { textLength: "text", per: 1 } } } } as const
    readonly provider = "elevenlabs"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly implements = VoiceSpeak
    readonly refusals = mediaRefusals
    readonly job = { sync: true, timeoutMs: 120_000, outputs: { path: "", as: "binary" }, usage: { path: "characters", unit: "characters" } } as const
    // UNVERIFIED: the error body `{ detail: { status, message } }` is the one ElevenLabs is known to answer; the page documents only the 422 list
    readonly wire = {
        errorField: "detail.status",
        errorCodes: { quota_exceeded: "quota_exceeded", content_against_policy: "content_refused" },
        statusRefusals: { "422": "input_invalid" },
    } as const

    run(input: In, reach: OperationReach<ElevenLabsAccount, MediaRefusal>): Out {
        const speed = input.speed === undefined ? 1 : 1 + input.speed * 0.1
        const response = reach.http({
            method: "POST",
            path: `/v1/text-to-speech/${input.voice}`,
            query: { output_format: OUTPUT_FORMAT[input.format ?? "mp3"] ?? "mp3_44100_128" },
            headers: { "content-type": "application/json" },
            body: { text: input.text, model_id: "eleven_v3", language_code: input.language ?? "vi", voice_settings: { speed } },
        })
        return response.status === 200 ? { characters: input.text.length } : reach.byStatus()
    }
}
