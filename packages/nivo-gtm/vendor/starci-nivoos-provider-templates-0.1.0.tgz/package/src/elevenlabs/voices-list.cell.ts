import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { isObject, member } from "../shared/json.ts"
import type { ElevenLabsAccount } from "./elevenlabs.provider.cell.ts"

export const VoicesInput = z.strictObject({
    /** Searches name, description, labels and category. */
    search: z.string().min(1).max(100).optional(),
})
export const VoicesOutput = z.strictObject({
    voices: z.array(z.strictObject({ voiceId: z.string().min(1), name: z.string(), category: z.string().nullable(), previewUrl: z.string().nullable() })),
})

type Refusal = "auth_failed"

/**
 * `elevenlabs.voices.list`: `GET /v2/voices?page_size=100` (https://elevenlabs.io/docs/api-reference/voices/search, read 2026-11-18). The page walk is declared in `wire.paging` (`next_page_token`, `has_more`), never looped here.
 * The `voice_id` of a voice is what `voice.speak` takes as `voice`.
 */
export class ElevenLabsVoicesList implements Operation<typeof VoicesInput, typeof VoicesOutput, ElevenLabsAccount, Refusal> {
    readonly key = "elevenlabs.voices.list"
    readonly version = 1
    readonly title = { vi: "Danh sách giọng (ElevenLabs)", en: "Voices (ElevenLabs)" }
    readonly input = VoicesInput
    readonly output = VoicesOutput
    readonly semantics = { mutates: false }
    readonly provider = "elevenlabs"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { paging: { cursorParam: "next_page_token", nextCursor: "next_page_token", items: "voices", pageSize: { param: "page_size", size: 100 }, maxPages: 5 } } as const

    run(input: z.infer<typeof VoicesInput>, reach: OperationReach<ElevenLabsAccount, Refusal>): z.infer<typeof VoicesOutput> {
        const response = reach.http({ method: "GET", path: "/v2/voices", query: input.search === undefined ? {} : { search: input.search } })
        const list = member(response.json, "voices")
        if (response.status !== 200 || !Array.isArray(list)) return reach.byStatus()
        const voices = list.filter(isObject).map((voice) => ({
            voiceId: String(voice["voice_id"] ?? ""),
            name: typeof voice["name"] === "string" ? voice["name"] : "",
            category: typeof voice["category"] === "string" ? voice["category"] : null,
            previewUrl: typeof voice["preview_url"] === "string" ? voice["preview_url"] : null,
        }))
        return { voices: voices.filter((voice) => voice.voiceId !== "") }
    }
}
