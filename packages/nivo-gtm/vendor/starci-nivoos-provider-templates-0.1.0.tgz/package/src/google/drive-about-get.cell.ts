import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const AboutInput = z.strictObject({})
export const AboutOutput = z.strictObject({ displayName: z.string().nullable(), emailAddress: z.string().nullable() })

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)
const textOrNull = (value: unknown): string | null => (typeof value === "string" ? value : null)

/** `google-drive.about.get`: the connect test of `google-drive`: reads who the signed-in user is (`fields` is required by the vendor on this method). */
export class DriveAboutGet implements Operation<typeof AboutInput, typeof AboutOutput, never> {
    readonly key = "google-drive.about.get"
    readonly version = 1
    readonly title = { vi: "Tôi là ai trên Google Drive", en: "Who am I on Google Drive" }
    readonly input = AboutInput
    readonly output = AboutOutput
    readonly semantics = { mutates: false }
    readonly provider = "google-drive"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = [] as const

    run(_input: z.infer<typeof AboutInput>, reach: OperationReach<never>): z.infer<typeof AboutOutput> {
        const answer = reach.http({ method: "GET", path: "/drive/v3/about", query: { fields: "user(displayName,emailAddress)" } })
        if (answer.status !== 200 || !isObject(answer.json)) return reach.byStatus()
        const user = answer.json["user"]
        if (!isObject(user)) return reach.byStatus()
        return { displayName: textOrNull(user["displayName"]), emailAddress: textOrNull(user["emailAddress"]) }
    }
}
