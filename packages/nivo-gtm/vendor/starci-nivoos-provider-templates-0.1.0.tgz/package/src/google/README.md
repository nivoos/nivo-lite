# google (Google Sheets) and google-drive (Google Drive)

Two providers, one folder, one Google sign-in each (OAuth 2.0 code flow with PKCE, run by the engine; the instance owner sets the client id and secret in the env
keys GOOGLE_API_CLIENT_ID / GOOGLE_API_CLIENT_SECRET, a different pair from the app's own "sign in with Google"). They are two providers because a provider has ONE
`base` and the two APIs answer on different hosts: Sheets on `https://sheets.googleapis.com`, Drive on `https://www.googleapis.com/drive/v3`. Each account is signed in
once per provider. Vendor facts below were fetched from Google's public docs on 2026-11-16; anything not on a fetched page is marked UNKNOWN.

| Provider | Operation | Vendor call | Scope (least privilege that works) |
| --- | --- | --- | --- |
| `google` | `google.sheets.values.append` | `POST /v4/spreadsheets/{id}/values/{range}:append` | `spreadsheets` |
| `google` | `google.sheets.values.get` | `GET /v4/spreadsheets/{id}/values/{range}` | `spreadsheets` (see below) |
| `google-drive` | `google-drive.about.get` (connect test) | `GET /drive/v3/about?fields=user(...)` | `drive.file` |
| `google-drive` | `google-drive.files.create` | `POST /drive/v3/files` (metadata only) | `drive.file` |

## Facts and where they come from
- Authorize `https://accounts.google.com/o/oauth2/v2/auth`, token `https://oauth2.googleapis.com/token`; `access_type=offline` makes Google return a refresh token at the first
  code exchange, `prompt=consent` makes it return a new one when the person signed in before; the token answer carries `access_token`, `expires_in`, `refresh_token` (only with
  offline), `scope`, `token_type`; a refresh is a POST of `client_id`, `refresh_token`, `grant_type=refresh_token` (`client_secret` optional) and answers `access_token`,
  `expires_in`, `scope`; a revoked or expired refresh token fails with `invalid_grant` and the user must sign in again.
  Source: https://developers.google.com/identity/protocols/oauth2/web-server
  The engine keeps the query of `authorizeUrl`, so the two parameters are written in the declared `authorizeUrl`.
- Sheets append: `POST https://sheets.googleapis.com/v4/spreadsheets/{spreadsheetId}/values/{range}:append`; query `valueInputOption` and `insertDataOption`
  (INSERT_ROWS inserts rows for the new data); body a ValueRange (`range`, `majorDimension`, `values`); answer `spreadsheetId`, `tableRange`, `updates` (UpdateValuesResponse:
  `spreadsheetId`, `updatedRange`, `updatedRows`, `updatedColumns`, `updatedCells`). Accepted scopes: `drive`, `drive.file`, `spreadsheets`.
  Sources: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets.values/append , https://developers.google.com/workspace/sheets/api/reference/rest/v4/UpdateValuesResponse
- Sheets get: `GET .../values/{range}`, query `majorDimension`; answer a ValueRange; the least scope the page lists is `spreadsheets.readonly`.
  Source: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets.values/get
  The provider asks ONE scope, `spreadsheets`, which covers both operations of the provider; asking `spreadsheets.readonly` would break the append. A read-only copy of the provider
  would be a separate provider (not built).
- Why `spreadsheets` and not `drive.file` for Sheets: the append page lists `drive.file` as accepted, but Google's scope text for `drive.file` is "only the specific Google Drive
  files you use with this app" (https://developers.google.com/identity/protocols/oauth2/scopes), so a spreadsheet the person made elsewhere is not reachable with it. Whether a
  spreadsheet picked another way is reachable with `drive.file` is UNKNOWN from the fetched pages.
- Sheets quota: 300 read and 300 write requests a minute per project, 60 a minute per user per project; over it Google answers 429 (the engine's table makes that a transient with its retry).
  Source: https://developers.google.com/workspace/sheets/api/limits
- Drive create: `POST https://www.googleapis.com/drive/v3/files` is the metadata URI (media goes to `/upload/drive/v3/files`); body a File resource (`id`, `name`, `mimeType`,
  `parents[]` with one parent, `webViewLink` output only, `description`); accepted scopes `drive`, `drive.appdata`, `drive.file`.
  Sources: https://developers.google.com/workspace/drive/api/reference/rest/v3/files/create , https://developers.google.com/workspace/drive/api/reference/rest/v3/files
- MIME types: Sheets the google-apps spreadsheet type, folder the google-apps folder type. Source: https://developers.google.com/workspace/drive/api/guides/mime-types
- Drive about: `GET https://www.googleapis.com/drive/v3/about`, `fields` is required, scopes include `drive.file`; the `user` field is "the authenticated user".
  Source: https://developers.google.com/workspace/drive/api/reference/rest/v3/about/get
  UNKNOWN from fetched pages: the User resource members. `displayName` and `emailAddress` are requested and read as optional (null when absent).

## Declared refusals and what is not declared
- `range_invalid` (append, get) and `request_invalid` (Drive create) are returned for HTTP 400. That mapping is this provider's choice; the exact 400 error body of Google is
  UNKNOWN (not on the fetched pages), so the code is derived from the status only, never from the message.
- 401 / 403 / 404 / 429 / 5xx are left to the engine's one table (`auth_failed` and the account `needs_reauth`, `not_found`, transient, ...).
- Sheets append and Drive create are not idempotent at the vendor: a repeat adds a second row / file. No dedupe key exists on these calls (UNKNOWN whether one does).

## Not built, on purpose
- No `connectTest` for `google`: Sheets has no call that needs no spreadsheet (UNKNOWN on the fetched pages). The account is proved by the first operation and by the engine's refresh.
- No webhook, no trigger, no poll.
- Logo: a neutral monogram (`mark: "monogram"`); Google's brand terms for redistributing its marks were not fetched.
- Publishing an OAuth client for production needs Google's app verification for sensitive scopes; the rules (and any refresh-token lifetime of an unverified app) are UNKNOWN here.

## Tests
`be/src/tests/integration/providers/google.integration-spec.ts` with fixtures in `be/src/tests/fixtures/e2e/providers/google/`: sign-in round trip against a fake Google OAuth server
(PKCE verified, offline access asked), tokens sealed, refresh before a call, a rejected refresh, append / read / create, a declared refusal, the Drive connect test.
The suite needs GOOGLE_API_CLIENT_ID / GOOGLE_API_CLIENT_SECRET in the e2e env (`be/src/tests/world/world-options.ts`).
