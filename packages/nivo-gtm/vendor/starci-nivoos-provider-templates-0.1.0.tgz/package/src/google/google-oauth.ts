import { z } from "zod"
import type { ProviderAuthWay } from "@starci/nivoos-sdk"

/**
 * What an account of a Google provider holds: the name the person gave it (public) and the three fields the engine's OAuth code flow fills, all
 * sealed (the form does not show them). There is no manual-token way: a Google access token lives about an hour, so only the sign-in keeps an account alive.
 */
export const GoogleFields = z.strictObject({
    account: z.string().min(1),
    accessToken: z.string().min(1).optional(),
    refreshToken: z.string().min(1).optional(),
    expiresAt: z.string().min(1).optional(),
    spreadsheetId: z.string().min(1).optional(),
})

export const GoogleSecrets = ["accessToken", "refreshToken", "expiresAt"] as const

export const GoogleForm = {
    account: {
        label: { vi: "Tên kết nối", en: "Connection name" },
        help: { vi: "Tên bạn đặt để nhận ra tài khoản Google này.", en: "A name you choose to recognise this Google account." },
        kind: "text",
        order: 1,
    },
    accessToken: { label: { vi: "Mã truy cập", en: "Access token" }, kind: "secret", order: 2 },
    refreshToken: { label: { vi: "Mã làm mới", en: "Refresh token" }, kind: "secret", order: 3 },
    expiresAt: { label: { vi: "Hết hạn lúc", en: "Expires at" }, kind: "secret", order: 4 },
    spreadsheetId: {
        label: { vi: "Bảng tính mặc định", en: "Default spreadsheet" },
        help: { vi: "Mã của bảng tính Google mà tác tử ghi vào; chọn ở bước thiết lập.", en: "The id of the Google spreadsheet the agent writes to; chosen in the setup." },
        kind: "text",
        order: 5,
    },
} as const

/** The instance owner's OAuth client of the Google providers (the env KEY NAMES; the values are the owner's, never in code). */
export const GOOGLE_CLIENT_ID_ENV = "GOOGLE_API_CLIENT_ID"
export const GOOGLE_CLIENT_SECRET_ENV = "GOOGLE_API_CLIENT_SECRET"

/**
 * The OAuth way of a Google provider. `access_type=offline` is what makes Google return a refresh token at the code exchange and `prompt=consent`
 * makes it return a new one when the person signed in before (Google, "Using OAuth 2.0 for Web Server Applications"); the engine keeps the query of
 * `authorizeUrl` and adds its own parameters, so they ride in the URL. See README.md.
 */
export const googleOauthWay = (scopes: ReadonlyArray<string>): ProviderAuthWay => ({
    kind: "oauth2",
    authorizeUrl: "https://accounts.google.com/o/oauth2/v2/auth?access_type=offline&prompt=consent",
    tokenUrl: "https://oauth2.googleapis.com/token",
    scopes,
    clientIdEnv: GOOGLE_CLIENT_ID_ENV,
    clientSecretEnv: GOOGLE_CLIENT_SECRET_ENV,
    tokenField: "accessToken",
    refreshField: "refreshToken",
    expiresAtField: "expiresAt",
})
