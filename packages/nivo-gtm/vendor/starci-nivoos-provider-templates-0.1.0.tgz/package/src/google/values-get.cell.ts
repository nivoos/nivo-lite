import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

const Cell = z.union([z.string(), z.number(), z.boolean()])

export const GetInput = z.strictObject({
    spreadsheetId: z.string().min(1).regex(/^[A-Za-z0-9_-]+$/u),
    /** A1 range, e.g. `Sheet1!A1:C10`. */
    range: z.string().min(1),
})
export const GetOutput = z.strictObject({
    range: z.string(),
    /** Rows of cells; empty when the range holds no value (the vendor omits `values` then). */
    values: z.array(z.array(Cell)),
})
type In = z.infer<typeof GetInput>
type Out = z.infer<typeof GetOutput>
const REFUSALS = ["range_invalid"] as const

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/** `google.sheets.values.get`: reads one range as rows (`majorDimension=ROWS`). A 400 is the declared refusal `range_invalid`. */
export class SheetsValuesGet implements Operation<typeof GetInput, typeof GetOutput, never, (typeof REFUSALS)[number]> {
    readonly key = "google.sheets.values.get"
    readonly version = 1
    readonly title = { vi: "Đọc một vùng ô của Google Sheets", en: "Read a range of Google Sheets" }
    readonly input = GetInput
    readonly output = GetOutput
    readonly semantics = { mutates: false }
    readonly provider = "google"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = REFUSALS

    run(input: In, reach: OperationReach<never, (typeof REFUSALS)[number]>): Out {
        const answer = reach.http({
            method: "GET",
            path: `/v4/spreadsheets/${input.spreadsheetId}/values/${encodeURIComponent(input.range)}`,
            query: { majorDimension: "ROWS" },
        })
        if (answer.status === 400) return reach.refuse("range_invalid")
        if (answer.status !== 200 || !isObject(answer.json)) return reach.byStatus()
        const range = answer.json["range"]
        if (typeof range !== "string") return reach.byStatus()
        const rows = answer.json["values"] ?? []
        if (!Array.isArray(rows)) return reach.byStatus()
        const values: Array<Array<string | number | boolean>> = []
        for (const row of rows) {
            if (!Array.isArray(row)) return reach.byStatus()
            const cells: Array<string | number | boolean> = []
            for (const cell of row) {
                if (typeof cell !== "string" && typeof cell !== "number" && typeof cell !== "boolean") return reach.byStatus()
                cells.push(cell)
            }
            values.push(cells)
        }
        return { range, values }
    }
}
