import type { Provider } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { z } from "zod"
import { GoogleFields, GoogleForm, GoogleSecrets, googleOauthWay } from "./google-oauth.ts"

/** Least scope that lets the sheet operations read and append to a spreadsheet the person already owns (`drive.file` only reaches files this app created). */
export const SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets"

/** `google`: Google Sheets through the person's own Google sign-in (OAuth 2.0 with refresh). No webhook, no connect test (see README.md). */
export class GoogleProvider implements Provider<typeof GoogleFields, z.ZodObject<{}>, {}> {
    readonly key = "google"
    readonly version = 1
    readonly title = { vi: "Google Sheets", en: "Google Sheets" }
    readonly description = {
        vi: "Ghi thêm một dòng vào bảng tính và đọc một vùng ô của Google Sheets bằng tài khoản Google của bạn.",
        en: "Append a row to a Google Sheets spreadsheet and read a range of it with your own Google account.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = GoogleFields
    readonly secrets = GoogleSecrets
    readonly form = GoogleForm
    readonly identityField = "account"
    readonly kind = "base"
    readonly base = { fixed: "https://sheets.googleapis.com" }
    readonly auth = { scheme: "bearer", secretField: "accessToken" } as const
    readonly authWays = [googleOauthWay([SHEETS_SCOPE])] as const
    /** Sign-in is Google's OAuth (https://developers.google.com/identity/protocols/oauth2/web-server). The spreadsheet list comes from Drive (another host), so the choose step lives on `google-drive`; this provider keeps the chosen id in `spreadsheetId`. */
    readonly setup = [
        setup.oauth({
            key: "sign-in",
            title: { vi: "Đăng nhập Google", en: "Sign in with Google" },
            body: {
                vi: "Bạn đăng nhập Google và cho phép NIVO dùng Google Sheets với quyền tối thiểu: chỉ các tệp NIVO tạo hoặc bạn mở bằng ứng dụng này.",
                en: "You sign in with Google and let NIVO use Google Sheets with the least scope: only files NIVO creates or you open with this app.",
            },
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = {}
}
