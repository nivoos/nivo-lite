import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

const Cell = z.union([z.string(), z.number(), z.boolean()])

export const AppendInput = z.strictObject({
    spreadsheetId: z.string().min(1).regex(/^[A-Za-z0-9_-]+$/u),
    /** A1 range that names the table to append after, e.g. `Sheet1!A:E`. */
    range: z.string().min(1),
    /** One row, one cell per column. */
    values: z.array(Cell).min(1),
    /** `USER_ENTERED` (the default here) parses the cells as typed in the UI; `RAW` keeps them as given. */
    valueInputOption: z.enum(["RAW", "USER_ENTERED"]).optional(),
})
export const AppendOutput = z.strictObject({
    spreadsheetId: z.string(),
    updatedRange: z.string(),
    updatedRows: z.number().int(),
    updatedCells: z.number().int(),
})
type In = z.infer<typeof AppendInput>
type Out = z.infer<typeof AppendOutput>
const REFUSALS = ["range_invalid"] as const

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/**
 * `google.sheets.values.append`: appends one row after the last row of the table the range names (`insertDataOption=INSERT_ROWS`, so the
 * row is inserted, never written over). A 400 is the vendor saying the request cannot be taken (an unparseable range): the declared refusal `range_invalid`.
 */
export class SheetsValuesAppend implements Operation<typeof AppendInput, typeof AppendOutput, never, (typeof REFUSALS)[number]> {
    readonly key = "google.sheets.values.append"
    readonly version = 1
    readonly title = { vi: "Thêm một dòng vào Google Sheets", en: "Append a row to Google Sheets" }
    readonly input = AppendInput
    readonly output = AppendOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "google"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = REFUSALS

    run(input: In, reach: OperationReach<never, (typeof REFUSALS)[number]>): Out {
        const answer = reach.http({
            method: "POST",
            path: `/v4/spreadsheets/${input.spreadsheetId}/values/${encodeURIComponent(input.range)}:append`,
            query: { valueInputOption: input.valueInputOption ?? "USER_ENTERED", insertDataOption: "INSERT_ROWS" },
            body: { majorDimension: "ROWS", values: [input.values] },
        })
        if (answer.status === 400) return reach.refuse("range_invalid")
        if (answer.status !== 200 || !isObject(answer.json)) return reach.byStatus()
        const updates = answer.json["updates"]
        if (!isObject(updates)) return reach.byStatus()
        const { spreadsheetId, updatedRange, updatedRows, updatedCells } = updates
        if (typeof spreadsheetId !== "string" || typeof updatedRange !== "string" || typeof updatedRows !== "number" || typeof updatedCells !== "number") return reach.byStatus()
        return { spreadsheetId, updatedRange, updatedRows, updatedCells }
    }
}
