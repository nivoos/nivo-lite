// The Google providers listed alone (the integration spec builds this with the real SDK build and deploys it as the master); the full list is `src/provider-templates.package.ts`.
import type { Package } from "@starci/nivoos-sdk"
import { DriveAboutGet } from "./drive-about-get.cell.ts"
import { DriveFilesCreate } from "./drive-files-create.cell.ts"
import { DriveSpreadsheetsList } from "./drive-spreadsheets-list.cell.ts"
import { GoogleDriveProvider } from "./google-drive.provider.cell.ts"
import { GoogleProvider } from "./google.provider.cell.ts"
import { SheetsValuesAppend } from "./values-append.cell.ts"
import { SheetsValuesGet } from "./values-get.cell.ts"

export default {
    package: { key: "google", version: "1.0.0", author: "e2e" },
    cells: [GoogleProvider, SheetsValuesAppend, SheetsValuesGet, GoogleDriveProvider, DriveAboutGet, DriveFilesCreate, DriveSpreadsheetsList],
    agents: [],
} satisfies Package
