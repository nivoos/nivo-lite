import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const SpreadsheetsListInput = z.strictObject({})
export const SpreadsheetsListOutput = z.strictObject({ items: z.array(z.strictObject({ value: z.string(), label: z.string() })) })

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/**
 * `google-drive.spreadsheets.list`: the spreadsheets of the signed-in person (newest first, at most 100) as `{ value: id, label: name }`, for the setup's
 * choose step. Drive `files.list` with `q: mimeType='application/vnd.google-apps.spreadsheet'`. Sheets answers on another host than Drive, so the
 * list lives on this provider (one `base` per provider). Scope: `files.list` accepts `drive.metadata.readonly` among others
 * (https://developers.google.com/workspace/drive/api/reference/rest/v3/files/list); `drive.file` alone would list only files this app made.
 */
export class DriveSpreadsheetsList implements Operation<typeof SpreadsheetsListInput, typeof SpreadsheetsListOutput, never> {
    readonly key = "google-drive.spreadsheets.list"
    readonly version = 1
    readonly title = { vi: "Danh sách bảng tính Google", en: "Google spreadsheets" }
    readonly input = SpreadsheetsListInput
    readonly output = SpreadsheetsListOutput
    readonly semantics = { mutates: false }
    readonly provider = "google-drive"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = [] as const

    run(_input: z.infer<typeof SpreadsheetsListInput>, reach: OperationReach<never>): z.infer<typeof SpreadsheetsListOutput> {
        const answer = reach.http({
            method: "GET",
            path: "/drive/v3/files",
            query: { q: "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false", orderBy: "modifiedTime desc", pageSize: 100, fields: "files(id,name)" },
        })
        if (answer.status !== 200 || !isObject(answer.json)) return reach.byStatus()
        const files = answer.json["files"]
        if (!Array.isArray(files)) return reach.byStatus()
        const items: Array<{ value: string; label: string }> = []
        for (const file of files) if (isObject(file) && typeof file["id"] === "string" && typeof file["name"] === "string") items.push({ value: file["id"], label: file["name"] })
        return { items }
    }
}
