import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const CreateInput = z.strictObject({
    name: z.string().min(1),
    /** E.g. `application/vnd.google-apps.spreadsheet` (a Google Sheets file) or `application/vnd.google-apps.folder`. */
    mimeType: z.string().min(1),
    /** The folder to create it in (one parent); the vendor's default when absent. */
    parentId: z.string().min(1).optional(),
})
export const CreateOutput = z.strictObject({
    id: z.string(),
    name: z.string(),
    mimeType: z.string(),
    webViewLink: z.string().nullable(),
})
type In = z.infer<typeof CreateInput>
type Out = z.infer<typeof CreateOutput>
const REFUSALS = ["request_invalid"] as const

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/**
 * `google-drive.files.create`: creates a file by metadata only (no content upload) with a name, a MIME type and an optional parent. A 400 is
 * the declared refusal `request_invalid`. Not idempotent at the vendor: a repeat creates a second file.
 */
export class DriveFilesCreate implements Operation<typeof CreateInput, typeof CreateOutput, never, (typeof REFUSALS)[number]> {
    readonly key = "google-drive.files.create"
    readonly version = 1
    readonly title = { vi: "Tạo tệp trên Google Drive", en: "Create a file on Google Drive" }
    readonly input = CreateInput
    readonly output = CreateOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "google-drive"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = REFUSALS

    run(input: In, reach: OperationReach<never, (typeof REFUSALS)[number]>): Out {
        const answer = reach.http({
            method: "POST",
            path: "/drive/v3/files",
            query: { fields: "id,name,mimeType,webViewLink" },
            body: input.parentId === undefined ? { name: input.name, mimeType: input.mimeType } : { name: input.name, mimeType: input.mimeType, parents: [input.parentId] },
        })
        if (answer.status === 400) return reach.refuse("request_invalid")
        if (answer.status !== 200 || !isObject(answer.json)) return reach.byStatus()
        const { id, name, mimeType, webViewLink } = answer.json
        if (typeof id !== "string" || typeof name !== "string" || typeof mimeType !== "string") return reach.byStatus()
        return { id, name, mimeType, webViewLink: typeof webViewLink === "string" ? webViewLink : null }
    }
}
