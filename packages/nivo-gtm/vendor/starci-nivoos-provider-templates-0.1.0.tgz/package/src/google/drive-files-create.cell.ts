import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { isObject } from "../shared/json.ts"

export const CreateInput = z.strictObject({
    name: z.string().min(1),
    /** E.g. `application/vnd.google-apps.spreadsheet` (a Google Sheets file) or `application/vnd.google-apps.folder`. */
    mimeType: z.string().min(1),
    /** The folder to create it in (one parent); the vendor's default when absent. */
    parentId: z.string().min(1).optional(),
})
export const CreateOutput = z.strictObject({
    id: z.string(),
    name: z.string(),
    mimeType: z.string(),
    webViewLink: z.string().nullable(),
})
type In = z.infer<typeof CreateInput>
type Out = z.infer<typeof CreateOutput>
const REFUSALS = ["request_invalid"] as const

/**
 * `google-drive.files.create`: creates a file by metadata only (no content upload) with a name, a MIME type and an optional parent. A 400 is
 * the declared refusal `request_invalid`, mapped by the engine from the declared wire. Not idempotent at the vendor: a repeat creates a second file. The file lands in the customer's own drive: the act leaves the
 * company, so a step that acts through it asks a person.
 */
export class DriveFilesCreate implements Operation<typeof CreateInput, typeof CreateOutput, never, (typeof REFUSALS)[number]> {
    readonly key = "google-drive.files.create"
    readonly version = 2
    readonly title = { vi: "Tạo tệp trên Google Drive", en: "Create a file on Google Drive" }
    readonly input = CreateInput
    readonly output = CreateOutput
    readonly semantics = { mutates: true, outside: true }
    readonly external = true
    readonly wire = { ok: [200], statusRefusals: { "400": "request_invalid" } } as const
    readonly provider = "google-drive"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = REFUSALS

    run(input: In, reach: OperationReach<never, (typeof REFUSALS)[number]>): Out {
        const answer = reach.http({
            method: "POST",
            path: "/drive/v3/files",
            query: { fields: "id,name,mimeType,webViewLink" },
            body: input.parentId === undefined ? { name: input.name, mimeType: input.mimeType } : { name: input.name, mimeType: input.mimeType, parents: [input.parentId] },
        })
        if (!isObject(answer.json)) return reach.byStatus()
        const { id, name, mimeType, webViewLink } = answer.json
        if (typeof id !== "string" || typeof name !== "string" || typeof mimeType !== "string") return reach.byStatus()
        return { id, name, mimeType, webViewLink: typeof webViewLink === "string" ? webViewLink : null }
    }
}
