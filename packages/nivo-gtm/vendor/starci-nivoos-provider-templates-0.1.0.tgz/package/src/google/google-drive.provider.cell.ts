import type { Provider } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { DriveAboutGet } from "./drive-about-get.cell.ts"
import { DriveSpreadsheetsList } from "./drive-spreadsheets-list.cell.ts"
import { z } from "zod"
import { GoogleFields, GoogleForm, GoogleSecrets, googleOauthWay } from "./google-oauth.ts"

/** Least scope for creating a file: the app reaches only the files it creates or the person opens with it. */
export const DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file"

/** Lists the person's files (metadata only) so the setup can offer their spreadsheets: one of the scopes `files.list` accepts (https://developers.google.com/workspace/drive/api/reference/rest/v3/files/list). Restricted: Google may require a security review of the app. */
export const DRIVE_METADATA_SCOPE = "https://www.googleapis.com/auth/drive.metadata.readonly"

/** `google-drive`: Google Drive file creation through the person's own Google sign-in. A second provider because Drive answers on another host than Sheets (one `base` per provider). */
export class GoogleDriveProvider implements Provider<typeof GoogleFields, z.ZodObject<{}>, {}> {
    readonly key = "google-drive"
    readonly version = 1
    readonly title = { vi: "Google Drive", en: "Google Drive" }
    readonly description = {
        vi: "Tạo tệp hoặc thư mục trong Google Drive của bạn, chỉ chạm vào những tệp do NIVO tạo.",
        en: "Create a file or folder in your Google Drive, touching only files NIVO creates.",
    }
    readonly logo = { file: "drive-logo.svg", mark: "monogram" } as const
    readonly fields = GoogleFields
    readonly secrets = GoogleSecrets
    readonly form = GoogleForm
    readonly identityField = "account"
    readonly kind = "base"
    readonly base = { fixed: "https://www.googleapis.com" }
    readonly auth = { scheme: "bearer", secretField: "accessToken" } as const
    readonly authWays = [googleOauthWay([DRIVE_SCOPE, DRIVE_METADATA_SCOPE])] as const
    readonly connectTest = "google-drive.about.get"
    /** Sign-in is Google's OAuth (https://developers.google.com/identity/protocols/oauth2/web-server); the scope is `drive.file`. */
    readonly setup = [
        setup.oauth({
            key: "sign-in",
            title: { vi: "Đăng nhập Google", en: "Sign in with Google" },
            body: { vi: "Bạn đăng nhập Google và cho phép NIVO tạo tệp trong Drive; NIVO chỉ chạm vào những tệp nó tạo.", en: "You sign in with Google and let NIVO create files in Drive; NIVO touches only files it creates." },
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra Drive", en: "Check Drive" }, operation: DriveAboutGet, show: "emailAddress" }),
        setup.choose({
            key: "spreadsheet",
            title: { vi: "Chọn bảng tính", en: "Choose a spreadsheet" },
            body: {
                vi: "Chọn bảng tính Google mà tác tử sẽ ghi vào. Để liệt kê bảng tính, NIVO xin thêm quyền **chỉ đọc thông tin tệp** (`drive.metadata.readonly`) và gọi `files.list` của Google Drive; NIVO không đọc nội dung tệp. Quyền này Google xếp vào nhóm hạn chế nên ứng dụng có thể phải qua bước xét duyệt của Google.",
                en: "Choose the Google spreadsheet the agent writes to. To list spreadsheets NIVO asks for the extra **read-only file metadata** scope (`drive.metadata.readonly`) and calls Google Drive's `files.list`; NIVO does not read file contents. Google classes this scope as restricted, so the app may need Google's review.",
            },
            operation: DriveSpreadsheetsList,
            field: "spreadsheetId",
            optional: true,
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = {}
}
