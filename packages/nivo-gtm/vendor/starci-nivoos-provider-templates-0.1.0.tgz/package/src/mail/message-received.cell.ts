import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { MailMessageRow } from "./mail.provider.cell.ts"

type Row = z.infer<typeof MailMessageRow>

/**
 * `mail.message.received`: one new mail of the inbox is one event, keyed by its Message-ID, on the subject `contact:<sender address>`, on by default. Version 2 declares the batching settings of a workspace
 * (E7): a wait that batches this kind (`NodeWait.batch`) gathers a burst of mails for `batchWindowSeconds` after the first one, or until `batchMax` mails, whichever comes first.
 */
export class MailMessageReceived implements Trigger<typeof MailMessageRow, typeof MailMessageRow> {
    readonly key = "mail.message.received"
    readonly version = 2
    readonly title = { vi: "Nhận một thư", en: "Mail received" }
    readonly row = MailMessageRow
    readonly event = MailMessageRow
    readonly provider = "mail"
    readonly dataType = { providerVersion: 1, key: "mail.message" }
    readonly keyMember = "messageId"
    readonly subjectKind = "contact"
    readonly subjectMember = "fromAddress"
    readonly switchOnByDefault = true
    readonly vias = ["poll"] as const
    /** The burst a batching wait gathers: the window from the first mail (seconds) and the most mails of one batch. */
    readonly settings = z.strictObject({
        batchWindowSeconds: z.number().int().min(1).max(86_400).default(120),
        batchMax: z.number().int().min(1).max(50).default(25),
    })

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Row> | null {
        return { id: row.messageId, data: row }
    }
}
