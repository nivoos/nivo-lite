import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const CheckInboxInput = z.strictObject({})
export const CheckInboxOutput = z.strictObject({ ok: z.literal(true) })

/** `mail.inbox.check`: the connect test. Opens the inbox once (one message at most); a server that refuses the login or is down fails the test through the engine's one table. */
export class CheckInbox implements Operation<typeof CheckInboxInput, typeof CheckInboxOutput> {
    readonly key = "mail.inbox.check"
    readonly version = 1
    readonly title = { vi: "Kiểm tra hộp thư", en: "Check the inbox" }
    readonly input = CheckInboxInput
    readonly output = CheckInboxOutput
    readonly semantics = { mutates: false }
    readonly provider = "mail"
    readonly http = false
    readonly refusals = [] as const

    run(_input: z.infer<typeof CheckInboxInput>, reach: OperationReach): z.infer<typeof CheckInboxOutput> {
        reach.mail?.fetch({ limit: 1 })
        return { ok: true }
    }
}
