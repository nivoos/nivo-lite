import { z } from "zod"
import type { DataTypes, Provider } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { CheckInbox } from "./check-inbox.cell.ts"
import { MAIL_PRESETS } from "./mail-presets.ts"

/** What an account of a mailbox connects with: the SMTP and IMAP servers, the login, the password (secret) and how the channel is secured. */
export const MailFields = z.strictObject({
    smtpHost: z.string().min(1),
    smtpPort: z.string().regex(/^[0-9]{1,5}$/u),
    imapHost: z.string().min(1),
    imapPort: z.string().regex(/^[0-9]{1,5}$/u),
    user: z.string().min(3),
    password: z.string().min(1),
    secure: z.enum(["tls", "starttls", "none"]),
})

/** A mailbox has no webhook: the provider declares no proof. */
const MailProof = z.strictObject({})

/** One message kept from the inbox: the Message-ID header is its key; `fromAddress` is lower case and names the contact. */
export const MailMessageRow = z.strictObject({
    messageId: z.string().min(1),
    fromAddress: z.string().min(3),
    fromName: z.string().optional(),
    to: z.array(z.string()),
    subject: z.string(),
    text: z.string(),
    receivedAt: z.string(),
    inReplyTo: z.string().optional(),
    /** The Message-IDs of the thread (the References header), oldest first. */
    references: z.array(z.string()).optional(),
    cc: z.array(z.string()).optional(),
    /** The HTML body as the server holds it (the engine sanitises it before a person sees it). */
    html: z.string().optional(),
    /** The files the message carries: `part` is the MIME part the engine downloads when a person opens the file. */
    attachments: z.array(z.strictObject({ name: z.string(), mime: z.string(), bytes: z.number().int().min(0), part: z.string() })).optional(),
})

/** The raw rows the mailbox keeps, by data type. */
export const MailData = {
    "mail.message": { value: MailMessageRow, keyMembers: ["messageId"], occurredAtMember: "receivedAt" },
} as const satisfies DataTypes

/**
 * `mail`: any mailbox that speaks SMTP (send) and IMAP (read). The ENGINE speaks both protocols with the account's settings
 * (`transport: "mail"`); the code only passes a message or a fetch request. There is no webhook: new mail arrives by the engine's poll of the
 * inbox (`mail.messages.poll`), kept under the Message-ID.
 */
export class MailProvider implements Provider<typeof MailFields, typeof MailProof, typeof MailData> {
    readonly key = "mail"
    readonly version = 1
    readonly title = { vi: "Hộp thư (SMTP / IMAP)", en: "Mailbox (SMTP / IMAP)" }
    readonly fields = MailFields
    readonly secrets = ["password"] as const
    readonly description = {
        vi: "Gửi thư qua SMTP và nhận thư mới qua IMAP của một hộp thư bất kỳ (dùng mật khẩu ứng dụng nếu nhà cung cấp yêu cầu).",
        en: "Sends mail over SMTP and receives new mail over IMAP for any mailbox (use an app password where the provider requires one).",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        smtpHost: { label: { vi: "Máy chủ SMTP", en: "SMTP host" }, help: { vi: "Tên máy chủ gửi thư, ví dụ smtp.example.com.", en: "The outgoing mail server, e.g. smtp.example.com." }, kind: "text", order: 1 },
        smtpPort: { label: { vi: "Cổng SMTP", en: "SMTP port" }, help: { vi: "465 (TLS ngầm định) hoặc 587 (STARTTLS).", en: "465 (implicit TLS) or 587 (STARTTLS)." }, placeholder: { vi: "587", en: "587" }, kind: "number", order: 2 },
        imapHost: { label: { vi: "Máy chủ IMAP", en: "IMAP host" }, help: { vi: "Tên máy chủ nhận thư, ví dụ imap.example.com.", en: "The incoming mail server, e.g. imap.example.com." }, kind: "text", order: 3 },
        imapPort: { label: { vi: "Cổng IMAP", en: "IMAP port" }, help: { vi: "993 cho IMAP qua TLS.", en: "993 for IMAP over TLS." }, placeholder: { vi: "993", en: "993" }, kind: "number", order: 4 },
        user: { label: { vi: "Địa chỉ thư", en: "Mailbox address" }, help: { vi: "Địa chỉ đăng nhập; cũng là địa chỉ người gửi.", en: "The login; it is also the sender address." }, kind: "email", order: 5 },
        password: { label: { vi: "Mật khẩu", en: "Password" }, help: { vi: "Mật khẩu hộp thư hoặc mật khẩu ứng dụng.", en: "The mailbox password or an app password." }, kind: "secret", order: 6 },
        secure: {
            label: { vi: "Bảo mật kết nối", en: "Connection security" },
            help: { vi: "TLS hoặc STARTTLS: có mã hoá (cổng 465 và 993 dùng TLS ngầm định, cổng 587 và 143 nâng cấp bằng STARTTLS); Không: không mã hoá.", en: "TLS or STARTTLS: encrypted (ports 465 and 993 use implicit TLS, ports 587 and 143 upgrade with STARTTLS); None: not encrypted." },
            kind: "select",
            order: 7,
            options: [
                { value: "tls", label: { vi: "TLS", en: "TLS" } },
                { value: "starttls", label: { vi: "STARTTLS", en: "STARTTLS" } },
                { value: "none", label: { vi: "Không", en: "None" } },
            ],
        },
    } as const
    readonly identityField = "user"
    readonly kind = "mail"
    readonly presets = MAIL_PRESETS
    readonly transport = "mail"
    readonly mail = { smtpHost: "smtpHost", smtpPort: "smtpPort", imapHost: "imapHost", imapPort: "imapPort", user: "user", password: "password", secure: "secure" } as const
    readonly auth = { scheme: "none" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly connectTest = "mail.inbox.check"
    readonly poll = { operation: "mail.messages.poll", dataType: "mail.message", aloneMs: 60_000, besideWebhookMs: 300_000, ratePerSecond: 1, burst: 2, concurrency: 1 } as const
    /** Ports and TLS follow RFC 8314 (https://www.rfc-editor.org/rfc/rfc8314): IMAP over implicit TLS defaults to 993. */
    readonly setup = [
        setup.fields({
            key: "mailbox",
            title: { vi: "Hộp thư", en: "The mailbox" },
            body: { vi: "Nhập máy chủ SMTP/IMAP, cổng, tên đăng nhập và mật khẩu (hoặc mật khẩu ứng dụng) của hộp thư.", en: "Enter the SMTP/IMAP hosts, ports, user name and password (or app password) of the mailbox." },
            fields: ["smtpHost", "smtpPort", "imapHost", "imapPort", "user", "password", "secure"],
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra hộp thư", en: "Check the inbox" }, operation: CheckInbox }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = MailData
}
