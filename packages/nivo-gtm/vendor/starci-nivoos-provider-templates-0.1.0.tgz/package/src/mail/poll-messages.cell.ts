import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { MailMessageRow } from "./mail.provider.cell.ts"

export const PollMessagesInput = z.strictObject({ from: z.string(), to: z.string(), limit: z.number().int().min(1).max(100) })
export const PollMessagesOutput = z.strictObject({
    items: z.array(z.strictObject({ key: z.string().min(1), value: MailMessageRow, at: z.string() })),
    fetched: z.number().int().min(0),
    oldestAt: z.string().optional(),
})

type In = z.infer<typeof PollMessagesInput>
type Out = z.infer<typeof PollMessagesOutput>

/**
 * `mail.messages.poll`: the engine's poll of the inbox. Reads the mail that arrived from `from` on (the mailbox's `since`; an IMAP search is by
 * date, so the window edge may repeat a message: the Message-ID key dedupes), keeps what arrived up to `to`, and answers the rows under the
 * Message-ID. The sender address is lower-cased: it names the contact.
 */
export class PollMessages implements Operation<typeof PollMessagesInput, typeof PollMessagesOutput> {
    readonly key = "mail.messages.poll"
    readonly version = 1
    readonly title = { vi: "Nhận thư mới", en: "Poll for new mail" }
    readonly input = PollMessagesInput
    readonly output = PollMessagesOutput
    readonly semantics = { mutates: false }
    readonly provider = "mail"
    readonly http = false
    readonly refusals = [] as const

    run(input: In, reach: OperationReach): Out {
        const read = reach.mail?.fetch({ since: input.from, limit: input.limit }) ?? []
        const until = Date.parse(input.to)
        const inWindow = read.filter((message) => Date.parse(message.receivedAt) <= until)
        const items = inWindow.map((message) => ({
            key: message.messageId,
            at: message.receivedAt,
            value: {
                messageId: message.messageId,
                fromAddress: message.from.address.toLowerCase(),
                ...(message.from.name === undefined ? {} : { fromName: message.from.name }),
                to: message.to.map((address) => address.address),
                subject: message.subject,
                text: message.text,
                receivedAt: message.receivedAt,
                ...(message.inReplyTo === undefined ? {} : { inReplyTo: message.inReplyTo }),
                ...(message.references === undefined ? {} : { references: [...message.references] }),
                ...(message.cc === undefined ? {} : { cc: message.cc.map((address) => address.address) }),
                ...(message.html === undefined ? {} : { html: message.html }),
                ...(message.attachments === undefined ? {} : { attachments: message.attachments.map((file) => ({ name: file.name, mime: file.mime, bytes: file.bytes, part: file.part })) }),
            },
        }))
        const oldest = read[0]?.receivedAt
        return { items, fetched: read.length, ...(oldest === undefined ? {} : { oldestAt: oldest }) }
    }
}
