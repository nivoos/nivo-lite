import type { MailFields } from "./mail.provider.cell.ts"
import type { ProviderPreset } from "@starci/nivoos-sdk"
import type { z } from "zod"

type Preset = ProviderPreset<keyof z.infer<typeof MailFields> & string>

const GMAIL_DOCS = { title: "Gmail: IMAP and SMTP settings (Google Workspace developers)", url: "https://developers.google.com/workspace/gmail/imap/imap-smtp" } as const
const GMAIL_SUPPORT = { title: "Gmail Help: add Gmail to another email client", url: "https://support.google.com/mail/answer/7126229" } as const
const ZOHO_DOCS = { title: "Zoho Mail: IMAP access and server details", url: "https://www.zoho.com/mail/help/imap-access.html" } as const
const OUTLOOK_DOCS = { title: "Microsoft: POP, IMAP and SMTP settings for Outlook.com", url: "https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040" } as const
const M365_SMTP_DOCS = { title: "Microsoft Learn: client SMTP submission with Microsoft 365", url: "https://learn.microsoft.com/en-us/exchange/mail-flow-best-practices/how-to-set-up-a-multifunction-device-or-application-to-send-email-using-microsoft-365-or-office-365" } as const
const M365_SMTP_AUTH_DOCS = { title: "Microsoft Learn: enable or disable SMTP AUTH in Exchange Online", url: "https://learn.microsoft.com/en-us/exchange/clients-and-mobile-in-exchange-online/authenticated-client-smtp-submission" } as const
const TINO_OUTLOOK = { title: "Wiki Tino: set up a mail account in Outlook", url: "https://tino.vn/blog/docs/thiet-lap-tai-khoan-mail-len-outlook/" } as const
const TINO_THUNDERBIRD = { title: "Wiki Tino: set up email in Thunderbird", url: "https://tino.vn/blog/docs/cau-hinh-email-cho-thunderbird/" } as const
const TINO_ANDROID = { title: "Tino: sign in to TinoMail in the Android Mail app", url: "https://tino.vn/blog/dang-nhap-tinomail-vao-ung-dung-mail-tren-android/" } as const

/**
 * The presets of the `mail` provider: a vendor's prefilled IMAP / SMTP settings and its setup guide. Every host, port and step below is what the vendor's
 * own page (cited in `docs`, read 2026-11-16) states; what it does not state is left empty and said in `notes`. `secure` is "tls" (encrypted): the
 * mailbox adapter uses implicit TLS on the ports 465 and 993 and STARTTLS on 587 and 143.
 */
export const MAIL_PRESETS: ReadonlyArray<Preset> = [
    {
        key: "tino",
        title: { vi: "Tino (TinoMail / email hosting)", en: "Tino (TinoMail / email hosting)" },
        description: { vi: "Hộp thư của Tino: máy chủ thư theo tên miền của bạn.", en: "A Tino mailbox: the mail server is named after your own domain." },
        values: { imapPort: "993", smtpPort: "465", secure: "tls" },
        guide: [
            {
                title: { vi: "Lấy thông tin máy chủ trong trang quản trị", en: "Get the server details from the admin panel" },
                body: {
                    vi: "Tino hướng dẫn xem thông tin đăng nhập và máy chủ ở mục IMAP/SMTP trong trang quản trị TinoMail (với email cPanel: nút Connect Devices của từng hộp thư).",
                    en: "Tino says to read the login and server details under IMAP/SMTP in the TinoMail admin panel (for cPanel email: the Connect Devices button of each mailbox).",
                },
                url: "https://tino.vn/blog/cau-hinh-va-su-dung-tinomail/",
            },
            {
                title: { vi: "Điền máy chủ thư của tên miền bạn", en: "Enter your domain's mail server" },
                body: {
                    vi: "Hướng dẫn Outlook của Tino dùng mail.<tên miền của bạn> cho cả thư đến lẫn thư đi, IMAP cổng 993 và SMTP cổng 465 (SSL/TLS); hướng dẫn Thunderbird dùng mail.tinohost.com làm máy chủ thư đến. Chép đúng giá trị trong trang quản trị của bạn.",
                    en: "Tino's Outlook guide uses mail.<your domain> for both incoming and outgoing mail, IMAP on port 993 and SMTP on port 465 (SSL/TLS); its Thunderbird guide uses mail.tinohost.com as the incoming server. Copy the exact values from your own admin panel.",
                },
                url: "https://tino.vn/blog/docs/thiet-lap-tai-khoan-mail-len-outlook/",
            },
            {
                title: { vi: "Đăng nhập bằng địa chỉ thư đầy đủ", en: "Sign in with the full address" },
                body: { vi: "Tên đăng nhập là địa chỉ thư đầy đủ, mật khẩu là mật khẩu hộp thư.", en: "The user name is the full mail address and the password is the mailbox password." },
            },
        ],
        docs: [TINO_OUTLOOK, TINO_THUNDERBIRD, TINO_ANDROID],
        notes: {
            vi: "Tino không công bố một máy chủ chung cho mọi khách hàng nên NIVO không điền sẵn máy chủ. Hai hướng dẫn của Tino cho SMTP cổng 465 với mức bảo mật khác nhau (hướng dẫn Android ghi STARTTLS, hướng dẫn Outlook ghi SSL/TLS); NIVO dùng TLS ngầm định ở cổng 465. Nếu không gửi được, dùng đúng giá trị trong trang quản trị của bạn.",
            en: "Tino documents no single server for every customer, so NIVO prefills no host. Tino's own guides disagree on SMTP port 465 security (the Android guide says STARTTLS, the Outlook guide SSL/TLS); NIVO uses implicit TLS on port 465. If sending fails, use the exact values from your admin panel.",
        },
    },
    {
        key: "gmail",
        title: { vi: "Gmail", en: "Gmail" },
        description: { vi: "Gmail cá nhân hoặc Google Workspace.", en: "Personal Gmail or Google Workspace." },
        values: { imapHost: "imap.gmail.com", imapPort: "993", smtpHost: "smtp.gmail.com", smtpPort: "465", secure: "tls" },
        guide: [
            {
                title: { vi: "IMAP luôn bật", en: "IMAP is always on" },
                body: { vi: "Google ghi rằng từ tháng 1/2025 IMAP luôn bật với tài khoản Google cá nhân, không có công tắc để bật hay tắt.", en: "Google states that since January 2025 IMAP is always on for personal Google accounts: there is no switch." },
                url: "https://support.google.com/mail/answer/7126229",
            },
            {
                title: { vi: "Tạo mật khẩu ứng dụng", en: "Create an app password" },
                body: {
                    vi: "Bật xác minh 2 bước cho tài khoản rồi tạo mật khẩu ứng dụng và dán vào ô Mật khẩu. Google ghi mật khẩu ứng dụng chỉ có khi dùng xác minh 2 bước và \"không được khuyến nghị\" vì đa số trường hợp không cần.",
                    en: "Turn on 2-Step Verification, create an app password and paste it in Password. Google states app passwords exist only with 2-Step Verification and are \"not recommended\" because they are unnecessary in most cases.",
                },
                url: "https://support.google.com/mail/answer/7126229",
            },
            {
                title: { vi: "Máy chủ và cổng", en: "Servers and ports" },
                body: { vi: "IMAP imap.gmail.com cổng 993 (TLS); SMTP smtp.gmail.com cổng 465 (TLS ngầm định) hoặc 587 (STARTTLS).", en: "IMAP imap.gmail.com port 993 (TLS); SMTP smtp.gmail.com port 465 (implicit TLS) or 587 (STARTTLS)." },
                url: "https://developers.google.com/workspace/gmail/imap/imap-smtp",
            },
        ],
        docs: [GMAIL_DOCS, GMAIL_SUPPORT],
        notes: {
            vi: "Google ghi các máy chủ này hỗ trợ OAuth 2.0 (XOAUTH2); hộp thư của NIVO đăng nhập bằng mật khẩu. Trang của Google không nói rõ mật khẩu ứng dụng có được chấp nhận ở mọi loại tài khoản hay không (Google Workspace do quản trị viên quyết định): nếu đăng nhập bị từ chối, hãy hỏi quản trị viên.",
            en: "Google states these servers support OAuth 2.0 (XOAUTH2); the NIVO mailbox signs in with a password. Google's pages do not say that an app password is accepted on every account type (a Google Workspace admin decides): if sign-in is refused, ask your admin.",
        },
    },
    {
        key: "zoho",
        title: { vi: "Zoho Mail (cá nhân / gói miễn phí)", en: "Zoho Mail (personal / free)" },
        values: { imapHost: "imap.zoho.com", imapPort: "993", smtpHost: "smtp.zoho.com", smtpPort: "465", secure: "tls" },
        guide: [
            {
                title: { vi: "Bật truy cập IMAP", en: "Turn IMAP access on" },
                body: { vi: "Trong Zoho Mail: Cài đặt, Tài khoản thư, chọn địa chỉ chính, tại mục IMAP tích Truy cập IMAP rồi Lưu.", en: "In Zoho Mail: Settings, Mail Accounts, click your primary address, tick IMAP Access in the IMAP section, then Save." },
                url: "https://www.zoho.com/mail/help/imap-access.html",
            },
            {
                title: { vi: "Mật khẩu ứng dụng", en: "App-specific password" },
                body: { vi: "Nếu bật xác thực hai lớp (hoặc đăng nhập SAML), tạo mật khẩu riêng cho ứng dụng và dùng nó làm mật khẩu.", en: "If two-factor authentication (or SAML login) is on, generate an app-specific password and use it as the password." },
                url: "https://www.zoho.com/mail/help/imap-access.html",
            },
            {
                title: { vi: "Máy chủ và cổng", en: "Servers and ports" },
                body: { vi: "IMAP imap.zoho.com cổng 993 (SSL); SMTP smtp.zoho.com cổng 465 (SSL) hoặc 587 (TLS). Tên đăng nhập là địa chỉ đầy đủ.", en: "IMAP imap.zoho.com port 993 (SSL); SMTP smtp.zoho.com port 465 (SSL) or 587 (TLS). The user name is the full address." },
                url: "https://www.zoho.com/mail/help/imap-access.html",
            },
        ],
        docs: [ZOHO_DOCS],
        notes: {
            vi: "Zoho ghi IMAP không có ở tài khoản miễn phí mới, và máy chủ thật của bạn nằm ở mục Server Configuration Details trong tài khoản Zoho (trang không liệt kê máy chủ theo khu vực dữ liệu). Gói trả phí dùng tên miền riêng: chọn \"Zoho Mail (gói trả phí)\".",
            en: "Zoho states IMAP is not available on new free-plan accounts, and your real servers are under Server Configuration Details in your Zoho account (the page lists no per-data-centre hosts). Paid plans with your own domain: pick \"Zoho Mail (paid)\".",
        },
    },
    {
        key: "zoho-paid",
        title: { vi: "Zoho Mail (gói trả phí)", en: "Zoho Mail (paid)" },
        values: { imapHost: "imappro.zoho.com", imapPort: "993", smtpHost: "smtppro.zoho.com", smtpPort: "465", secure: "tls" },
        guide: [
            {
                title: { vi: "Bật truy cập IMAP", en: "Turn IMAP access on" },
                body: { vi: "Như gói cá nhân; với tài khoản tổ chức, hỏi quản trị viên xem có cho phép IMAP không.", en: "As for the personal plan; on an organisation account, ask the admin whether IMAP is allowed." },
                url: "https://www.zoho.com/mail/help/imap-access.html",
            },
            {
                title: { vi: "Máy chủ và cổng", en: "Servers and ports" },
                body: { vi: "IMAP imappro.zoho.com cổng 993 (SSL); SMTP smtppro.zoho.com cổng 465 (SSL) hoặc 587 (TLS). Tên đăng nhập là you@tên-miền-của-bạn.", en: "IMAP imappro.zoho.com port 993 (SSL); SMTP smtppro.zoho.com port 465 (SSL) or 587 (TLS). The user name is you@your-domain." },
                url: "https://www.zoho.com/mail/help/imap-access.html",
            },
        ],
        docs: [ZOHO_DOCS],
        notes: { vi: "Máy chủ theo khu vực dữ liệu không được trang của Zoho liệt kê: xem Server Configuration Details trong tài khoản của bạn.", en: "Per-data-centre servers are not listed on Zoho's page: see Server Configuration Details in your account." },
    },
    {
        key: "outlook",
        title: { vi: "Microsoft 365 / Outlook", en: "Microsoft 365 / Outlook" },
        description: { vi: "Hộp thư Exchange Online (Microsoft 365) hoặc Outlook.com.", en: "An Exchange Online (Microsoft 365) or Outlook.com mailbox." },
        values: { imapHost: "outlook.office365.com", imapPort: "993", smtpHost: "smtp.office365.com", smtpPort: "587", secure: "tls" },
        guide: [
            {
                title: { vi: "Bật IMAP", en: "Turn IMAP on" },
                body: { vi: "Outlook.com: Cài đặt, Thư, Chuyển tiếp và IMAP, bật \"Cho phép thiết bị và ứng dụng dùng IMAP\" rồi Lưu (Microsoft ghi POP/IMAP tắt theo mặc định).", en: "Outlook.com: Settings, Mail, Forwarding and IMAP, turn on \"Let devices and apps use IMAP\" and Save (Microsoft states POP and IMAP are off by default)." },
                url: "https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040",
            },
            {
                title: { vi: "Microsoft 365: bật Authenticated SMTP", en: "Microsoft 365: turn Authenticated SMTP on" },
                body: { vi: "Quản trị viên bật \"Authenticated SMTP\" cho hộp thư (Trung tâm quản trị, Người dùng, Thư, Quản lý ứng dụng email). Microsoft ghi SMTP AUTH đã tắt với tổ chức tạo sau tháng 1/2020 và khi bật security defaults.", en: "An admin turns \"Authenticated SMTP\" on for the mailbox (admin centre, Users, Mail, Manage email apps). Microsoft states SMTP AUTH is off for organisations created after January 2020 and while security defaults is on." },
                url: "https://learn.microsoft.com/en-us/exchange/clients-and-mobile-in-exchange-online/authenticated-client-smtp-submission",
            },
            {
                title: { vi: "Máy chủ và cổng", en: "Servers and ports" },
                body: { vi: "IMAP outlook.office365.com cổng 993 (SSL/TLS). SMTP Microsoft 365: smtp.office365.com cổng 587 (STARTTLS). Outlook.com cá nhân: smtp-mail.outlook.com cổng 587.", en: "IMAP outlook.office365.com port 993 (SSL/TLS). Microsoft 365 SMTP: smtp.office365.com port 587 (STARTTLS). Personal Outlook.com: smtp-mail.outlook.com port 587." },
                url: "https://learn.microsoft.com/en-us/exchange/mail-flow-best-practices/how-to-set-up-a-multifunction-device-or-application-to-send-email-using-microsoft-365-or-office-365",
            },
        ],
        docs: [OUTLOOK_DOCS, M365_SMTP_DOCS, M365_SMTP_AUTH_DOCS],
        notes: {
            vi: "Hạn chế quan trọng: Microsoft yêu cầu OAuth2 (Modern Auth) cho Outlook.com và ghi SMTP AUTH dùng Basic (tên + mật khẩu) trên Exchange Online đã có lịch ngừng hỗ trợ; hộp thư của NIVO đăng nhập bằng mật khẩu nên chỉ chạy khi tổ chức của bạn vẫn cho phép Basic cho SMTP và IMAP. Microsoft không nêu SMTP cổng 465 là dùng được; dùng 587.",
            en: "Important limit: Microsoft requires OAuth2 (Modern Auth) for Outlook.com and states Basic authentication for SMTP AUTH on Exchange Online is scheduled for deprecation; the NIVO mailbox signs in with a password, so it works only while your organisation still allows Basic for SMTP and IMAP. Microsoft says port 465 is not supported for client SMTP submission; use 587.",
        },
    },
]
