import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

const Address = z.strictObject({ address: z.string().min(3), name: z.string().optional() })

export const SendMessageInput = z.strictObject({
    to: z.array(Address).min(1).max(50),
    cc: z.array(Address).max(50).optional(),
    subject: z.string().min(1).max(998),
    text: z.string().optional(),
    html: z.string().optional(),
    /** The Message-ID of the mail this one answers (threading). */
    inReplyTo: z.string().min(1).optional(),
    /** Files to attach: the bytes as base64 (at most 10 files, 10 MB together). */
    attachments: z.array(z.strictObject({ filename: z.string().min(1).max(150), contentType: z.string().min(3), base64: z.string() })).max(10).optional(),
})
export const SendMessageOutput = z.strictObject({ messageId: z.string().min(1) })

type Address = z.infer<typeof Address>

/** An address as the primitive takes it: no member holds `undefined`. */
const addressOf = (entry: Address): { readonly address: string; readonly name?: string } => (entry.name === undefined ? { address: entry.address } : { address: entry.address, name: entry.name })

type In = z.infer<typeof SendMessageInput>
type Out = z.infer<typeof SendMessageOutput>

/**
 * `mail.messages.send`: sends one mail through the account's SMTP server and answers the Message-ID the server gave it. A body is required
 * (`text`, `html` or both): without one the operation refuses `empty_message`, which a node can branch on. The mail primitive takes no blind copy
 * from here, so none is offered.
 */
export class MailSendMessage implements Operation<typeof SendMessageInput, typeof SendMessageOutput> {
    readonly key = "mail.messages.send"
    readonly version = 1
    readonly title = { vi: "Gửi thư", en: "Send a mail" }
    readonly input = SendMessageInput
    readonly output = SendMessageOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "mail"
    readonly http = false
    readonly refusals = ["empty_message"] as const

    run(input: In, reach: OperationReach<never, "empty_message">): Out {
        const hasText = input.text !== undefined && input.text !== ""
        const hasHtml = input.html !== undefined && input.html !== ""
        if (!hasText && !hasHtml) reach.refuse("empty_message")
        const sent = reach.mail?.send({
            to: input.to.map(addressOf),
            ...(input.cc === undefined ? {} : { cc: input.cc.map(addressOf) }),
            subject: input.subject,
            ...(input.text === undefined ? {} : { text: input.text }),
            ...(input.html === undefined ? {} : { html: input.html }),
            ...(input.inReplyTo === undefined ? {} : { inReplyTo: input.inReplyTo }),
            ...(input.attachments === undefined ? {} : { attachments: input.attachments.map((file) => ({ filename: file.filename, contentType: file.contentType, base64: file.base64 })) }),
        })
        if (sent === undefined) return reach.unknown("no_mail_primitive")
        return { messageId: sent.messageId }
    }
}
