# mail

Any mailbox that speaks SMTP (send) and IMAP (read). The engine speaks both protocols with the account's settings (`transport: "mail"`, the mail
primitive); the cells only pass a message or a fetch request and never hold a socket or the password.

| Cell | Kind | What |
| --- | --- | --- |
| `mail.provider.cell.ts` (`mail`) | provider | account fields, `connectTest = mail.inbox.check`, poll of `mail.messages.poll`, data type `mail.message` |
| `check-inbox.cell.ts` (`mail.inbox.check`) | operation, read | the connect test: opens the inbox, one message at most |
| `send-message.cell.ts` (`mail.messages.send`) | operation, act | sends one mail; answers the Message-ID the server gave; declares the refusal `empty_message` (no text and no html) |
| `poll-messages.cell.ts` (`mail.messages.poll`) | operation, read | the engine's poll over a window `{ from, to, limit }`; answers rows under the Message-ID |
| `message-received.cell.ts` (`mail.message.received`) | trigger (poll, on by default) | one new mail = one event, key = Message-ID, subject `contact:<sender address lower-cased>` |

## Account fields
`smtpHost`, `smtpPort`, `imapHost`, `imapPort`, `user` (login and sender), `password` (secret), `secure` (`tls` | `starttls` | `none`). There is no
`base`, no webhook and no OAuth way. The person finds the values in the mailbox provider's own help page; they differ per provider and NIVO guesses none.

## Vendor facts (and what is NOT known)
- Ports and security. RFC 8314 section 3.3: implicit TLS submission ("submissions") defaults to port 465 and STARTTLS submission to port 587, both
  acceptable; section 3.2: IMAP over implicit TLS ("imaps") defaults to port 993. https://www.rfc-editor.org/rfc/rfc8314 (fetched 2026-11-16).
  The form help and placeholders (587 / 993) come from this; the person's provider decides the real ones.
- Message-ID. RFC 5322 section 3.6.4: the Message-ID "MUST be a globally unique identifier for a message", written `<left@right>`.
  https://www.rfc-editor.org/rfc/rfc5322 (fetched 2026-11-16). This is why it is the key of a kept row and the event key; the engine dedupes a
  poll window that overlaps the last one on it.
- The mail primitive (engine, `be/src/modules/domain/providers/provider-mail.service.ts`): SMTP through `@starci/mail`, IMAP through `imapflow`;
  carries a recipient list, subject, text, html, one Reply-To and an `inReplyTo` id; a copy-to-self, blind copy or attachment is not offered here.
- NOT known / not verified: how each mailbox provider (Gmail, Outlook, Zoho ...) names its servers, whether it needs an app password or has turned
  off password login, and its send / fetch limits. None is cited, so none is claimed; a provider that only allows OAuth for mail is not covered by
  this provider (it would need an `oauth2` way and an XOAUTH2 mail port, which the primitive does not have).
- `inReplyTo` threading: the SMTP adapter is told the Message-ID being answered; whether a given server keeps the thread is the receiver's client.

## How inbound works
No webhook. `provider.poll` makes the engine run `mail.messages.poll` per account every minute (five when a webhook also delivers, which a mailbox
never does): `reach.mail.fetch({ since: from, limit })` over the window, rows kept oldest first under the Message-ID. The IMAP search is by date
(the primitive's `since`), so a window edge can repeat a mail: the key dedupes it. `receivedAt` is the server's arrival time; a mail that arrives
with an earlier INTERNALDATE than the window start is missed (the window overlaps the last pass by the engine's `overlapMs` to soften this).
The sender address is lower-cased in the row; the subject of the event is that address.

## Needs from the engine (not in this folder)
- `Provider.poll` (`ProviderPollWay`) in the SDK (`packages/nivoos-sdk/src/cells.ts`, build.ts): the SDK wrote `poll: null` for every provider, so
  a poll could not be authored although the engine reads it. The lane commit "sdk: provider poll" adds it.
- Registration in provider-templates.package.ts (the coordinator).

## Logo
A neutral monogram (`M`): mail is a protocol, not a brand. `mark: "monogram"`.

## Tests
`be/src/tests/integration/providers/mail.integration-spec.ts` against the fake mail adapter; the recorded mailbox is
`be/src/tests/fixtures/e2e/providers/mail/inbox.ts`. There is no HTTP exchange and no signed webhook to record, so the signed / wrong-signature
cases do not apply.
