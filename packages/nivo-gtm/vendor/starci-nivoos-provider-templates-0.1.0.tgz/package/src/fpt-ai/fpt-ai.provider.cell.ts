import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"

/** What the platform account of FPT.AI holds: the API key, from the instance's custody env `NIVO_MEDIA_FPT_TTS_API_KEY` (never typed in a workspace). */
export const FptAiFields = z.strictObject({
    /** The public name of the account (the identity): the instance writes "platform". */
    account: z.string().min(1),
    apiKey: z.string().min(1),
})

export type FptAiAccount = z.infer<typeof FptAiFields>

/** `fpt-ai`: Vietnamese text to speech for `voice.speak`. A platform account: NIVO's key, metered in NIVO credit. The key travels in the header `api_key` (https://docs.fpt.ai/docs/en/speech/api/text-to-speech.html). See README.md. */
export class FptAiProvider implements Provider<typeof FptAiFields, z.ZodObject<{}>, {}> {
    readonly key = "fpt-ai"
    readonly version = 1
    readonly title = { vi: "FPT.AI", en: "FPT.AI" }
    readonly description = {
        vi: "Đọc văn bản thành giọng nói tiếng Việt (giọng Bắc, Trung, Nam).",
        en: "Reads text aloud in Vietnamese voices (north, centre, south).",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = FptAiFields
    readonly secrets = ["apiKey"] as const
    readonly form = {
        account: { label: { vi: "Tên tài khoản", en: "Account name" }, help: { vi: "Tên hiển thị của tài khoản nền tảng.", en: "The display name of the platform account." }, kind: "text", order: 0 },
        apiKey: { label: { vi: "Khoá API", en: "API key" }, help: { vi: "Do nền tảng giữ; không nhập trong không gian làm việc.", en: "Held by the platform; never entered in a workspace." }, kind: "secret", order: 1 },
    } as const
    readonly identityField = "account"
    readonly kind = "base"
    readonly accountOwner = "platform"
    readonly base = { fixed: "https://api.fpt.ai" }
    readonly auth = { scheme: "header", name: "api_key", secretField: "apiKey" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly dataTypes = {}
}
