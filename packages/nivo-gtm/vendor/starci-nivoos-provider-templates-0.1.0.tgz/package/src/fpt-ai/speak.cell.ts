import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { VoiceSpeak, VoiceSpeakInput } from "../media/capabilities/voice-speak.capability.ts"
import { mediaRefusals } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { member } from "../shared/json.ts"
import type { FptAiAccount } from "./fpt-ai.provider.cell.ts"

/** The native voices of FPT.AI (README): the free `voice` of the capability narrowed to them. */
export const FptVoices = z.enum(["banmai", "thuminh", "leminh", "myan", "giahuy", "lannhi", "linhsan"])

export const SpeakInput = VoiceSpeakInput.extend({ text: z.string().min(3).max(5000), voice: FptVoices })
export const SpeakOutput = z.strictObject({
    /** The link the file appears at in 5 s to 2 min (`job.vendorJobId` and `job.outputs`). */
    async: z.string().min(1),
    request_id: z.string().min(1),
})

type In = z.infer<typeof SpeakInput>
type Out = z.infer<typeof SpeakOutput>

/**
 * `fpt-ai.tts.speak`: `POST /hmi/tts/v5`, the raw text as the body and `voice`, `speed`, `format` as headers (where `speed` and `format` go is UNVERIFIED, README). The vendor answers a link and the file
 * comes later: a job whose status read is `fpt-ai.tts.file`. FPT speaks Vietnamese only.
 */
export class FptAiTtsSpeak implements Operation<typeof SpeakInput, typeof SpeakOutput, FptAiAccount, MediaRefusal> {
    readonly key = "fpt-ai.tts.speak"
    readonly version = 1
    readonly title = { vi: "Đọc thành giọng nói (FPT.AI)", en: "Speak text (FPT.AI)" }
    readonly input = SpeakInput
    readonly output = SpeakOutput
    // 0.0000131 USD per character is DERIVED from the dearest VND pack at an example rate (README); the usdToVnd setting of the owner prices the credits
    readonly semantics = { mutates: true, metered: { usage: "units", price: { usdPerUnit: 0.0000131 }, estimate: { units: { textLength: "text", per: 1 } } } } as const
    readonly provider = "fpt-ai"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly implements = VoiceSpeak
    readonly refusals = mediaRefusals
    readonly job = {
        status: "fpt-ai.tts.file",
        vendorJobId: "async",
        state: { path: "state", pending: ["pending"], done: ["done"], failed: ["failed"] },
        outputs: { path: "async", as: "url" },
        poll: { firstAfterMs: 5_000, everyMs: 5_000, maxEveryMs: 20_000, factor: 1.5 },
        timeoutMs: 300_000,
    } as const

    run(input: In, reach: OperationReach<FptAiAccount, MediaRefusal>): Out {
        if (input.language === "en") return reach.refuse("input_invalid", { why: "fpt_vietnamese_only" })
        const response = reach.http({
            method: "POST",
            path: "/hmi/tts/v5",
            headers: { "content-type": "text/plain", voice: input.voice, speed: String(input.speed ?? 0), format: input.format ?? "mp3" },
            body: input.text,
        })
        const link = member(response.json, "async")
        const requestId = member(response.json, "request_id")
        if (response.status !== 200 || member(response.json, "error") !== 0 || typeof link !== "string" || link === "" || typeof requestId !== "string") return reach.byStatus()
        return { async: link, request_id: requestId }
    }
}
