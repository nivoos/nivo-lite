# fpt-ai

FPT.AI text to speech for `voice.speak` (spec A section 1.6 and P4, lane gm-p-voice). Page read 2026-11-18: https://docs.fpt.ai/docs/en/speech/api/text-to-speech.html. The pricing page (https://docs.fpt.ai/docs/en/speech/documentation/tts-pricing/) figures come from spec A and were not re-read. Anything not on a cited page is marked UNVERIFIED.

## What it is
- Provider `fpt-ai`, `accountOwner: "platform"`, base `https://api.fpt.ai`. Account field `apiKey` (secret), from the instance custody variable for the FPT TTS key. A workspace never sees it. No real key was entered.
- `fpt-ai.tts.speak` implements `voice.speak` and is the submit of a job. `fpt-ai.tts.file` is its status read. Neither loops.
- Logo: neutral monogram (brand terms not checked).

## Request (resolved from the page)
- `POST /hmi/tts/v5`. The body is the raw text (3 to 5000 characters), not JSON.
- Headers: `api_key` (underscore, the spelling of the page: declared as `auth: header, name api_key`), `voice`, `callback_url` (optional).
- `speed` (integer -3..3, default 0) and `format` (`mp3` default, `wav`): the page lists them as parameters and shows no placement. UNVERIFIED: sent as headers `speed` and `format`, like `voice`. TODO: confirm with a real call.
- Voices (a static list, also the input enum): `banmai` (north, f), `thuminh` (north, f), `leminh` (north, m), `myan` (centre, f), `giahuy` (centre, m), `lannhi` (south, f), `linhsan` (south, f). Gender and region are from spec A, not the page. FPT voices speak Vietnamese only: `language: "en"` is refused as `input_invalid`.

## Answer
`{ error, async, request_id, message }`. `error: 0` is success; any other value is a failure and the page lists no codes (the operation ends `byStatus`). `async` is the link to the file, which appears 5 s to 2 min later. There is no status endpoint.

## Job declaration
- `job.status = fpt-ai.tts.file`, `vendorJobId = async`, poll first at 5 s, then every 5 s growing x1.5 up to 20 s, deadline 5 min.
- The status read asks the link itself: 200 is done, 404 is pending (`wire.ok = [200, 404]`). `failed` is declared and never produced; the deadline ends a job whose file never appears (`job_timeout`).
- `job.outputs = { path: "async", as: "url" }`.
- The callback (`callback_url` nudge, unsigned, `{ message: <link>, success }`) is NOT declared: a job `callback.inputMember` must be a member of the submit input and `voice.speak` has none. Polling alone covers it. Revisit with the engine nudge door.
- Usage: the answer reports no length, so the engine bills the estimate (characters of `text`).

## Gaps the engine owns (reported)
1. `HttpRequest.method` has no `HEAD`; the status read uses `GET`, which downloads the audio. Proposed: add `HEAD`.
2. `HttpRequest.path` is a path under the provider base, never a URL. The async link is on another host (UNVERIFIED: the page shows no example link). The status read sends only the path of the link, so the engine must let a provider declare the file host or route an absolute `vendorJobId`. Until then the pending-to-done sequence is proven only at the `http` port.
3. A raw text body: the operation passes the text as the `body` string with `content-type: text/plain`. UNVERIFIED that the engine sends a string body unquoted.

## Price
Unit `characters`. Free: 100,000 characters a month. Packs (spec A, VND): 500,000 VND for 1.5M characters down to 5,000,000 VND for 27M, about 333 to 185 VND per 1,000 characters. `usdPerUnit` is DERIVED: 333 VND / 1000 / 25,500 (an example rate; the `usdToVnd` setting of the owner is the real one) = 0.0000131 USD per character, the dearest tier so a hold never falls short.

## Errors
The page documents none beyond `error != 0`. Nothing is mapped; a 401 or 429 falls to the engine table. TODO with a real key.

## Recorded exchanges
No real key: `be/src/tests/fixtures/e2e/providers/fpt-ai/` is built from the documented shapes and marked `documented`: a success submit, a refusal (error not 0), and the pending (404) then done (200) status sequence.
