import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import type { FptAiAccount } from "./fpt-ai.provider.cell.ts"

export const FileInput = z.strictObject({ vendorJobId: z.string().min(1) })
export const FileOutput = z.strictObject({ state: z.enum(["pending", "done", "failed"]) })

type Refusal = "auth_failed"

/** The path of an `https://host/path` link (the part the http reach takes); the link itself when it has no host. */
const pathOf = (link: string): string => link.replace(/^https?:\/\/[^/]+/u, "")

/**
 * `fpt-ai.tts.file`: the status read of `fpt-ai.tts.speak`. FPT has no status endpoint, so it asks the async link itself: 200 is done, 404 is pending (`wire.ok` lets 404 through as data). Two gaps are the
 * engine's, not this operation's (README): the http reach has no HEAD (GET is used) and takes a path under the base, not the host of the link.
 */
export class FptAiTtsFile implements Operation<typeof FileInput, typeof FileOutput, FptAiAccount, Refusal> {
    readonly key = "fpt-ai.tts.file"
    readonly version = 1
    readonly title = { vi: "Trạng thái giọng nói (FPT.AI)", en: "Speech file status (FPT.AI)" }
    readonly input = FileInput
    readonly output = FileOutput
    readonly semantics = { mutates: false }
    readonly provider = "fpt-ai"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { ok: [200, 404] } as const

    run(input: z.infer<typeof FileInput>, reach: OperationReach<FptAiAccount, Refusal>): z.infer<typeof FileOutput> {
        const answer = reach.http({ method: "GET", path: pathOf(input.vendorJobId) })
        return { state: answer.status === 200 ? "done" : "pending" }
    }
}
