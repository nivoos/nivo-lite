// The SePay provider alone: the entry the integration spec builds (`loadProject`) so a case deploys exactly this folder. The shipped package lists these cells in provider-templates.package.ts.
import type { Package } from "@starci/nivoos-sdk"
import { FindTransaction } from "./find-transaction.cell.ts"
import { ListTransactions } from "./list-transactions.cell.ts"
import { SepayPaymentPaid } from "./payment-paid.cell.ts"
import { SepayProvider } from "./sepay.provider.cell.ts"
import { TransferReceived } from "./transfer-received.cell.ts"

export default {
    package: { key: "e2e-sepay", version: "1.0.0", author: "e2e" },
    cells: [SepayProvider, FindTransaction, ListTransactions, SepayPaymentPaid, TransferReceived],
    agents: [],
} satisfies Package
