import { z } from "zod"
import type { JsonValue, Operation, OperationReach } from "@starci/nivoos-sdk"

export const TransactionOut = z.strictObject({
    transferId: z.string(),
    accountNumber: z.string(),
    transactionDate: z.string(),
    amountIn: z.string(),
    amountOut: z.string(),
    content: z.string(),
    referenceNumber: z.string(),
})
export const ListTransactionsInput = z.strictObject({
    sinceId: z.string().min(1).optional(),
    referenceNumber: z.string().min(1).optional(),
    limit: z.number().int().min(1).max(5000).optional(),
})
export const ListTransactionsOutput = z.strictObject({ transactions: z.array(TransactionOut) })

type In = z.infer<typeof ListTransactionsInput>
type Out = z.infer<typeof ListTransactionsOutput>
type Tx = z.infer<typeof TransactionOut>

const str = (value: JsonValue | undefined): string => (typeof value === "string" ? value : typeof value === "number" ? String(value) : "")

/** The transactions of a SePay answer `{ transactions: [...] }`, mapped; null when the body is not that shape. */
export const transactionsOf = (json: JsonValue | undefined): Array<Tx> | null => {
    if (json === undefined || json === null || typeof json !== "object" || Array.isArray(json)) return null
    const list = (json as { readonly [member: string]: JsonValue })["transactions"]
    if (!Array.isArray(list)) return null
    const out: Array<Tx> = []
    for (const item of list) {
        if (item === null || typeof item !== "object" || Array.isArray(item)) return null
        const row = item as { readonly [member: string]: JsonValue }
        out.push({
            transferId: str(row["id"]),
            accountNumber: str(row["account_number"]),
            transactionDate: str(row["transaction_date"]),
            amountIn: str(row["amount_in"]),
            amountOut: str(row["amount_out"]),
            content: str(row["transaction_content"]),
            referenceNumber: str(row["reference_number"]),
        })
    }
    return out
}

/** `sepay.transactions.list`: reads `GET /userapi/transactions/list` for the account's bank account. The connect test of the provider. */
export class ListTransactions implements Operation<typeof ListTransactionsInput, typeof ListTransactionsOutput> {
    readonly key = "sepay.transactions.list"
    readonly version = 1
    readonly title = { vi: "Danh sách giao dịch", en: "List transactions" }
    readonly input = ListTransactionsInput
    readonly output = ListTransactionsOutput
    readonly semantics = { mutates: false }
    readonly provider = "sepay"
    readonly http = true
    readonly needs = ["apiToken", "accountNumber"] as const
    readonly refusals = [] as const

    run(input: In, reach: OperationReach): Out {
        const account = reach.account() as { readonly accountNumber?: string }
        const response = reach.http({
            method: "GET",
            path: "/userapi/transactions/list",
            query: {
                account_number: account.accountNumber ?? "",
                limit: input.limit ?? 20,
                ...(input.sinceId === undefined ? {} : { since_id: input.sinceId }),
                ...(input.referenceNumber === undefined ? {} : { reference_number: input.referenceNumber }),
            },
        })
        const transactions = response.status === 200 ? transactionsOf(response.json) : null
        if (transactions === null) return reach.byStatus()
        return { transactions }
    }
}
