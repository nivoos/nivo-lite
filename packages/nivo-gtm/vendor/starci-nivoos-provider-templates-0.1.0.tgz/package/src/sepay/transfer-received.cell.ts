import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SepayTransfer } from "./sepay.schemas.ts"

export const TransferEvent = z.strictObject({
    transferId: z.string().min(1),
    amount: z.number().nonnegative(),
    content: z.string(),
    accountNumber: z.string(),
    referenceCode: z.string().nullable(),
    transactionDate: z.string(),
})

type Row = z.infer<typeof SepayTransfer>
type Event = z.infer<typeof TransferEvent>

/** `sepay.transfer.received`: money IN to the watched account; one kept transfer is one event on the subject `transfer:<transferId>`, event id = SePay's transfer id. Money out starts nothing. Off until a person switches it on. */
export class TransferReceived implements Trigger<typeof SepayTransfer, typeof TransferEvent> {
    readonly key = "sepay.transfer.received"
    readonly version = 1
    readonly title = { vi: "Nhận tiền chuyển khoản", en: "Transfer received" }
    readonly row = SepayTransfer
    readonly event = TransferEvent
    readonly provider = "sepay"
    readonly dataType = { providerVersion: 1, key: "sepay.transfer" }
    readonly keyMember = "transferId"
    readonly subjectKind = "transfer"
    readonly subjectMember = "transferId"
    readonly vias = ["webhook"] as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Event> | null {
        if (row.direction !== "in") return null
        const { transferId, amount, content, accountNumber, referenceCode, transactionDate } = row
        return { id: transferId, data: { transferId, amount, content, accountNumber, referenceCode, transactionDate } }
    }
}
