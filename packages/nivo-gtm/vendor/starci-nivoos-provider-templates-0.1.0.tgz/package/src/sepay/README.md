# sepay

SePay (Vietnam bank-transfer notifications). Fetched 2026-11-16. Anything not on a cited page is marked UNKNOWN.

## What it is
- Provider `sepay`; account fields `accountNumber` (public, identity), `apiToken` (secret), `webhookSecret` (secret, generated in the form).
- Operations: `sepay.transactions.list` (read, the connect test), `sepay.transactions.find` (read; declares refusal `transaction_not_found`).
- Triggers (webhook, off until switched on): `sepay.transfer.received` (subject `transfer:<id>`), `sepay.payment.paid` (subject `order:<orderCode>`).
- Logo: neutral monogram (`mark: "monogram"`); SePay's brand terms on redistributing the mark were not checked.

## Webhook
- Auth: SePay offers HMAC-SHA256, API Key, OAuth 2.0, none; HMAC-SHA256 is marked "Recommended" (https://developer.sepay.vn/en/sepay-webhooks/xac-thuc). Only HMAC is offered here.
- Headers `X-SePay-Signature: sha256={hex}` and `X-SePay-Timestamp` (Unix seconds); HMAC-SHA256 over `{timestamp}.{raw_body}` with the webhook Secret Key; verify against the raw body (same page).
- The 5-minute timestamp tolerance is the page's sample-code behaviour (anti-replay), not a stated rule; we apply it.
- API Key way (not used): `Authorization: Apikey YOUR_API_KEY` (same page).
- Payload (https://docs.sepay.vn/tich-hop-webhooks.html, https://developer.sepay.vn/en/sepay-webhooks/bat-dau-nhanh): `id` (number; "use it to detect duplicates"), `gateway`, `transactionDate` ("2024-07-02 11:08:33"; time zone UNKNOWN), `accountNumber`, `subAccount`, `code` (payment code; null or a string), `content`, `transferType` (`"in"`; `"out"` implied, not defined on the pages), `transferAmount` (VND number), `accumulated`, `referenceCode`, `description`.
- Success response: HTTP 200 or 201 with `{"success": true}` (a 200 without it is logged as failed and not retried); SePay waits up to 30 s. Retries on connect failure/timeout (and non-2xx when enabled): up to 7, at 1, 1, 2, 3, 5, 8, 13 minutes (docs.sepay.vn/tich-hop-webhooks.html). The ack here is 200 `{success:true}`; a refused proof is 401.
- Source IPs SePay lists for allow-listing are on the same page; not enforced here (the engine's door has no IP check).
- Registration: `copy` (paste `https://<api>/webhooks/<accountId>` in my.sepay.vn). No registration API found.

## Dedupe
The row key is SePay's `id` (as text); a re-delivery, manual resend or a second webhook for the same transaction is one kept row (the engine dedupes on the key) and is still acknowledged 200.

## Order code (our rule, not a SePay fact) — `order-code.ts`
`sepay.payment.paid` takes an incoming transfer and names the order: the code is SePay's `code` field when it has the shape `[A-Z]{2,5}[0-9]{4,12}` (case-folded), otherwise the first token of `content` with that shape after upper-casing and splitting at every non-alphanumeric character. No token, no event (the transfer still raises `sepay.transfer.received`). The amount is carried as paid and never compared in the trigger. Example: `Thanh toan don DH123456 cam on` -> `DH123456`. SePay's own `code` recognition depends on the prefix set in the SePay account; that setting is UNKNOWN to us, so the memo rule is the fallback.

## API
- `GET https://my.sepay.vn/userapi/transactions/list`, params `account_number`, `transaction_date_min/max`, `since_id`, `limit` (up to 5000), `reference_number`, `amount_in`, `amount_out`; answer `{ status, error, messages, transactions: [{ id, bank_brand_name, account_number, transaction_date, amount_out, amount_in, accumulated, transaction_content, reference_number, code, sub_account, bank_account_id }] }`, amounts as decimal strings (https://docs.sepay.vn/api-giao-dich.html; the base URL is inferred from the endpoint URL there).
- Auth: `Authorization: Bearer API_TOKEN` (https://developer.sepay.vn/en/sepay-api/v1/tao-api-token).
- Rate limit 3 requests/second, 429 with `x-sepay-userapi-retry-after` (https://developer.sepay.vn/en/sepay-api/gioi-thieu); the engine's table treats 429 as transient.
- WARNING: those pages say API v1 is deprecated and recommend API v2 for new integrations. v2 endpoints were NOT read; moving to v2 is open. A 404 for the "unknown account" case is UNKNOWN, so `transaction_not_found` is only "the list is empty".
