import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { TransactionOut, transactionsOf } from "./list-transactions.cell.ts"

export const FindTransactionInput = z.strictObject({ referenceNumber: z.string().min(1) })
export const FindTransactionOutput = z.strictObject({ transaction: TransactionOut })

type In = z.infer<typeof FindTransactionInput>
type Out = z.infer<typeof FindTransactionOutput>

/** `sepay.transactions.find`: the one transaction with a bank reference number (list filtered by `reference_number`); declares `transaction_not_found` when SePay lists none. */
export class FindTransaction implements Operation<typeof FindTransactionInput, typeof FindTransactionOutput, never, "transaction_not_found"> {
    readonly key = "sepay.transactions.find"
    readonly version = 1
    readonly title = { vi: "Tìm giao dịch theo mã tham chiếu", en: "Find a transaction by reference" }
    readonly input = FindTransactionInput
    readonly output = FindTransactionOutput
    readonly semantics = { mutates: false }
    readonly provider = "sepay"
    readonly http = true
    readonly needs = ["apiToken", "accountNumber"] as const
    readonly refusals = ["transaction_not_found"] as const

    run(input: In, reach: OperationReach<never, "transaction_not_found">): Out {
        const account = reach.account() as { readonly accountNumber?: string }
        const response = reach.http({ method: "GET", path: "/userapi/transactions/list", query: { account_number: account.accountNumber ?? "", reference_number: input.referenceNumber, limit: 1 } })
        const transactions = response.status === 200 ? transactionsOf(response.json) : null
        if (transactions === null) return reach.byStatus()
        const first = transactions[0]
        if (first === undefined) return reach.refuse("transaction_not_found")
        return { transaction: first }
    }
}
