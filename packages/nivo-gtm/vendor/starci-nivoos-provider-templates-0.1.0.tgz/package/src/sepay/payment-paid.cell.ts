import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { orderCodeOf } from "./order-code.ts"
import { SepayTransfer } from "./sepay.provider.cell.ts"

export const PaymentPaidEvent = z.strictObject({
    orderCode: z.string().min(1),
    transferId: z.string().min(1),
    amount: z.number().nonnegative(),
    content: z.string(),
    accountNumber: z.string(),
    transactionDate: z.string(),
})

type Row = z.infer<typeof SepayTransfer>
type Event = z.infer<typeof PaymentPaidEvent>

/**
 * `sepay.payment.paid`: an incoming transfer whose memo names an order: the subject is `order:<orderCode>`, so the run that waits on that order takes it.
 * The code is SePay's `code` or the first token of the memo shaped like `DH123456` (see order-code.ts); a transfer naming no order is no event here
 * (`sepay.transfer.received` still carries it). The amount is carried as paid, never compared here: the workflow decides short / exact / over. Off until switched on.
 */
export class SepayPaymentPaid implements Trigger<typeof SepayTransfer, typeof PaymentPaidEvent> {
    readonly key = "sepay.payment.paid"
    readonly version = 1
    readonly title = { vi: "Đơn hàng đã được thanh toán", en: "Payment paid" }
    readonly row = SepayTransfer
    readonly event = PaymentPaidEvent
    readonly provider = "sepay"
    readonly dataType = { providerVersion: 1, key: "sepay.transfer" }
    readonly keyMember = "transferId"
    readonly subjectKind = "order"
    readonly subjectMember = "orderCode"
    readonly vias = ["webhook"] as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Event> | null {
        if (row.direction !== "in") return null
        const orderCode = orderCodeOf(row.code, row.content)
        if (orderCode === null) return null
        return { id: row.transferId, data: { orderCode, transferId: row.transferId, amount: row.amount, content: row.content, accountNumber: row.accountNumber, transactionDate: row.transactionDate } }
    }
}
