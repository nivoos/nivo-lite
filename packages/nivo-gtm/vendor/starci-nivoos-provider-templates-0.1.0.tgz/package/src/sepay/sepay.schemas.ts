import { z } from "zod"

// The row a SePay account keeps. A leaf: it imports no cell, so the provider and its triggers can both read it without a load cycle.

/** A kept bank transfer: SePay's `id` as `transferId`, in or out, the amount in VND, the memo, SePay's `code` (null when it found none) and the rest as SePay sent them. */
export const SepayTransfer = z.strictObject({
    transferId: z.string().min(1),
    direction: z.enum(["in", "out"]),
    amount: z.number().nonnegative(),
    content: z.string(),
    code: z.string().nullable(),
    accountNumber: z.string(),
    subAccount: z.string().nullable(),
    gateway: z.string(),
    referenceCode: z.string().nullable(),
    transactionDate: z.string(),
})
