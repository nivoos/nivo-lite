import { z } from "zod"
import type { DataTypes, Delivery, ProofRequest, Provider, ProviderReach, ReceiveResult } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { ListTransactions } from "./list-transactions.cell.ts"
import { SepayTransfer } from "./sepay.schemas.ts"
import { TransferReceived } from "./transfer-received.cell.ts"

export { SepayTransfer }

/** What an account of SePay connects with: the bank account number it watches (public), the API token and the webhook secret (secret). */
export const SepayFields = z.strictObject({
    accountNumber: z.string().min(1),
    apiToken: z.string().min(1),
    webhookSecret: z.string().min(1),
})

/** The two headers an HMAC-SHA256 SePay webhook is proved by. */
export const SepayProof = z.strictObject({ "x-sepay-signature": z.string().optional(), "x-sepay-timestamp": z.string().optional() })

export const SepayData = {
    "sepay.transfer": { value: SepayTransfer, keyMembers: ["transferId"] },
} as const satisfies DataTypes

type Fields = z.infer<typeof SepayFields>
type Proof = z.infer<typeof SepayProof>

/** How far the signed timestamp may be from now (SePay's sample code: 5 minutes). */
const TOLERANCE_SECONDS = 300
/** The account field the HMAC key is read from (the engine reads it by name; the field is never held here). */
const KEY_FIELD = "webhookSecret"

const textOf = (value: unknown): string | null => (typeof value === "string" ? value : typeof value === "number" ? String(value) : null)

/**
 * `sepay`: bank transfer webhooks and the transaction list of SePay. A delivery is proved by HMAC-SHA256 (`X-SePay-Signature: sha256=<hex>` over
 * `<X-SePay-Timestamp>.<raw body>` with the webhook's secret key, timestamp within 5 minutes); one POST is one transfer, kept under SePay's `id`
 * so a re-delivery is one row. SePay's API Key / OAuth 2.0 / no-auth ways are not offered: HMAC is the one SePay marks recommended.
 */
export class SepayProvider implements Provider<typeof SepayFields, typeof SepayProof, typeof SepayData> {
    readonly key = "sepay"
    readonly version = 1
    readonly title = { vi: "SePay", en: "SePay" }
    readonly fields = SepayFields
    readonly secrets = ["apiToken", "webhookSecret"] as const
    readonly description = { vi: "Nhận biến động số dư tài khoản ngân hàng qua webhook SePay và xem danh sách giao dịch.", en: "Receives bank account transfers through SePay webhooks and lists transactions." }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        accountNumber: { label: { vi: "Số tài khoản", en: "Account number" }, help: { vi: "Số tài khoản ngân hàng đã liên kết trong SePay.", en: "The bank account number linked in SePay." }, kind: "text", order: 1 },
        apiToken: { label: { vi: "API token", en: "API token" }, help: { vi: "Tạo trong my.sepay.vn, mục API Access.", en: "Created in my.sepay.vn (API access)." }, kind: "secret", order: 2 },
        webhookSecret: {
            label: { vi: "Khoá bí mật webhook", en: "Webhook secret key" },
            help: { vi: "Chọn bảo mật HMAC-SHA256 khi tạo webhook trong SePay và nhập đúng khoá này; bấm Tự sinh để tạo.", en: "Choose HMAC-SHA256 when you create the webhook in SePay and enter this same key; generate it here." },
            kind: "secret",
            order: 3,
            generate: { bytes: 32, encoding: "hex" },
        },
    } as const
    readonly identityField = "accountNumber"
    readonly kind = "base"
    readonly base = { fixed: "https://my.sepay.vn" }
    readonly auth = { scheme: "bearer", secretField: "apiToken" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly connectTest = "sepay.transactions.list"
    readonly webhook = { proof: SepayProof, ack: { status: 200, body: { success: true } }, refusedStatus: 401, registration: { kind: "copy" } } as const
    /** Sources: https://developer.sepay.vn/en/sepay-api/v1/tao-api-token (API token), https://docs.sepay.vn/tich-hop-webhooks.html and https://developer.sepay.vn/en/sepay-webhooks/xac-thuc (webhook, HMAC). */
    readonly setup = [
        setup.fields({
            key: "credentials",
            title: { vi: "Tài khoản và mã API", en: "Account and API token" },
            body: {
                vi: "Nhập số tài khoản ngân hàng đã liên kết với SePay và **API token** (cách tạo: xem tài liệu SePay). Mã bí mật webhook là chuỗi bạn đặt, dùng lại ở SePay để ký webhook (HMAC-SHA256).",
                en: "Enter the bank account number linked to SePay and the **API token** (how to make one: see the SePay docs). The webhook secret is a string you choose and reuse at SePay to sign webhooks (HMAC-SHA256).",
            },
            fields: ["accountNumber", "apiToken", "webhookSecret"],
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra kết nối", en: "Check the connection" }, operation: ListTransactions }),
        setup.guide({
            key: "dashboard",
            title: { vi: "Cấu hình webhook ở SePay", en: "Configure the webhook at SePay" },
            body: {
                vi: "Trong my.sepay.vn, thêm một webhook trỏ tới **địa chỉ ở bước tiếp theo** và chọn xác thực HMAC-SHA256 với đúng mã bí mật bạn đã nhập. SePay không có API đăng ký webhook nên bước này làm tay. Các nút cụ thể trên giao diện my.sepay.vn không có trong tài liệu chúng tôi đã đọc: làm theo tài liệu SePay.",
                en: "In my.sepay.vn, add a webhook pointing at the **address shown in the next step** and choose HMAC-SHA256 authentication with the same secret you entered. SePay has no webhook-registration API, so this is done by hand. The exact buttons of the my.sepay.vn screens are not in the documents we read: follow the SePay docs.",
            },
            link: { label: { vi: "Tài liệu webhook SePay", en: "SePay webhook docs" }, url: "https://docs.sepay.vn/tich-hop-webhooks.html" },
        }),
        setup.webhook({ key: "webhook", title: { vi: "Địa chỉ webhook", en: "Webhook address" } }),
        setup.waitEvent({
            key: "first-transfer",
            title: { vi: "Chuyển khoản thử", en: "Make a test transfer" },
            body: { vi: "Chuyển một khoản nhỏ vào tài khoản đã liên kết; trang cập nhật khi SePay báo về. Có thể bỏ qua.", en: "Send a small transfer to the linked account; this page updates when SePay reports it. You may skip this." },
            optional: true,
            trigger: TransferReceived,
            timeout: "15m",
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = SepayData

    /** A delivery is SePay's when its signature is the HMAC-SHA256 of `<timestamp>.<raw body>` under the account's webhook secret and the timestamp is fresh. */
    prove(request: ProofRequest<Proof>, reach: ProviderReach<Fields>): boolean {
        const signature = request.headers["x-sepay-signature"]
        const timestamp = request.headers["x-sepay-timestamp"]
        if (typeof signature !== "string" || typeof timestamp !== "string" || !signature.startsWith("sha256=")) return false
        const seconds = Number(timestamp)
        if (!Number.isFinite(seconds)) return false
        if (Math.abs(Date.parse(reach.now()) / 1000 - seconds) > TOLERANCE_SECONDS) return false
        return reach.hmacEquals({ algorithm: "sha256", secret: KEY_FIELD, message: `${timestamp}.${request.body}`, presented: signature.slice("sha256=".length), encoding: "hex" })
    }

    /** One transfer per delivery, kept under SePay's `id`. */
    receive(delivery: Delivery, _reach: ProviderReach<Fields>): ReceiveResult<typeof SepayData> {
        const body = delivery.json
        if (body === null || body === undefined || typeof body !== "object" || Array.isArray(body)) return { kind: "invalid", why: "not_an_object" }
        const raw = body as { readonly [member: string]: unknown }
        const transferId = textOf(raw["id"])
        const direction = raw["transferType"]
        const amount = raw["transferAmount"]
        if (transferId === null || transferId === "" || (direction !== "in" && direction !== "out") || typeof amount !== "number" || amount < 0) return { kind: "invalid", why: "transfer_shape" }
        const content = typeof raw["content"] === "string" ? raw["content"] : ""
        const code = typeof raw["code"] === "string" && raw["code"] !== "" ? raw["code"] : null
        const subAccount = typeof raw["subAccount"] === "string" && raw["subAccount"] !== "" ? raw["subAccount"] : null
        const referenceCode = typeof raw["referenceCode"] === "string" && raw["referenceCode"] !== "" ? raw["referenceCode"] : null
        const accountNumber = textOf(raw["accountNumber"]) ?? ""
        const gateway = typeof raw["gateway"] === "string" ? raw["gateway"] : ""
        const transactionDate = typeof raw["transactionDate"] === "string" ? raw["transactionDate"] : ""
        return { kind: "rows", rows: [{ type: "sepay.transfer", key: transferId, value: { transferId, direction, amount, content, code, accountNumber, subAccount, gateway, referenceCode, transactionDate } }] }
    }
}
