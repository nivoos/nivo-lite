/**
 * The order code of a bank transfer: ONE rule, used by the payment trigger. A code is a token of 2 to 5 capital letters followed by 4 to 12 digits
 * (`DH123456`). SePay's own `code` field (the payment code its account setting recognises) wins when it has that shape; else the first token of
 * the memo that has the shape (the memo is upper-cased and split at every character that is not a letter or a digit, because banks strip spaces and
 * punctuation and change case). No code gives null. This is a NIVO convention, not a SePay fact.
 */
const SHAPE = /^[A-Z]{2,5}[0-9]{4,12}$/

export const orderCodeOf = (code: string | null, content: string): string | null => {
    if (code !== null && SHAPE.test(code.toUpperCase())) return code.toUpperCase()
    for (const token of content.toUpperCase().split(/[^A-Z0-9]+/)) if (SHAPE.test(token)) return token
    return null
}
