# media

The eight provider-neutral media capabilities and their shared shapes (spec A §1). A capability is a name and schemas; a vendor's operation `implements` it, and a node names the capability, never the vendor.

| key | class | file | unit | estimate |
|---|---|---|---|---|
| `image.generate` | `ImageGenerate` | `capabilities/image-generate.capability.ts` | images | `count` (default 1) |
| `image.edit` | `ImageEdit` | `capabilities/image-edit.capability.ts` | images | `count` (default 1) |
| `video.generate` | `VideoGenerate` | `capabilities/video-generate.capability.ts` | video_seconds | `seconds` (default 6) |
| `video.fromImage` | `VideoFromImage` | `capabilities/video-from-image.capability.ts` | video_seconds | `seconds` (default 6) |
| `avatar.speak` | `AvatarSpeak` | `capabilities/avatar-speak.capability.ts` | video_seconds | `script` length per 15 characters (with `audio` the engine probes the file) |
| `voice.speak` | `VoiceSpeak` | `capabilities/voice-speak.capability.ts` | characters | `text` length per 1000 |
| `media.transcribe` | `MediaTranscribe` | `capabilities/media-transcribe.capability.ts` | audio_minutes | fixed 1 (the engine probes the audio) |
| `video.compose` | `VideoCompose` | `capabilities/video-compose.capability.ts` | render_seconds | fixed 1 (known after the render) |

Shared shapes are in `schemas.ts`: `FileRef` (`fileRef()`), `MediaFile`, `Brand`, `JobTicket`, `MediaResult`, `Unit`, `Aspect`.

## Defaults
The build refuses `z.default` and custom checks in a schema (pure data only), so every defaulted member is `.optional()` and the default is in the capability's comment and spec A §1.2; the engine applies it. `avatar.speak` needs exactly one of `script` and `audio`: the engine checks it.

## Refusals
A capability has no `refusals` member in the SDK; each operation declares its own. Spread `mediaRefusals` (or `mediaRefusalsWithFiles` when the operation takes a `FileRef`, which adds `media_not_approved`) into `refusals` and map the vendor's codes to them through `wire.errorCodes`.

## Rules the capabilities carry (spec A §1.9)
1. No vendor documents Vietnamese text drawn into pixels. `image.*`, `video.*` and `avatar.speak` never render text: lettering is overlaid by `video.compose` with the template's own fonts.
2. Vietnamese speech comes from `voice.speak`, never from a video model's native audio, so `audio` defaults to `none`. A presenter takes `audio` rather than `script`.
3. Captions come from `media.transcribe` with `language: "vi"`, and a person reviews them with the asset.

`review` is always `internal` at birth. Credits follow the platform settings: `ceil(vendorUsd x usdToVnd x markup / 10)`, 1 credit = 10 VND.
