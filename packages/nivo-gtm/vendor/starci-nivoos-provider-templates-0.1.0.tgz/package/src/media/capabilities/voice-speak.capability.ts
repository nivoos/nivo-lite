import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { MediaResult } from "../schemas.ts"

export const VoiceSpeakInput = z.strictObject({
    text: z.string().min(1).max(5000),
    /** The vendor's voice id, from the provider's read operation `*.voices.list`. */
    voice: z.string().min(1),
    language: z.enum(["vi", "en"]).optional(),
    speed: z.number().int().min(-3).max(3).optional(),
    format: z.enum(["mp3", "wav"]).optional(),
})
export const VoiceSpeakOutput = MediaResult.extend({})

/** `voice.speak`: text to speech (`files[0]` is the audio, with `durationMs`). The text is the business's own words, so there is no `Brand`. Vietnamese speech comes from here, never from a video model's native audio (spec A §1.9 rule 2). Defaults the engine applies: language vi, format mp3. Estimated per 1000 characters. */
export class VoiceSpeak implements Capability<typeof VoiceSpeakInput, typeof VoiceSpeakOutput> {
    readonly key = "voice.speak"
    readonly version = 1
    readonly title = { vi: "Đọc thành giọng nói", en: "Speak text" }
    readonly input = VoiceSpeakInput
    readonly output = VoiceSpeakOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { textLength: "text", per: 1000 } } } } as const
}
