import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { Brand, MediaFile, MediaResult } from "../schemas.ts"

export const VideoGenerateInput = Brand.extend({
    aspect: z.enum(["16:9", "9:16", "1:1"]),
    seconds: z.number().int().min(2).max(15).optional(),
    resolution: z.enum(["720p", "1080p"]).optional(),
    /** `none` by default: Vietnamese speech comes from `voice.speak`, never from a video model's native audio (spec A §1.9 rule 2). */
    audio: z.enum(["none", "native"]).optional(),
    seed: z.number().int().optional(),
})
export const VideoGenerateOutput = MediaResult.extend({ posterFile: MediaFile.optional() })

/** `video.generate`: (defaults the engine applies: seconds 6, resolution 720p, audio none) a silent clip from the business's words (`files[0]` is the mp4). Never renders text into pixels (spec A §1.9 rule 1). */
export class VideoGenerate implements Capability<typeof VideoGenerateInput, typeof VideoGenerateOutput> {
    readonly key = "video.generate"
    readonly version = 1
    readonly title = { vi: "Tạo video", en: "Generate a video" }
    readonly input = VideoGenerateInput
    readonly output = VideoGenerateOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { member: "seconds", default: 6 } } } } as const
}
