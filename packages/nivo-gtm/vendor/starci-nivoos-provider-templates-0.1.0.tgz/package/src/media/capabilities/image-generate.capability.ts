import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { Aspect, Brand, FileRef, MediaResult } from "../schemas.ts"

export const ImageGenerateInput = Brand.extend({
    aspect: Aspect.optional(),
    size: z.enum(["1k", "2k", "4k"]).optional(),
    count: z.number().int().min(1).max(4).optional(),
    quality: z.enum(["draft", "standard", "high"]).optional(),
    transparent: z.boolean().optional(),
    references: z.array(FileRef).max(4).optional(),
    seed: z.number().int().optional(),
})
export const ImageGenerateOutput = MediaResult.extend({})

/** `image.generate`: pictures from the business's words. Never renders text into pixels (spec A §1.9 rule 1): lettering is overlaid by `video.compose`. Defaults the engine applies: aspect 1:1, size 1k, count 1, quality standard. Refusals: see `mediaRefusals` (+ `media_not_approved` for references). */
export class ImageGenerate implements Capability<typeof ImageGenerateInput, typeof ImageGenerateOutput> {
    readonly key = "image.generate"
    readonly version = 1
    readonly title = { vi: "Tạo ảnh", en: "Generate images" }
    readonly input = ImageGenerateInput
    readonly output = ImageGenerateOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { member: "count", default: 1 } } } } as const
}
