import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { FileRef, MediaResult } from "../schemas.ts"

export const MediaTranscribeInput = z.strictObject({
    /** An audio or a video file. */
    source: FileRef,
    language: z.enum(["vi", "en", "auto"]).optional(),
    formats: z.array(z.enum(["srt", "vtt", "words"])).min(1).optional(),
    maxLineChars: z.number().int().min(10).max(120).optional(),
})
export const MediaTranscribeOutput = MediaResult.extend({
    text: z.string(),
    /** Word timings; a large result is a file in `files` instead. */
    words: z.array(z.strictObject({ w: z.string(), startMs: z.number().int().nonnegative(), endMs: z.number().int().nonnegative() })).optional(),
})

/** `media.transcribe`: captions and word timings of the final audio (`files` has one per format). Vietnamese captions are reviewed by a person with the asset (spec A §1.9 rule 3). Defaults the engine applies: language vi, formats [srt], maxLineChars 42. Takes a file, so it may refuse `media_not_approved`. */
export class MediaTranscribe implements Capability<typeof MediaTranscribeInput, typeof MediaTranscribeOutput> {
    readonly key = "media.transcribe"
    readonly version = 1
    readonly title = { vi: "Chuyển giọng nói thành chữ", en: "Transcribe media" }
    readonly input = MediaTranscribeInput
    readonly output = MediaTranscribeOutput
    // the length is only known after the probe of the file: the engine counts the audio minutes, this is the floor the hold starts from
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { fixed: 1 } } } } as const
}
