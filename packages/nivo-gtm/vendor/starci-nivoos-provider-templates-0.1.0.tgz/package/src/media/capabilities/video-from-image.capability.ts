import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { Brand, FileRef, MediaFile, MediaResult } from "../schemas.ts"

export const VideoFromImageInput = Brand.extend({
    firstFrame: FileRef,
    lastFrame: FileRef.optional(),
    aspect: z.enum(["16:9", "9:16", "1:1"]),
    seconds: z.number().int().min(2).max(15).optional(),
    resolution: z.enum(["720p", "1080p"]).optional(),
    audio: z.enum(["none", "native"]).optional(),
    /** A camera instruction; it is part of the subject. */
    motion: z.string().max(500).optional(),
})
export const VideoFromImageOutput = MediaResult.extend({ posterFile: MediaFile.optional() })

/** `video.fromImage`: animate a stored picture (spec A §1.0 spells it `fromImage`; `video.from-image` if the build refuses). Defaults the engine applies: seconds 6, resolution 720p, audio none. Never renders text into pixels (spec A §1.9 rule 1). Takes files, so it may refuse `media_not_approved`. */
export class VideoFromImage implements Capability<typeof VideoFromImageInput, typeof VideoFromImageOutput> {
    readonly key = "video.fromImage"
    readonly version = 1
    readonly title = { vi: "Tạo video từ ảnh", en: "Video from an image" }
    readonly input = VideoFromImageInput
    readonly output = VideoFromImageOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { member: "seconds", default: 6 } } } } as const
}
