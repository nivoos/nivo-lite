import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { FileRef, MediaResult } from "../schemas.ts"

export const VideoComposeInput = z.strictObject({
    /** The vendor's template id. */
    template: z.string().min(1),
    /** The named fields of the template: the business's own text (the one place Vietnamese lettering is put on a picture or a video), files and numbers. */
    fields: z.record(z.string(), z.union([z.string(), FileRef, z.number()])),
    format: z.enum(["mp4", "png", "jpg", "gif"]).optional(),
    resolution: z.enum(["720p", "1080p"]).optional(),
})
export const VideoComposeOutput = MediaResult.extend({})

/** `video.compose`: fill a vendor template with clips, voice, captions and brand text (Creatomate, Shotstack, Canva). The one capability that renders text, with the template's own fonts (spec A §1.9 rule 1). Default format mp4. Takes files, so it may refuse `media_not_approved`. */
export class VideoCompose implements Capability<typeof VideoComposeInput, typeof VideoComposeOutput> {
    readonly key = "video.compose"
    readonly version = 1
    readonly title = { vi: "Ghép video theo mẫu", en: "Compose from a template" }
    readonly input = VideoComposeInput
    readonly output = VideoComposeOutput
    // render seconds are known after the render (an image counts 1): the engine books the reported units
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { fixed: 1 } } } } as const
}
