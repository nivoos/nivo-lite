import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { Aspect, Brand, FileRef, MediaResult } from "../schemas.ts"

export const ImageEditInput = Brand.extend({
    source: FileRef,
    /** White = keep. The engine converts the mask to each vendor's convention. */
    mask: FileRef.optional(),
    references: z.array(FileRef).max(4).optional(),
    aspect: Aspect.optional(),
    count: z.number().int().min(1).max(4).optional(),
})
export const ImageEditOutput = MediaResult.extend({})

/** `image.edit`: change a stored picture. Never renders text into pixels (spec A §1.9 rule 1). Default count 1. Takes files, so it may refuse `media_not_approved`. */
export class ImageEdit implements Capability<typeof ImageEditInput, typeof ImageEditOutput> {
    readonly key = "image.edit"
    readonly version = 1
    readonly title = { vi: "Chỉnh sửa ảnh", en: "Edit an image" }
    readonly input = ImageEditInput
    readonly output = ImageEditOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { member: "count", default: 1 } } } } as const
}
