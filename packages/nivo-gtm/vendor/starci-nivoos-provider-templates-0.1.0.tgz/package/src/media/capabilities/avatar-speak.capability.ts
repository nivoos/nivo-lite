import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { Aspect, Brand, FileRef, MediaFile, MediaResult } from "../schemas.ts"

export const AvatarSpeakInput = Brand.extend({
    /** The vendor's avatar id, from the provider's read operation `*.avatars.list`. */
    avatar: z.string().min(1),
    voice: z.string().min(1).optional(),
    script: z.string().min(1).max(5000).optional(),
    /** Preferred for Vietnamese: the `voice.speak` file (spec A §1.9 rule 2). */
    audio: FileRef.optional(),
    aspect: Aspect,
    resolution: z.enum(["720p", "1080p"]).optional(),
    /** A picture or a colour (`#rrggbb`). */
    background: z.union([FileRef, z.string().regex(/^#[0-9a-fA-F]{6}$/u)]).optional(),
    captions: z.boolean().optional(),
})
export const AvatarSpeakOutput = MediaResult.extend({ captionsFile: MediaFile.optional() })

/**
 * `avatar.speak`: an AI presenter says a script or plays an audio file (`files[0]` is the mp4, `captionsFile` an srt). Exactly one of `script` and `audio` (the engine checks it; the build allows no custom check in a schema). Defaults the engine applies: resolution 720p, captions false.
 * The estimate counts seconds from the script at about 15 characters per second; with `audio` the engine probes the stored file.
 * Never renders text into pixels (spec A §1.9 rule 1).
 */
export class AvatarSpeak implements Capability<typeof AvatarSpeakInput, typeof AvatarSpeakOutput> {
    readonly key = "avatar.speak"
    readonly version = 1
    readonly title = { vi: "Người dẫn AI nói", en: "AI presenter speaks" }
    readonly input = AvatarSpeakInput
    readonly output = AvatarSpeakOutput
    readonly semantics = { mutates: true, metered: { usage: "units", price: "reported", estimate: { units: { textLength: "script", per: 15 } } } } as const
}
