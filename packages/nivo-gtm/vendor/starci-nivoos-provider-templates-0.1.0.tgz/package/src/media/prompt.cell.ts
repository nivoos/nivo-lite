import { z } from "zod"
import { PROMPT_BASES_MARK, type Node, type NodeReach } from "@starci/nivoos-sdk"

/** One named base: the brand's words that open every prompt of a kind of media, and the version a prompt records. */
const PromptBase = z.strictObject({
    version: z.number().int().min(1),
    text: z.string().min(1).max(8000),
})

export const MediaPromptInput = z.strictObject({
    /** The name of the base the prompt opens with (`illustration`, or a name `media.yaml` gives). */
    base: z.string().min(1).max(120),
    /** What this one picture or clip is of: it follows the base after a blank line. */
    subject: z.string().max(4000),
})

export const MediaPromptOutput = z.strictObject({
    prompt: z.string().min(1),
    /** The base the prompt opens with, and its version, for the record of the media. */
    base: z.strictObject({ name: z.string(), version: z.number().int() }),
})

/** The workspace's bases by name; `{}` until a standard or the console sets some. */
export const MediaPromptSettings = z.strictObject({
    "media.promptBases": z.record(z.string().min(1).max(120), PromptBase).default({}).meta({ $comment: PROMPT_BASES_MARK }),
})

type In = z.infer<typeof MediaPromptInput>
type Out = z.infer<typeof MediaPromptOutput>
type Settings = z.infer<typeof MediaPromptSettings>

/**
 * `media.prompt` (Lời mở đầu của prompt media): the node that holds the setting `media.promptBases` (E8 standard entries and console edits reach it by this cell) and composes a prompt from it:
 * the base's text, a blank line, then the subject. A base the workspace does not keep stops the run at this step. The engine composes the prompt of a capability call the same way from the same setting
 * (`composePrompt`); a console text edit of a base raises its version (`editedPromptBases`).
 */
export class MediaPrompt implements Node<typeof MediaPromptInput, typeof MediaPromptOutput, typeof MediaPromptSettings> {
    readonly key = "media.prompt"
    readonly version = 1
    readonly title = { vi: "Lời mở đầu của prompt media", en: "Media prompt base" }
    readonly input = MediaPromptInput
    readonly output = MediaPromptOutput
    readonly settings = MediaPromptSettings
    readonly reads = []

    run(input: In, reach: NodeReach<Settings>): Out {
        const bases = reach.settings["media.promptBases"]
        const found = Object.hasOwn(bases, input.base) ? bases[input.base] : undefined
        if (found === undefined) throw new Error(`media.prompt: the workspace keeps no prompt base named ${input.base}`)
        return { prompt: `${found.text.trim()}\n\n${input.subject}`, base: { name: input.base, version: found.version } }
    }
}
