// The shared shapes of the media capabilities (spec A §1.1). A capability is a name and schemas; the vendors' operations `implements` it.
import { z } from "zod"
import { fileRef } from "@starci/nivoos-sdk"

/** A file of the workspace, by key (an object-store key under `generated/` or `brain/`, or a drive path). The engine turns it into a short-lived signed URL for the vendor; the code never holds bytes. */
export const FileRef = fileRef()

/** A file the engine stored and probed: the SDK's file handle plus what the probe found. */
export const MediaFile = z.strictObject({
    file: z.string().min(1),
    mime: z.string().min(1),
    bytes: z.number().int().nonnegative(),
    width: z.number().int().positive().optional(),
    height: z.number().int().positive().optional(),
    durationMs: z.number().int().nonnegative().optional(),
    sha256: z.string().regex(/^[0-9a-f]{64}$/u),
})

/**
 * What every generating capability starts with: the prompt composition (spec A §4) and the business's own words.
 * No vendor documents Vietnamese text drawn into pixels, so `subject` never asks for lettering: text on an image or a video is overlaid by `video.compose` (spec A §1.9 rule 1).
 */
export const Brand = z.strictObject({
    /** The name of a prompt base; absent: the default base of the capability. */
    base: z.string().min(1).max(100).optional(),
    /** The business's words for what to make. Describe the picture, never any text in it: no text, no letters rendered into pixels. */
    subject: z.string().min(1).max(4000).describe("What to make, in the business's words. Never ask for text or letters in the picture: text is overlaid by video.compose."),
})

/** What every async capability answers when it is submitted: the job and the estimate the engine held. */
export const JobTicket = z.strictObject({
    jobId: z.uuid(),
    state: z.literal("submitted"),
    estimateCredits: z.number().nonnegative(),
})

export const Unit = z.enum(["images", "video_seconds", "audio_seconds", "characters", "audio_minutes", "render_seconds"])
export const Aspect = z.enum(["1:1", "16:9", "9:16", "4:5", "3:4", "4:3"])

/** Common to every final output (it arrives in `engine.job.finished`). `review` is `internal` at birth: a person approves before the file leaves the company (spec A §6). */
export const MediaResult = z.strictObject({
    generationId: z.uuid(),
    files: z.array(MediaFile),
    provider: z.string(),
    model: z.string(),
    units: z.number().nonnegative(),
    unit: Unit,
    credits: z.number().nonnegative(),
    review: z.literal("internal"),
})

/**
 * The refusals every media operation declares in its own `refusals` (the SDK has no refusals on a capability; an operation maps its vendor's codes to these through `wire.errorCodes`).
 * `media_not_approved` is added by an operation that takes a file the workspace has not approved.
 */
export const mediaRefusals = [
    "content_refused", // the vendor's moderation
    "input_invalid", // a size, length or ratio the vendor refuses
    "input_unreachable", // the vendor could not fetch a FileRef
    "quota_exceeded", // the vendor account is out of credit: a platform alert, not the customer's problem
    "media_cap_reached", // the workspace caps
    "media_budget_exhausted", // the credit pool
    "job_timeout",
    "job_cancelled",
] as const
export const mediaRefusalsWithFiles = [...mediaRefusals, "media_not_approved"] as const
export type MediaRefusal = (typeof mediaRefusals)[number] | "media_not_approved"

export type MediaFileValue = z.infer<typeof MediaFile>
export type BrandValue = z.infer<typeof Brand>
export type JobTicketValue = z.infer<typeof JobTicket>
export type MediaResultValue = z.infer<typeof MediaResult>
