// The shared SRT / VTT mapper of the media providers (spec A section 1.7, P5): word or utterance timings in, caption text out. PURE: no clock, no I/O, no vendor.
// Deepgram's answer and OpenAI's `gpt-transcribe` words both go through it, so a caption file looks the same whichever vendor heard the audio. Text passes through untouched (Vietnamese
// diacritics included; nothing is normalised), only the length of a line is measured without combining marks, so a decomposed "e" + accent counts as one character like the composed one.

/** One timed piece of speech: a word, or a whole utterance (any piece that holds spaces is split into words, its time shared out by length). Times are milliseconds from the start of the media. */
export interface CaptionWord {
    readonly w: string
    readonly startMs: number
    readonly endMs: number
}

export interface CaptionOptions {
    /** The most characters on one line of a cue (default 42; a single word longer than this keeps a line to itself). */
    readonly maxLineChars?: number
    /** The most lines in one cue (default 2). */
    readonly maxLines?: number
    /** A cue never lasts longer than this (default 6000 ms), unless one word does. */
    readonly maxCueMs?: number
    /** A silence at least this long between two words ends the cue (default 800 ms). */
    readonly gapMs?: number
}

export interface CaptionCue {
    readonly startMs: number
    readonly endMs: number
    readonly lines: ReadonlyArray<string>
}

export const DEFAULT_MAX_LINE_CHARS = 42
const DEFAULT_MAX_LINES = 2
const DEFAULT_MAX_CUE_MS = 6000
const DEFAULT_GAP_MS = 800
/** A cue that would end before it starts, or at the same instant, still shows for this long. */
const MIN_CUE_MS = 200

const positive = (value: number | undefined, fallback: number): number => (value !== undefined && Number.isFinite(value) && value >= 1 ? Math.floor(value) : fallback)
const milliseconds = (value: number): number => (Number.isFinite(value) && value > 0 ? Math.round(value) : 0)

/** The width of a text in characters: code points, combining marks not counted. */
const widthOf = (text: string): number => {
    let width = 0
    for (const character of text) if (!/^\p{M}$/u.test(character)) width += 1
    return width
}

/** The words of the input in order, every piece with spaces split into words and its time shared by width; empty text dropped, times made whole and never backwards. */
export const wordsOf = (pieces: ReadonlyArray<CaptionWord>): ReadonlyArray<CaptionWord> => {
    const out: Array<CaptionWord> = []
    let floor = 0
    for (const piece of pieces) {
        const parts = piece.w.split(/\s+/u).filter((part) => part !== "")
        if (parts.length === 0) continue
        const start = Math.max(milliseconds(piece.startMs), floor)
        const end = Math.max(milliseconds(piece.endMs), start)
        const total = parts.reduce((sum, part) => sum + widthOf(part), 0)
        let at = start
        let used = 0
        for (const part of parts) {
            used += widthOf(part)
            const to = parts.length === 1 ? end : start + Math.round(((end - start) * used) / total)
            out.push({ w: part, startMs: at, endMs: to })
            at = to
        }
        floor = end
    }
    return out
}

/** The cues of the timings: words joined into lines of at most `maxLineChars`, lines into cues of at most `maxLines` and `maxCueMs`, a cue ended by a long silence or by the end of a sentence once it holds a line. */
export const cuesOf = (pieces: ReadonlyArray<CaptionWord>, options: CaptionOptions = {}): ReadonlyArray<CaptionCue> => {
    const maxLineChars = positive(options.maxLineChars, DEFAULT_MAX_LINE_CHARS)
    const maxLines = positive(options.maxLines, DEFAULT_MAX_LINES)
    const maxCueMs = positive(options.maxCueMs, DEFAULT_MAX_CUE_MS)
    const gapMs = positive(options.gapMs, DEFAULT_GAP_MS)
    const cues: Array<{ startMs: number; endMs: number; lines: Array<string> }> = []
    let current: { startMs: number; endMs: number; lines: Array<string> } | null = null
    let previous: CaptionWord | null = null
    for (const word of wordsOf(pieces)) {
        const sentenceEnded = previous !== null && /[.!?…]["')\]]*$/u.test(previous.w)
        const closes =
            current !== null &&
            previous !== null &&
            (word.startMs - previous.endMs >= gapMs || word.endMs - current.startMs > maxCueMs || (sentenceEnded && current.lines.length >= 1 && current.lines.join(" ").length >= maxLineChars / 2))
        if (closes && current !== null) {
            cues.push(current)
            current = null
        }
        if (current === null) {
            current = { startMs: word.startMs, endMs: word.endMs, lines: [word.w] }
        } else {
            const last = current.lines[current.lines.length - 1] ?? ""
            if (widthOf(last) + 1 + widthOf(word.w) <= maxLineChars) {
                current.lines[current.lines.length - 1] = `${last} ${word.w}`
            } else if (current.lines.length < maxLines) {
                current.lines.push(word.w)
            } else {
                cues.push(current)
                current = { startMs: word.startMs, endMs: word.endMs, lines: [word.w] }
            }
            current.endMs = word.endMs
        }
        previous = word
    }
    if (current !== null) cues.push(current)
    // a cue shows at least MIN_CUE_MS and never over the next one
    return cues.map((cue, index) => {
        const next = cues[index + 1]
        const wanted = Math.max(cue.endMs, cue.startMs + MIN_CUE_MS)
        const endMs = next === undefined ? wanted : Math.max(Math.min(wanted, next.startMs), cue.endMs)
        return { startMs: cue.startMs, endMs, lines: cue.lines }
    })
}

const pad = (value: number, width: number): string => String(value).padStart(width, "0")
const clock = (ms: number, separator: "," | "."): string => {
    const hours = Math.floor(ms / 3_600_000)
    const minutes = Math.floor((ms % 3_600_000) / 60_000)
    const seconds = Math.floor((ms % 60_000) / 1000)
    return `${pad(hours, 2)}:${pad(minutes, 2)}:${pad(seconds, 2)}${separator}${pad(ms % 1000, 3)}`
}
/** A WebVTT cue text may not hold `&`, `<` (markup) or `>` (it could close `-->`): they travel as entities. */
const vttText = (text: string): string => text.replace(/&/gu, "&amp;").replace(/</gu, "&lt;").replace(/>/gu, "&gt;")

/** SubRip text: numbered cues, `HH:MM:SS,mmm --> HH:MM:SS,mmm`, a blank line between cues; empty when there is no speech. */
export const srtOf = (pieces: ReadonlyArray<CaptionWord>, options: CaptionOptions = {}): string =>
    cuesOf(pieces, options)
        .map((cue, index) => `${index + 1}\n${clock(cue.startMs, ",")} --> ${clock(cue.endMs, ",")}\n${cue.lines.join("\n")}\n`)
        .join("\n")

/** WebVTT text: the `WEBVTT` header, then cues `HH:MM:SS.mmm --> HH:MM:SS.mmm`; a header alone when there is no speech. */
export const vttOf = (pieces: ReadonlyArray<CaptionWord>, options: CaptionOptions = {}): string => {
    const body = cuesOf(pieces, options)
        .map((cue) => `${clock(cue.startMs, ".")} --> ${clock(cue.endMs, ".")}\n${cue.lines.map(vttText).join("\n")}\n`)
        .join("\n")
    return body === "" ? "WEBVTT\n" : `WEBVTT\n\n${body}`
}

const BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

/** The UTF-8 bytes of a text, as base64 (RFC 4648, padded): the form a `job.outputs` of `as: "base64"` takes a text file in. Pure, so a caption file made here needs no runtime global. */
export const base64Of = (text: string): string => {
    const bytes: Array<number> = []
    for (const character of text) {
        const point = character.codePointAt(0) ?? 0xfffd
        const code = point >= 0xd800 && point <= 0xdfff ? 0xfffd : point
        if (code < 0x80) bytes.push(code)
        else if (code < 0x800) bytes.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f))
        else if (code < 0x10000) bytes.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f))
        else bytes.push(0xf0 | (code >> 18), 0x80 | ((code >> 12) & 0x3f), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f))
    }
    let out = ""
    for (let index = 0; index < bytes.length; index += 3) {
        const a = bytes[index] ?? 0
        const b = bytes[index + 1]
        const c = bytes[index + 2]
        const chunk = (a << 16) | ((b ?? 0) << 8) | (c ?? 0)
        out += BASE64.charAt((chunk >> 18) & 63) + BASE64.charAt((chunk >> 12) & 63) + (b === undefined ? "=" : BASE64.charAt((chunk >> 6) & 63)) + (c === undefined ? "=" : BASE64.charAt(chunk & 63))
    }
    return out
}
