// What the two image operations of OpenAI share: the wire, the sizes, the models and the mapping of an answer. Data and pure mapping only; no transport, no clock.
import { z } from "zod"
import type { JsonValue } from "@starci/nivoos-sdk"
import type { MediaRefusal } from "../media/schemas.ts"

/** Fast model for draft and standard, quality model for high (spec A section 1.3). The 2.6 ids are in the enum too (README). */
export const MODEL_FAST = "gpt-image-2.5-flare"
export const MODEL_QUALITY = "gpt-image-2.5-sunburst"

export const ImagesOutput = z.strictObject({
    /** The pictures as base64 (PNG): the engine lifts, decodes and stores them (`job.outputs`). */
    images: z.array(z.string()),
    /** How many pictures: the unit billed (`job.usage`). */
    imageCount: z.number().int().nonnegative(),
    /** The tokens the vendor reports. */
    usage: z.strictObject({ inputTokens: z.number().int().nonnegative(), outputTokens: z.number().int().nonnegative(), totalTokens: z.number().int().nonnegative() }).optional(),
})
export type ImagesOut = z.infer<typeof ImagesOutput>

type Aspect = "1:1" | "16:9" | "9:16" | "4:5" | "3:4" | "4:3"
type Size = "1k" | "2k" | "4k"

/** Both sides divisible by 16, ratio inside 1:3..3:1, at most 3840x2160 (README). Sizes above 2560x1440 are experimental on the vendor's page. */
const SIZES: Readonly<Record<Size, Readonly<Record<Aspect, string>>>> = {
    "1k": { "1:1": "1024x1024", "16:9": "1024x576", "9:16": "576x1024", "4:5": "832x1040", "3:4": "768x1024", "4:3": "1024x768" },
    "2k": { "1:1": "2048x2048", "16:9": "2048x1152", "9:16": "1152x2048", "4:5": "1664x2080", "3:4": "1536x2048", "4:3": "2048x1536" },
    "4k": { "1:1": "2160x2160", "16:9": "3840x2160", "9:16": "2160x3840", "4:5": "1728x2160", "3:4": "2160x2880", "4:3": "2880x2160" },
}

export const sizeOf = (aspect: Aspect | undefined, size: Size | undefined): string => SIZES[size ?? "1k"][aspect ?? "1:1"]
export const baseSizeOf = (aspect: Aspect | undefined): string => (aspect === undefined ? "auto" : SIZES["1k"][aspect])

export const qualityOf = (quality: "draft" | "standard" | "high" | undefined): "low" | "medium" | "high" => (quality === "draft" ? "low" : quality === "high" ? "high" : "medium")
export const modelOf = (quality: "draft" | "standard" | "high" | undefined): string => (quality === "high" ? MODEL_QUALITY : MODEL_FAST)

/** The wire both operations declare (README, Errors). `errorField` is the vendor's own code at `error.code`. */
export const IMAGES_WIRE = {
    // no idempotency header: the engine guards the call (a retry after a lost answer is not sent blind, so it never bills twice)
    dedupe: {},
    errorField: "error.code",
    errorCodes: {
        credit_balance_exhausted: "quota_exceeded",
        organization_spend_limit_exceeded: "quota_exceeded",
        project_spend_limit_exceeded: "quota_exceeded",
        organization_usage_limit_exceeded: "quota_exceeded",
        insufficient_quota: "quota_exceeded",
        billing_hard_limit_reached: "quota_exceeded",
        moderation_blocked: "content_refused",
        content_policy_violation: "content_refused",
        invalid_image_url: "input_unreachable",
    },
    statusRefusals: { "400": "input_invalid", "413": "input_invalid" },
    transientCodes: { slow_down: { retryAfterSeconds: 20 } },
} as const satisfies { readonly dedupe?: { readonly lookup?: string }; readonly errorField: string; readonly errorCodes: Readonly<Record<string, MediaRefusal>>; readonly statusRefusals: Readonly<Record<string, MediaRefusal>>; readonly transientCodes: Readonly<Record<string, { readonly retryAfterSeconds: number }>> }

type Json = { readonly [member: string]: JsonValue }
const isObject = (value: JsonValue | undefined): value is Json => typeof value === "object" && value !== null && !Array.isArray(value)
const count = (value: JsonValue | undefined): number => (typeof value === "number" && Number.isFinite(value) && value >= 0 ? Math.floor(value) : 0)

/** The pictures and the usage of an `ImagesResponse`; null when the answer has no picture in base64 (a `url` never comes from GPT image models). */
export const imagesOf = (json: JsonValue | undefined): ImagesOut | null => {
    if (!isObject(json) || !Array.isArray(json["data"])) return null
    const images: Array<string> = []
    for (const item of json["data"]) {
        const encoded = isObject(item) ? item["b64_json"] : undefined
        if (typeof encoded !== "string" || encoded === "") return null
        images.push(encoded)
    }
    if (images.length === 0) return null
    const usage = json["usage"]
    return isObject(usage)
        ? { images, imageCount: images.length, usage: { inputTokens: count(usage["input_tokens"]), outputTokens: count(usage["output_tokens"]), totalTokens: count(usage["total_tokens"]) } }
        : { images, imageCount: images.length }
}
