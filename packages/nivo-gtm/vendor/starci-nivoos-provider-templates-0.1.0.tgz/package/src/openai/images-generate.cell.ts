import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { ImageGenerate, ImageGenerateInput } from "../media/capabilities/image-generate.capability.ts"
import { mediaRefusalsWithFiles } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { IMAGES_WIRE, ImagesOutput, imagesOf, modelOf, qualityOf, sizeOf } from "./images.ts"
import type { ImagesOut } from "./images.ts"
import type { OpenaiAccount } from "./openai.provider.cell.ts"
import { z } from "zod"

type In = z.infer<typeof ImageGenerateInput>

/**
 * `openai.images.generate`: `POST /v1/images/generations` (JSON), or `/v1/images/edits` when `references` are given (the generation endpoint takes none). One long call the engine makes itself
 * (`job.sync`, 180 s); GPT image models answer base64 only. `seed` is ignored (no seed is documented). Never asks for text in the picture: the subject is the business's own words and lettering is
 * overlaid by `video.compose`. See README.md.
 */
export class OpenaiImagesGenerate implements Operation<typeof ImageGenerateInput, typeof ImagesOutput, OpenaiAccount, MediaRefusal> {
    readonly key = "openai.images.generate"
    readonly version = 1
    readonly title = { vi: "Tạo ảnh (OpenAI)", en: "Generate images (OpenAI)" }
    readonly input = ImageGenerateInput
    readonly output = ImagesOutput
    // tokens, as the vendor reports them in the answer; per-image prices of 2.5 and 2.6 are UNVERIFIED (README)
    readonly semantics = { mutates: true, timeoutMs: 180_000, metered: { usage: "tokens", price: "reported" } } as const
    readonly provider = "openai"
    readonly http = true
    readonly implements = ImageGenerate
    readonly needs = ["apiKey"] as const
    readonly refusals = mediaRefusalsWithFiles
    readonly job = { sync: true, timeoutMs: 180_000, outputs: { path: "images", as: "base64" }, usage: { path: "imageCount", unit: "images" } } as const
    readonly wire = IMAGES_WIRE

    run(input: In, reach: OperationReach<OpenaiAccount, MediaRefusal>): ImagesOut {
        const references = input.references ?? []
        const common = {
            model: modelOf(input.quality),
            prompt: input.subject,
            n: input.count ?? 1,
            size: sizeOf(input.aspect, input.size),
            quality: qualityOf(input.quality),
            output_format: "png",
            ...(input.transparent === true ? { background: "transparent" } : {}),
        }
        const response =
            references.length === 0
                ? reach.http({ method: "POST", path: "/v1/images/generations", headers: { "content-type": "application/json" }, body: common })
                : reach.http({
                      method: "POST",
                      path: "/v1/images/edits",
                      headers: { "content-type": "application/json" },
                      body: { ...common, images: references.map((reference) => ({ image_url: reference.file })) },
                  })
        const answer = response.status === 200 ? imagesOf(response.json) : null
        return answer === null ? reach.byStatus() : answer
    }
}
