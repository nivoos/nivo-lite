import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { ImageEdit, ImageEditInput } from "../media/capabilities/image-edit.capability.ts"
import { mediaRefusalsWithFiles } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { baseSizeOf, IMAGES_WIRE, ImagesOutput, imagesOf, MODEL_QUALITY } from "./images.ts"
import type { ImagesOut } from "./images.ts"
import type { OpenaiAccount } from "./openai.provider.cell.ts"

type In = z.infer<typeof ImageEditInput>

/**
 * `openai.images.edit`: `POST /v1/images/edits`, JSON: `images[]` of `{ image_url }` (the source, then the references; the engine has replaced each `FileRef` with a signed address) and an optional
 * `mask` (alpha channel, a hint and not a hard shape). Sync, like generation. See README.md.
 */
export class OpenaiImagesEdit implements Operation<typeof ImageEditInput, typeof ImagesOutput, OpenaiAccount, MediaRefusal> {
    readonly key = "openai.images.edit"
    readonly version = 1
    readonly title = { vi: "Chỉnh sửa ảnh (OpenAI)", en: "Edit an image (OpenAI)" }
    readonly input = ImageEditInput
    readonly output = ImagesOutput
    readonly semantics = { mutates: true, timeoutMs: 180_000, metered: { usage: "tokens", price: "reported" } } as const
    readonly provider = "openai"
    readonly http = true
    readonly implements = ImageEdit
    readonly needs = ["apiKey"] as const
    readonly refusals = mediaRefusalsWithFiles
    readonly job = { sync: true, timeoutMs: 180_000, outputs: { path: "images", as: "base64" }, usage: { path: "imageCount", unit: "images" } } as const
    readonly wire = IMAGES_WIRE

    run(input: In, reach: OperationReach<OpenaiAccount, MediaRefusal>): ImagesOut {
        const images = [input.source, ...(input.references ?? [])].map((file) => ({ image_url: file.file }))
        const response = reach.http({
            method: "POST",
            path: "/v1/images/edits",
            headers: { "content-type": "application/json" },
            body: {
                model: MODEL_QUALITY,
                prompt: input.subject,
                images,
                n: input.count ?? 1,
                size: baseSizeOf(input.aspect),
                output_format: "png",
                ...(input.mask === undefined ? {} : { mask: { image_url: input.mask.file } }),
            },
        })
        const answer = response.status === 200 ? imagesOf(response.json) : null
        return answer === null ? reach.byStatus() : answer
    }
}
