# openai

OpenAI images and transcription for the media capabilities `image.generate`, `image.edit` and `media.transcribe` (spec A section 1.3, 1.7, lane gm-p-openai). Pages read 2026-11-18. Anything not on a cited page is marked UNVERIFIED. No real key was entered or recorded: the fixtures under `be/src/tests/fixtures/e2e/providers/openai/` are built from the documented shapes and marked `documented`.

## What it is
- Provider `openai`, `accountOwner: "platform"`, base `https://api.openai.com`, `Authorization: Bearer <apiKey>` (`auth: bearer`, secret field `apiKey`). Custody names (spec A section 7): the upper-case, underscore form of nivo-media-openai-api-key and nivo-media-openai-org (the second is optional; no typed env reader declares them yet, so they are not written out here). The instance makes the account at boot; a workspace never sees it.
- Operations (all `job: { sync: true }`: the engine makes the one long call in the media worker; no operation loops on a status read):
  - `openai.images.generate` implements `image.generate`;
  - `openai.images.edit` implements `image.edit`;
  - `openai.audio.transcribe` implements `media.transcribe`.
- Logo: neutral monogram; OpenAI's brand terms were not checked.

## Models (resolved: the spec's open check)
https://developers.openai.com/api/reference/resources/images/methods/generate.md (read 2026-11-18). The `model` enum lists `gpt-image-2.5-sunburst`, `gpt-image-2.5-flare`, `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare` (the 2.6 ids ARE in the enum now), plus `gpt-image-2`, `gpt-image-1.5`, `gpt-image-1-mini`; `gpt-image-1` was shut down on 2026-10-23.
- Used: `gpt-image-2.5-flare` (fast) for quality `draft` and `standard`, `gpt-image-2.5-sunburst` (quality) for `high`. Switching to 2.6 is one constant in `images.ts`. 2.6 was not chosen because spec A names 2.5 and no 2.6 price or behaviour is documented on the pages read.
- The edit page (edit.md) defaults `model` to `gpt-image-2.5-sunburst`.

## images.generate
- `POST /v1/images/generations`, JSON: `model`, `prompt` (<= 32000), `n` (1..10; the capability allows 1..4), `size`, `quality`, `background`, `output_format: "png"`.
- `prompt` is `input.subject`. UNVERIFIED: that the engine composes the brand base (spec A section 4) into the prompt before `run`; this operation does not read `input.base`.
- Quality: `draft` -> `low`, `standard` -> `medium`, `high` -> `high` (`quality` accepts `low|medium|high`, 2.5 also `xhigh|max`, not used).
- `transparent: true` -> `background: "transparent"` (needs png or webp; png is always sent). Otherwise the field is left out (`auto`).
- Size: the page allows `1024x1024`, `1536x1024`, `1024x1536` and, for the `gpt-image-2` family, any `WxH` with both sides divisible by 16, ratio between 1:3 and 3:1, at most 3840x2160. The table in `images.ts` maps (aspect, 1k/2k/4k) to such sizes; every side is divisible by 16. The edit page says sizes above 2560x1440 are experimental, which includes most `4k` entries. UNVERIFIED: that the 2.5 models accept custom sizes on the generation endpoint (the edit page says the `gpt-image-2` and `gpt-image-2.5` families do).
- `seed`: the API documents no seed. It is ignored.
- `references` (<= 4): the generation endpoint has no reference images, so when present the operation posts to `/v1/images/edits` instead with `images[]` = the references (documented as one to 16 `image_url`s). UNVERIFIED: result quality of that use.
- Answer: `data[].b64_json` (GPT image models return base64 only, never `url`), `usage` `{ input_tokens, output_tokens, total_tokens, ... }`. The operation answers `images` (a flat array of the base64 strings), `imageCount` and `usage`; `job.outputs = { path: "images", as: "base64" }`. The brief named `data[].b64_json` as the path; the wire policy only takes plain dotted names, so the operation lifts the strings into a flat member. UNVERIFIED: that the engine lifts an ARRAY at `outputs.path` and names each file by position (gm-jobs owns it, as for Deepgram).

## images.edit
- `POST /v1/images/edits`, JSON (https://developers.openai.com/api/reference/resources/images/methods/edit.md): `images` (1..16 of `{ image_url }`; here the source then the references), `prompt`, `mask` (`{ image_url }`; transparent areas are edited, a hint, not a hard shape), `model`, `size`, `n` (1..10), `quality`, `output_format`.
- The `FileRef` members arrive as short-lived signed HTTPS URLs (the engine replaces them before `run`), which is what `image_url` takes. The engine converts the "white = keep" mask to OpenAI's convention (spec A section 1.2). UNVERIFIED: that conversion exists in gm-wire-files.
- `aspect` absent -> `size: "auto"`; present -> the `1k` table entry. Edit quality is `auto` (the edit capability has no quality or size input).

## audio.transcribe: the decision that departs from the brief
https://developers.openai.com/api/docs/guides/speech-to-text and the audio transcription reference page (the `create` method) (read 2026-11-18):
- `gpt-transcribe` returns JSON `{ text, languages }`. The guide says `timestamp_granularities[]` "is only supported for `whisper-1`" (deprecated, shuts down 2027-02-26). The reference page lists `word` timings for `verbose_json` without naming models. The two pages disagree; the guide is the stricter, and `gpt-transcribe` has no documented word timing.
- Every format the capability offers (`srt`, `vtt`, `words`) needs timings, so `gpt-transcribe` alone can serve none of them. The operation therefore calls **`whisper-1`** with `response_format=verbose_json` and `timestamp_granularities[]=word`, and maps `words[]` (`{ word, start, end }`, seconds) through the shared captions mapper of the media folder to SRT and VTT. `duration` (seconds) gives the units billed.
- TODO (before 2027-02-26): swap the one constant when a model other than `whisper-1` documents word timings. Until then Deepgram stays the first captions vendor (the preference is a workspace setting).
- Multipart fields: `file`, `model`, `response_format`, `timestamp_granularities[]`, `language` (ISO 639-1). `language: "auto"` leaves `language` out. File limit 25 MB (the guide): a larger file is refused by the vendor and mapped `input_invalid` through the 400 and 413 statuses. The guide lists `flac, mp3, mp4, mpeg, mpga, m4a, ogg, wav, webm`.
- **Vietnamese is UNVERIFIED**: neither page names it. Whisper-family support of Vietnamese is general knowledge, not read on a page. A person reviews Vietnamese captions with the asset (spec A section 1.9 rule 3).
- UNVERIFIED: whether the engine hands `files.file` the storage key (a multipart part "names it and the engine streams it", SDK doc) or the signed URL the generic `FileRef` replacement would give; the operation passes `input.source` as it is. gm-wire-files owns it.
- Price: gpt-transcribe $0.0045/min (pricing page, read). `whisper-1` is not on the pages read: **$0.006/min is UNVERIFIED** (from memory) and is what the hold uses, so it does not fall short.
- Output: `text`, `words` (ms), `files` (base64, one per requested format in the order given), `audioMinutes`.

## Errors (wire)
Body `{ error: { message, type, param, code } }` (error-codes guide; the full body is not on the page), so `errorField = "error.code"`.

| source | code or status | refusal | page |
|---|---|---|---|
| 429 | `credit_balance_exhausted`, `organization_spend_limit_exceeded`, `project_spend_limit_exceeded`, `organization_usage_limit_exceeded` | `quota_exceeded` | error-codes guide |
| any | `insufficient_quota`, `billing_hard_limit_reached` | `quota_exceeded` | UNVERIFIED (the guide names `insufficient_quota` as an `error.type`, not a code) |
| 400 | `moderation_blocked`, `content_policy_violation` | `content_refused` | UNVERIFIED: no read page lists a moderation code for images |
| 400 | `invalid_image_url` | `input_unreachable` | UNVERIFIED code |
| 400, 413 | any other | `input_invalid` | status rule (size, ratio, file too large) |
| 429 | `slow_down` | transient, 20 s | error-codes guide |
| 429 (no code), 503 `server_is_overloaded`, 401 | | the engine's table (a 401 is a platform alert) | |

TODO: confirm the moderation and bad-URL codes with a real call.

## Facts that do not fit the operation
- `OpenAI-Organization`: sent from the optional `org` field through `auth.headers`; an account that leaves `org` empty sends no header (the engine omits an optional credential header that is empty). A key belongs to a default organization, so the header is optional.
- Idempotency: the pages read document no idempotency header, so `wire.idempotency` is not declared. Each operation declares `wire.dedupe` instead: the engine records an attempt per intent key and never re-sends one whose answer was lost, so a retry cannot bill twice. There is no lookup (the vendor has no list of past generations), so a held attempt stops the run until a person releases it.
- Prices: spec A gives image output $30 / 1M tokens (pricing page read: `gpt-image-2` $8 input and $30 output per 1M image tokens; 2.5 and 2.6 rows not seen). Image operations declare `metered: { usage: "tokens", price: "reported" }`, the answer carries `usage`, and the job reports `imageCount` as `images`. A tokens-metered operation may declare no `estimate` (the SDK build refuses it), so the hold before a run has no figure from these two operations: gap for the engine (estimate from the capability). UNVERIFIED: how the engine combines tokens and images.

## Recorded exchanges
No real key, so `be/src/tests/fixtures/e2e/providers/openai/openai.fixtures.ts` holds documented-shape exchanges, marked `documented`: per operation one success and one refusal. A sync job has no pending sequence. The multipart request of the transcription fixture carries no body, because the fake transport matches JSON bodies only.
