import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"

/**
 * What the platform account of OpenAI holds: the API key (custody env `NIVO_MEDIA_OPENAI_API_KEY`) and, optionally, the organization (`NIVO_MEDIA_OPENAI_ORG`); never typed in a workspace.
 * `org` is public and, when the account has one, is sent as `OpenAI-Organization`; empty, the engine leaves the header out.
 */
export const OpenaiFields = z.strictObject({
    /** The public name of the account (the identity): the instance writes "platform". */
    account: z.string().min(1),
    apiKey: z.string().min(1),
    org: z.string().min(1).optional(),
})

export type OpenaiAccount = z.infer<typeof OpenaiFields>

/**
 * `openai`: images (`gpt-image-2.5`) and transcription for the media capabilities. A platform account: NIVO's key, metered in NIVO credit, never connectable in a workspace. The key travels as
 * `Authorization: Bearer <key>`. See README.md.
 */
export class OpenaiProvider implements Provider<typeof OpenaiFields, z.ZodObject<{}>, {}> {
    readonly key = "openai"
    readonly version = 1
    readonly title = { vi: "OpenAI", en: "OpenAI" }
    readonly description = {
        vi: "Tạo và chỉnh sửa ảnh, chuyển giọng nói thành chữ và phụ đề.",
        en: "Generates and edits images, and turns speech into text and captions.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = OpenaiFields
    readonly secrets = ["apiKey"] as const
    readonly form = {
        account: { label: { vi: "Tên tài khoản", en: "Account name" }, help: { vi: "Tên hiển thị của tài khoản nền tảng.", en: "The display name of the platform account." }, kind: "text", order: 0 },
        apiKey: { label: { vi: "Khoá API", en: "API key" }, help: { vi: "Do nền tảng giữ; không nhập trong không gian làm việc.", en: "Held by the platform; never entered in a workspace." }, kind: "secret", order: 1 },
        org: { label: { vi: "Tổ chức", en: "Organization" }, help: { vi: "Tuỳ chọn; do nền tảng giữ.", en: "Optional; held by the platform." }, kind: "text", order: 2 },
    } as const
    readonly identityField = "account"
    readonly kind = "base"
    readonly accountOwner = "platform"
    readonly base = { fixed: "https://api.openai.com" }
    readonly auth = { scheme: "bearer", secretField: "apiKey", headers: { "openai-organization": { field: "org" } } } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly dataTypes = {}
}
