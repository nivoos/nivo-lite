import { z } from "zod"
import type { JsonValue, Operation, OperationReach } from "@starci/nivoos-sdk"
import { MediaTranscribe, MediaTranscribeInput } from "../media/capabilities/media-transcribe.capability.ts"
import { mediaRefusalsWithFiles } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { base64Of, srtOf, vttOf } from "../media/captions.ts"
import type { CaptionWord } from "../media/captions.ts"
import type { OpenaiAccount } from "./openai.provider.cell.ts"

/** `whisper-1` is the one model whose word timings are documented (README); swap this when another model documents them. */
export const TRANSCRIBE_MODEL = "whisper-1"

export const TranscribeOutput = z.strictObject({
    /** The whole transcript. */
    text: z.string(),
    /** Word timings in milliseconds. */
    words: z.array(z.strictObject({ w: z.string(), startMs: z.number().int().nonnegative(), endMs: z.number().int().nonnegative() })),
    /** One base64 file per requested format, in the order asked; the engine decodes and stores them (`job.outputs`). */
    files: z.array(z.string()),
    /** The length of the audio in minutes: the unit billed (`job.usage`). */
    audioMinutes: z.number().nonnegative(),
})

type In = z.infer<typeof MediaTranscribeInput>
type Out = z.infer<typeof TranscribeOutput>

type Json = { readonly [member: string]: JsonValue }
const isObject = (value: JsonValue | undefined): value is Json => typeof value === "object" && value !== null && !Array.isArray(value)
const numberOf = (value: JsonValue | undefined): number | null => (typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : null)

/** The text, the duration (seconds) and the word timings of a `verbose_json` answer (times in seconds become milliseconds); null when the answer has no word list. */
export const timingsOf = (json: JsonValue | undefined): { readonly text: string; readonly seconds: number; readonly words: ReadonlyArray<CaptionWord> } | null => {
    if (!isObject(json) || typeof json["text"] !== "string" || !Array.isArray(json["words"])) return null
    const words: Array<CaptionWord> = []
    for (const item of json["words"]) {
        if (!isObject(item)) return null
        const start = numberOf(item["start"])
        const end = numberOf(item["end"])
        if (typeof item["word"] !== "string" || start === null || end === null) return null
        words.push({ w: item["word"], startMs: Math.round(start * 1000), endMs: Math.round(end * 1000) })
    }
    const last = words[words.length - 1]
    const duration = numberOf(json["duration"])
    return { text: json["text"], seconds: duration ?? (last === undefined ? 0 : last.endMs / 1000), words }
}

/**
 * `openai.audio.transcribe`: `POST /v1/audio/transcriptions`, multipart (the engine streams `file`; at most 25 MB), `verbose_json` with word timestamps. One long call the engine makes itself
 * (`job.sync`, 180 s). The timings become SRT and VTT through `media/captions.ts`; `files` holds one base64 text per requested format. Vietnamese is UNVERIFIED (README).
 */
export class OpenaiAudioTranscribe implements Operation<typeof MediaTranscribeInput, typeof TranscribeOutput, OpenaiAccount, MediaRefusal> {
    readonly key = "openai.audio.transcribe"
    readonly version = 1
    readonly title = { vi: "Chuyển giọng nói thành chữ (OpenAI)", en: "Transcribe speech (OpenAI)" }
    readonly input = MediaTranscribeInput
    readonly output = TranscribeOutput
    // $0.006 per minute for whisper-1 is UNVERIFIED (README); gpt-transcribe is $0.0045
    readonly semantics = { mutates: true, timeoutMs: 180_000, metered: { usage: "units", price: { usdPerUnit: 0.006 }, estimate: { units: { fixed: 1 } } } } as const
    readonly provider = "openai"
    readonly http = true
    readonly implements = MediaTranscribe
    readonly needs = ["apiKey"] as const
    readonly refusals = mediaRefusalsWithFiles
    readonly job = { sync: true, timeoutMs: 180_000, outputs: { path: "files", as: "base64" }, usage: { path: "audioMinutes", unit: "audio_minutes" } } as const
    readonly wire = {
        dedupe: {},
        errorField: "error.code",
        errorCodes: {
            credit_balance_exhausted: "quota_exceeded",
            organization_spend_limit_exceeded: "quota_exceeded",
            project_spend_limit_exceeded: "quota_exceeded",
            organization_usage_limit_exceeded: "quota_exceeded",
            insufficient_quota: "quota_exceeded",
            billing_hard_limit_reached: "quota_exceeded",
        },
        statusRefusals: { "400": "input_invalid", "413": "input_invalid" },
        transientCodes: { slow_down: { retryAfterSeconds: 20 } },
    } as const

    run(input: In, reach: OperationReach<OpenaiAccount, MediaRefusal>): Out {
        const language = input.language ?? "vi"
        const response = reach.http({
            method: "POST",
            path: "/v1/audio/transcriptions",
            multipart: {
                fields: {
                    model: TRANSCRIBE_MODEL,
                    response_format: "verbose_json",
                    "timestamp_granularities[]": "word",
                    ...(language === "auto" ? {} : { language }),
                },
                files: { file: input.source },
            },
        })
        const timings = response.status === 200 ? timingsOf(response.json) : null
        if (timings === null) return reach.byStatus()
        const options = { maxLineChars: input.maxLineChars ?? 42 }
        const files = (input.formats ?? ["srt"]).map((format) =>
            format === "srt" ? base64Of(srtOf(timings.words, options)) : format === "vtt" ? base64Of(vttOf(timings.words, options)) : base64Of(JSON.stringify(timings.words)),
        )
        return { text: timings.text, words: timings.words.map((word) => ({ w: word.w, startMs: word.startMs, endMs: word.endMs })), files, audioMinutes: timings.seconds / 60 }
    }
}
