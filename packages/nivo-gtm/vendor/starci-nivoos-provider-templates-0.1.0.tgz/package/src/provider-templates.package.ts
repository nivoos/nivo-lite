// The entry of the provider-templates package: `nivoos package build src/provider-templates.package.ts --out seed` type-checks the package and
// writes seed/provider-templates@<version>.json. A provider is ONE folder `src/<key>/` (its `<key>.provider.cell.ts`, one `*.cell.ts` per
// operation and trigger, `logo.svg`, `README.md`); this file only lists them. This package carries providers only: no agent, no workflow.
import type { Package } from "@starci/nivoos-sdk"
import { PACKAGE_KEY } from "./package-key.ts"
// PROVIDERS (imports): one line per provider, in alphabetical order of the folder:
//   import { <Key>Provider } from "./<key>/<key>.provider.cell.ts"
//   import { <Operation> } from "./<key>/<operation>.cell.ts"
//   import { <Trigger> } from "./<key>/<trigger>.cell.ts"
import { DriveAboutGet } from "./google/drive-about-get.cell.ts"
import { DriveFilesCreate } from "./google/drive-files-create.cell.ts"
import { DriveSpreadsheetsList } from "./google/drive-spreadsheets-list.cell.ts"
import { GoogleDriveProvider } from "./google/google-drive.provider.cell.ts"
import { GoogleProvider } from "./google/google.provider.cell.ts"
import { SheetsValuesAppend } from "./google/values-append.cell.ts"
import { SheetsValuesGet } from "./google/values-get.cell.ts"
import { CheckInbox } from "./mail/check-inbox.cell.ts"
import { MailProvider } from "./mail/mail.provider.cell.ts"
import { MailMessageReceived } from "./mail/message-received.cell.ts"
import { PollMessages } from "./mail/poll-messages.cell.ts"
import { MailSendMessage } from "./mail/send-message.cell.ts"
import { CancelPayment } from "./payos/payment-cancel.cell.ts"
import { CreatePayment } from "./payos/payment-create.cell.ts"
import { GetPayment } from "./payos/payment-get.cell.ts"
import { PayosPaymentPaid } from "./payos/payment-paid.cell.ts"
import { PayosProvider } from "./payos/payos.provider.cell.ts"
import { FindTransaction } from "./sepay/find-transaction.cell.ts"
import { ListTransactions } from "./sepay/list-transactions.cell.ts"
import { SepayPaymentPaid } from "./sepay/payment-paid.cell.ts"
import { SepayProvider } from "./sepay/sepay.provider.cell.ts"
import { TransferReceived } from "./sepay/transfer-received.cell.ts"
import { TelegramCallbackAnswer } from "./telegram/callback-answer.cell.ts"
import { TelegramEditMessage } from "./telegram/edit-message.cell.ts"
import { TelegramMe } from "./telegram/me.cell.ts"
import { TelegramMessageReceived } from "./telegram/message-received.cell.ts"
// after message-received: the provider and its first trigger load each other, and the provider must be evaluated before a trigger reads its row schema
import { TelegramCallbackReceived } from "./telegram/callback-received.cell.ts"
import { TelegramSendMessage } from "./telegram/send-message.cell.ts"
import { TelegramProvider } from "./telegram/telegram.provider.cell.ts"
import { TelegramWebhookSet } from "./telegram/webhook-set.cell.ts"
import { ZaloMessageReceived } from "./zalo/message-received.cell.ts"
import { OaProfile } from "./zalo/oa-profile.cell.ts"
import { ZaloSendMessage } from "./zalo/send-message.cell.ts"
import { ZaloProvider } from "./zalo/zalo.provider.cell.ts"

export default {
    package: { key: PACKAGE_KEY, version: "0.1.0", author: "nivoos-lite" },
    // PROVIDERS (cells): the provider class first, then its operations and triggers, one provider per line group.
    cells: [
        GoogleProvider, SheetsValuesAppend, SheetsValuesGet,
        GoogleDriveProvider, DriveAboutGet, DriveFilesCreate, DriveSpreadsheetsList,
        MailProvider, CheckInbox, PollMessages, MailSendMessage, MailMessageReceived,
        PayosProvider, CreatePayment, GetPayment, CancelPayment, PayosPaymentPaid,
        SepayProvider, ListTransactions, FindTransaction, TransferReceived, SepayPaymentPaid,
        TelegramProvider, TelegramMe, TelegramWebhookSet, TelegramSendMessage, TelegramEditMessage, TelegramCallbackAnswer, TelegramMessageReceived, TelegramCallbackReceived,
        ZaloProvider, OaProfile, ZaloSendMessage, ZaloMessageReceived,
    ],
    agents: [],
} satisfies Package
