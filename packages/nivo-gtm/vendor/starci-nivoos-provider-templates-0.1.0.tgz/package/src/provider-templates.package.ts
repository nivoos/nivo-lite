// The entry of the provider-templates package: `nivoos package build src/provider-templates.package.ts --out seed` type-checks the package and
// writes seed/provider-templates@<version>.json. A provider is ONE folder `src/<key>/` (its `<key>.provider.cell.ts`, one `*.cell.ts` per
// operation and trigger, `logo.svg`, `README.md`); this file only lists them. This package carries providers only: no agent, no workflow.
import type { Package } from "@starci/nivoos-sdk"
import { PACKAGE_KEY } from "./package-key.ts"
// PROVIDERS (imports): one line per provider, in alphabetical order of the folder:
//   import { <Key>Provider } from "./<key>/<key>.provider.cell.ts"
//   import { <Operation> } from "./<key>/<operation>.cell.ts"
//   import { <Trigger> } from "./<key>/<trigger>.cell.ts"
import { DeepgramProvider } from "./deepgram/deepgram.provider.cell.ts"
import { DeepgramListen } from "./deepgram/listen.cell.ts"
import { GeoLookup } from "./geo/geo-lookup.capability.ts"
import { GeocodeAddress } from "./geo/lookup.cell.ts"
import { NominatimProvider } from "./geo/nominatim.provider.cell.ts"
import { NominatimStatus } from "./geo/status.cell.ts"
import { DriveAboutGet } from "./google/drive-about-get.cell.ts"
import { DriveFilesCreate } from "./google/drive-files-create.cell.ts"
import { DriveSpreadsheetsList } from "./google/drive-spreadsheets-list.cell.ts"
import { GoogleDriveProvider } from "./google/google-drive.provider.cell.ts"
import { GoogleProvider } from "./google/google.provider.cell.ts"
import { SheetsValuesAppend } from "./google/values-append.cell.ts"
import { SheetsValuesGet } from "./google/values-get.cell.ts"
import { AvatarSpeak } from "./media/capabilities/avatar-speak.capability.ts"
import { ImageEdit } from "./media/capabilities/image-edit.capability.ts"
import { ImageGenerate } from "./media/capabilities/image-generate.capability.ts"
import { MediaTranscribe } from "./media/capabilities/media-transcribe.capability.ts"
import { VideoCompose } from "./media/capabilities/video-compose.capability.ts"
import { VideoFromImage } from "./media/capabilities/video-from-image.capability.ts"
import { VideoGenerate } from "./media/capabilities/video-generate.capability.ts"
import { VoiceSpeak } from "./media/capabilities/voice-speak.capability.ts"
import { CheckInbox } from "./mail/check-inbox.cell.ts"
import { MailProvider } from "./mail/mail.provider.cell.ts"
import { MailMessageReceived } from "./mail/message-received.cell.ts"
import { PollMessages } from "./mail/poll-messages.cell.ts"
import { MailSendMessage } from "./mail/send-message.cell.ts"
import { MetaCommentHide } from "./meta/comment-hide.cell.ts"
import { MetaCommentReply } from "./meta/comment-reply.cell.ts"
import { MetaIgComment } from "./meta/ig-comment.cell.ts"
import { MetaIgCommentHide } from "./meta/ig-comment-hide.cell.ts"
import { MetaIgCommentReply } from "./meta/ig-comment-reply.cell.ts"
import { MetaIgContainerStatus } from "./meta/ig-container-status.cell.ts"
import { MetaIgMediaPublish } from "./meta/ig-media-publish.cell.ts"
import { MetaIgMessages } from "./meta/ig-messages.cell.ts"
import { MetaIgMetrics } from "./meta/ig-metrics.cell.ts"
import { MetaIgPublish } from "./meta/ig-publish.cell.ts"
import { MetaLeadGet } from "./meta/lead-get.cell.ts"
import { MetaLeadsPoll } from "./meta/leads-poll.cell.ts"
import { MetaMe } from "./meta/me.cell.ts"
import { MetaMessages } from "./meta/messages.cell.ts"
import { MetaProvider } from "./meta/meta.provider.cell.ts"
import { MetaPageComment } from "./meta/page-comment.cell.ts"
import { MetaPageLeadgen } from "./meta/page-leadgen.cell.ts"
import { MetaPagePost } from "./meta/page-post.cell.ts"
import { MetaPageSchedule } from "./meta/page-schedule.cell.ts"
import { MetaPageSubscribe } from "./meta/page-subscribe.cell.ts"
import { MetaPostMetrics } from "./meta/post-metrics.cell.ts"
import { ObjectsRepeat } from "./objects/repeat.cell.ts"
import { CancelPayment } from "./payos/payment-cancel.cell.ts"
import { CreatePayment } from "./payos/payment-create.cell.ts"
import { GetPayment } from "./payos/payment-get.cell.ts"
import { PayosPaymentPaid } from "./payos/payment-paid.cell.ts"
import { PayosProvider } from "./payos/payos.provider.cell.ts"
import { FindTransaction } from "./sepay/find-transaction.cell.ts"
import { ListTransactions } from "./sepay/list-transactions.cell.ts"
import { SepayPaymentPaid } from "./sepay/payment-paid.cell.ts"
import { SepayProvider } from "./sepay/sepay.provider.cell.ts"
import { TransferReceived } from "./sepay/transfer-received.cell.ts"
import { SocialCommentHide } from "./social/capabilities/comment-hide.capability.ts"
import { SocialCommentReply } from "./social/capabilities/comment-reply.capability.ts"
import { SocialLeadGet } from "./social/capabilities/lead-get.capability.ts"
import { SocialPostMetrics } from "./social/capabilities/post-metrics.capability.ts"
import { SocialPostPublish } from "./social/capabilities/post-publish.capability.ts"
import { SocialPostSchedule } from "./social/capabilities/post-schedule.capability.ts"
import { SocialCommentReceived } from "./social/events/comment-received.event.ts"
import { SocialLeadReceived } from "./social/events/lead-received.event.ts"
import { SocialMessageReceived } from "./social/events/message-received.event.ts"
import { TelegramCallbackAnswer } from "./telegram/callback-answer.cell.ts"
import { TelegramEditMessage } from "./telegram/edit-message.cell.ts"
import { TelegramMe } from "./telegram/me.cell.ts"
import { TelegramMessageReceived } from "./telegram/message-received.cell.ts"
// after message-received: the provider and its first trigger load each other, and the provider must be evaluated before a trigger reads its row schema
import { TelegramCallbackReceived } from "./telegram/callback-received.cell.ts"
import { TelegramSendMessage } from "./telegram/send-message.cell.ts"
import { TelegramProvider } from "./telegram/telegram.provider.cell.ts"
import { TelegramWebhookSet } from "./telegram/webhook-set.cell.ts"
import { ZaloMessageReceived } from "./zalo/message-received.cell.ts"
import { OaProfile } from "./zalo/oa-profile.cell.ts"
import { ZaloSendMessage } from "./zalo/send-message.cell.ts"
import { ZaloProvider } from "./zalo/zalo.provider.cell.ts"

export default {
    package: { key: PACKAGE_KEY, version: "0.1.0", author: "nivoos-lite" },
    // PROVIDERS (cells): the provider class first, then its operations and triggers, one provider per line group.
    cells: [
        DeepgramProvider, DeepgramListen,
        GeoLookup, NominatimProvider, NominatimStatus, GeocodeAddress,
        GoogleProvider, SheetsValuesAppend, SheetsValuesGet,
        GoogleDriveProvider, DriveAboutGet, DriveFilesCreate, DriveSpreadsheetsList,
        // MEDIA capabilities (gm-p-media-caps): the names the media providers implement
        ImageGenerate, ImageEdit, VideoGenerate, VideoFromImage, AvatarSpeak, VoiceSpeak, MediaTranscribe, VideoCompose,
        MailProvider, CheckInbox, PollMessages, MailSendMessage, MailMessageReceived,
        MetaProvider, MetaMe, MetaPageSubscribe, MetaPagePost, MetaPageSchedule, MetaIgPublish, MetaIgContainerStatus, MetaIgMediaPublish, MetaPostMetrics, MetaIgMetrics, MetaCommentReply, MetaCommentHide, MetaIgCommentReply, MetaIgCommentHide, MetaLeadGet, MetaLeadsPoll, MetaPageComment, MetaIgComment, MetaMessages, MetaIgMessages, MetaPageLeadgen,
        PayosProvider, CreatePayment, GetPayment, CancelPayment, PayosPaymentPaid,
        SepayProvider, ListTransactions, FindTransaction, TransferReceived, SepayPaymentPaid,
        SocialPostPublish, SocialPostSchedule, SocialPostMetrics, SocialCommentReply, SocialCommentHide, SocialLeadGet, SocialCommentReceived, SocialMessageReceived, SocialLeadReceived,
        TelegramProvider, TelegramMe, TelegramWebhookSet, TelegramSendMessage, TelegramEditMessage, TelegramCallbackAnswer, TelegramMessageReceived, TelegramCallbackReceived,
        ZaloProvider, OaProfile, ZaloSendMessage, ZaloMessageReceived,
        // GENERIC NODES (no vendor): ObjectsRepeat makes the instances of a recurring object ahead of time.
        ObjectsRepeat,
    ],
    agents: [],
} satisfies Package
