# payos

payOS payment gateway: create, read and cancel a payment link; receive the signed paid-order webhook. Every vendor fact below was read on
2026-11-16 from payOS's public documentation; what the pages do not say is marked **unknown** and was not guessed.

| Cell | Key | What |
| --- | --- | --- |
| provider | `payos` | fields `clientId` (public), `apiKey`, `checksumKey` (secret); base `https://api-merchant.payos.vn`; API key in `x-api-key`; webhook registration `copy` |
| operation | `payos.payments.create` | `POST /v2/payment-requests`, signed (write) |
| operation | `payos.payments.get` | `GET /v2/payment-requests/{orderCode}` (read); declares `not_found` |
| operation | `payos.payments.cancel` | `POST /v2/payment-requests/{orderCode}/cancel` (write); declares `not_found` |
| trigger | `payos.payment.paid` | webhook; subject `order:<orderCode>`, key `orderCode`; off until switched on |

## Facts and sources
- API reference (paths, headers `x-client-id` + `x-api-key`, required create fields `orderCode`, `amount`, `description`, `cancelUrl`, `returnUrl`,
  `signature`; optional `expiredAt` Unix Int32; `description` limited to 9 characters for bank accounts not linked through payOS; answers
  `code: "00"` with `data`; only 401 and 429 are documented as error statuses): https://payos.vn/docs/api/
- Create signature: HMAC-SHA256 under the channel's Checksum Key over `amount`, `cancelUrl`, `description`, `orderCode`, `returnUrl` sorted by key
  as `key=value` joined with `&`: https://payos.vn/docs/api/
- Webhook body `{ code, desc, success, data{ orderCode, amount, description, accountNumber, reference, transactionDateTime, currency,
  paymentLinkId, code, desc, counterAccount*, virtualAccount* }, signature }`; the endpoint answers any 2XX:
  https://payos.vn/docs/du-lieu-tra-ve/webhook/
- Webhook signature: HMAC-SHA256 hex under the Checksum Key over the sorted `key=value` pairs of `data` joined with `&`; null / undefined become
  an empty text; nested arrays are JSON with sorted keys: https://payos.vn/docs/tich-hop-webhook/kiem-tra-du-lieu-voi-signature/
  The proof is the `signature` member INSIDE the body, so `prove` declares no header and compares through `hmacEquals` against `checksumKey`.

## Unknown (not in the pages read)
- A numeric error code of any refusal (the docs give Vietnamese messages, all filed under 401). So `payos.payments.create` declares NO refusal
  (an "already exists" order is classified by the engine's table), and cancel does not declare "cannot be cancelled".
- The HTTP status of "payment not found". `get` / `cancel` declare `not_found` for **404 as an assumption**; if payOS answers another status the
  refusal never fires and the engine's table decides.
- How the webhook URL is registered (the pages read say nothing; payOS's console is assumed, `registration: copy`), whether payOS retries a
  failed delivery, the range / uniqueness rule of `orderCode` (the caller chooses it, so a retried node sends the same code), the full list of
  status words (`PENDING`, `PAID`, `CANCELLED` appear; others are passed through as text).
- A read of the account's own identity: none documented, so the provider declares no `connectTest` (the connect test answers ok with
  `no_connect_test`).
- Logo: payOS's brand terms for redistribution were not found, so `logo.svg` is a neutral monogram (`mark: "monogram"`).

## Engine primitives this provider uses
1. The Client ID header: the provider declares `auth.headers: { "x-client-id": { field: "clientId" } }`, so the engine sends `x-client-id` next to `x-api-key` on every call; operations pass no credential header.
2. `payos.payments.create` signs its body with `reach.hmacSign({ algorithm: "sha256", secretField: "checksumKey", data })`; the code never holds the Checksum Key. `secret_unavailable` ends the node `unknown`.
3. A `prove` that throws (a non-JSON body to `JSON.parse`) is refused by the engine as "not proven".

