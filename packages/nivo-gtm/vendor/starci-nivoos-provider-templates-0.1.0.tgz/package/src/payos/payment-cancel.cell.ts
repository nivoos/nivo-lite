import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { dataOf, numberMember, textMember } from "./payos-calls.ts"
import type { PayosFields } from "./payos.provider.cell.ts"

export const CancelPaymentInput = z.strictObject({ orderCode: z.number().int().positive(), cancellationReason: z.string().min(1).optional() })
export const CancelPaymentOutput = z.strictObject({
    id: z.string().min(1),
    orderCode: z.number().int(),
    status: z.string().min(1),
    canceledAt: z.string().nullable(),
    cancellationReason: z.string().nullable(),
})

type Fields = z.infer<typeof PayosFields>

/**
 * `payos.payments.cancel`: cancels a payment link by its order code (`POST /v2/payment-requests/{id}/cancel`, https://payos.vn/docs/api/;
 * body `cancellationReason` optional). Declares `not_found` for an HTTP 404 (unverified, as for get). The docs also list "payment order cannot
 * be cancelled" with no status and no code, so that refusal is NOT declared: the engine's table classifies it.
 */
export class CancelPayment implements Operation<typeof CancelPaymentInput, typeof CancelPaymentOutput, Fields, "not_found"> {
    readonly key = "payos.payments.cancel"
    readonly version = 1
    readonly title = { vi: "Huỷ link thanh toán", en: "Cancel a payment link" }
    readonly input = CancelPaymentInput
    readonly output = CancelPaymentOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "payos"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["not_found"] as const

    run(input: z.infer<typeof CancelPaymentInput>, reach: OperationReach<Fields, "not_found">): z.infer<typeof CancelPaymentOutput> {
        const response = reach.http({
            method: "POST",
            path: `/v2/payment-requests/${input.orderCode}/cancel`,
            body: input.cancellationReason === undefined ? {} : { cancellationReason: input.cancellationReason },
        })
        if (response.status === 404) return reach.refuse("not_found")
        const data = dataOf(response)
        if (data === null) return reach.byStatus()
        const id = textMember(data, "id")
        const orderCode = numberMember(data, "orderCode")
        const status = textMember(data, "status")
        if (id === null || orderCode === null || status === null) return reach.byStatus()
        return { id, orderCode, status, canceledAt: textMember(data, "canceledAt"), cancellationReason: textMember(data, "cancellationReason") }
    }
}
