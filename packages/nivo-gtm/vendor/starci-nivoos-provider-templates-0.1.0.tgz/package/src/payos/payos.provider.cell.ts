import { z } from "zod"
import type { DataTypes, Delivery, ProofRequest, Provider, ProviderReach, ReceiveResult } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { signedMessageOf } from "./payos-signature.ts"

/** What an account of payOS connects with: the channel's Client ID (public), its API Key and its Checksum Key (both secret). */
export const PayosFields = z.strictObject({
    clientId: z.string().min(1),
    apiKey: z.string().min(1),
    checksumKey: z.string().min(1),
})

/** payOS proves a webhook by a `signature` member INSIDE the body, not by a header: no header is read. */
export const PayosProof = z.strictObject({})

/**
 * One paid-order delivery, the members of the webhook's `data` (https://payos.vn/docs/du-lieu-tra-ve/webhook/). `orderCode` is kept as text (the
 * subject id and the dedupe key); every other member the page lists is text, except `amount`.
 */
export const PayosPayment = z.strictObject({
    orderCode: z.string().min(1),
    amount: z.number(),
    description: z.string(),
    paymentLinkId: z.string(),
    reference: z.string(),
    transactionDateTime: z.string(),
    currency: z.string(),
    accountNumber: z.string(),
    counterAccountName: z.string(),
    counterAccountNumber: z.string(),
    counterAccountBankName: z.string(),
})

export const PayosData = {
    "payos.payment": { value: PayosPayment, keyMembers: ["orderCode"] },
} as const satisfies DataTypes

type Fields = z.infer<typeof PayosFields>
type Proof = z.infer<typeof PayosProof>

type Json = { readonly [member: string]: unknown }

const isObject = (value: unknown): value is Json => value !== null && typeof value === "object" && !Array.isArray(value)

const textOf = (value: unknown): string => (typeof value === "string" ? value : "")

/**
 * `payos`: payOS payment links (https://payos.vn/docs/api/). Calls carry the API Key in `x-api-key` and the Client ID in `x-client-id` (the engine attaches both). The paid-order
 * webhook is proved by the `signature` member of the body: HMAC-SHA256 hex under the Checksum Key over the sorted `key=value` pairs of `data`.
 */
export class PayosProvider implements Provider<typeof PayosFields, typeof PayosProof, typeof PayosData> {
    readonly key = "payos"
    readonly version = 1
    readonly title = { vi: "payOS", en: "payOS" }
    readonly fields = PayosFields
    readonly secrets = ["apiKey", "checksumKey"] as const
    readonly description = {
        vi: "Cổng thanh toán payOS: tạo và huỷ link thanh toán, nhận thông báo đã thanh toán qua webhook có chữ ký.",
        en: "payOS payment gateway: create and cancel payment links, receive signed paid-order webhooks.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        clientId: { label: { vi: "Client ID", en: "Client ID" }, help: { vi: "Kênh thanh toán trên my.payos.vn, mục thông tin tích hợp.", en: "Your payment channel at my.payos.vn, integration information." }, kind: "text", order: 1 },
        apiKey: { label: { vi: "API Key", en: "API Key" }, help: { vi: "Cùng chỗ với Client ID.", en: "Same place as the Client ID." }, kind: "secret", order: 2 },
        checksumKey: { label: { vi: "Checksum Key", en: "Checksum Key" }, help: { vi: "Cùng chỗ với Client ID; dùng để ký yêu cầu và kiểm chữ ký webhook.", en: "Same place as the Client ID; signs requests and verifies webhook signatures." }, kind: "secret", order: 3 },
    } as const
    readonly identityField = "clientId"
    readonly kind = "base"
    readonly base = { fixed: "https://api-merchant.payos.vn" }
    readonly auth = { scheme: "header", secretField: "apiKey", name: "x-api-key", headers: { "x-client-id": { field: "clientId" } } } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly webhook = { proof: PayosProof, ack: { status: 200, body: { success: true } }, refusedStatus: 401, registration: { kind: "copy" } } as const
    /** Sources: https://payos.vn/docs/api/ (keys), https://payos.vn/docs/du-lieu-tra-ve/webhook/ and https://payos.vn/docs/tich-hop-webhook/kiem-tra-du-lieu-voi-signature/ (webhook, signature). payOS has no READ operation of this provider to check with, so there is no check step. */
    readonly setup = [
        setup.guide({
            key: "keys",
            title: { vi: "Lấy khóa payOS", en: "Get the payOS keys" },
            body: {
                vi: "Bạn cần ba giá trị của kênh thanh toán payOS: **Client ID**, **API Key** và **Checksum Key**. Chỗ lấy chúng trên giao diện payOS không có trong tài liệu chúng tôi đã đọc; xem tài liệu payOS.",
                en: "You need three values of your payOS payment channel: **Client ID**, **API Key** and **Checksum Key**. Where to find them in the payOS screens is not in the documents we read; see the payOS docs.",
            },
            link: { label: { vi: "Tài liệu payOS", en: "payOS docs" }, url: "https://payos.vn/docs/api/" },
        }),
        setup.fields({ key: "keys-form", title: { vi: "Nhập khóa", en: "Enter the keys" }, fields: ["clientId", "apiKey", "checksumKey"] }),
        setup.guide({
            key: "dashboard",
            title: { vi: "Khai báo webhook ở payOS", en: "Declare the webhook at payOS" },
            body: {
                vi: "Dán **địa chỉ webhook ở bước tiếp theo** vào cấu hình webhook của kênh thanh toán trên payOS. payOS ký dữ liệu bằng Checksum Key (HMAC-SHA256) và NIVO kiểm tra chữ ký đó. Nút bấm cụ thể trên payOS không có trong tài liệu chúng tôi đã đọc.",
                en: "Paste the **webhook address of the next step** into the payment channel's webhook setting at payOS. payOS signs the data with the Checksum Key (HMAC-SHA256) and NIVO checks that signature. The exact buttons at payOS are not in the documents we read.",
            },
            link: { label: { vi: "Webhook payOS", en: "payOS webhook" }, url: "https://payos.vn/docs/du-lieu-tra-ve/webhook/" },
        }),
        setup.webhook({ key: "webhook", title: { vi: "Địa chỉ webhook", en: "Webhook address" } }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = PayosData

    /** A delivery is payOS's when `signature` equals the HMAC of its `data` under the account's checksum key. */
    prove(request: ProofRequest<Proof>, reach: ProviderReach<Fields>): boolean {
        const body: unknown = JSON.parse(request.body)
        if (!isObject(body) || !isObject(body["data"]) || typeof body["signature"] !== "string") return false
        return reach.hmacEquals({ algorithm: "sha256", secret: "checksumKey", message: signedMessageOf(body["data"]), presented: body["signature"], encoding: "hex" })
    }

    /** One paid order per delivery: `code` "00" with a `data` that names an order code and an amount. */
    receive(delivery: Delivery, _reach: ProviderReach<Fields>): ReceiveResult<typeof PayosData> {
        const body = delivery.json
        if (!isObject(body)) return { kind: "invalid", why: "not_an_object" }
        if (body["code"] !== "00") return { kind: "ignored", why: "not_a_success" }
        const data = body["data"]
        if (!isObject(data)) return { kind: "invalid", why: "no_data" }
        const orderCode = typeof data["orderCode"] === "number" ? String(data["orderCode"]) : textOf(data["orderCode"])
        if (orderCode === "" || typeof data["amount"] !== "number") return { kind: "invalid", why: "payment_shape" }
        return {
            kind: "rows",
            rows: [
                {
                    type: "payos.payment",
                    key: orderCode,
                    value: {
                        orderCode,
                        amount: data["amount"],
                        description: textOf(data["description"]),
                        paymentLinkId: textOf(data["paymentLinkId"]),
                        reference: textOf(data["reference"]),
                        transactionDateTime: textOf(data["transactionDateTime"]),
                        currency: textOf(data["currency"]),
                        accountNumber: textOf(data["accountNumber"]),
                        counterAccountName: textOf(data["counterAccountName"]),
                        counterAccountNumber: textOf(data["counterAccountNumber"]),
                        counterAccountBankName: textOf(data["counterAccountBankName"]),
                    },
                },
            ],
        }
    }
}
