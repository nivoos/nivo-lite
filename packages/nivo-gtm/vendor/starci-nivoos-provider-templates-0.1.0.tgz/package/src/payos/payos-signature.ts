// payOS signs the `data` of a webhook (and of a create request) with HMAC-SHA256 hex under the channel's checksum key, over `key=value`
// pairs sorted by key and joined with `&` (https://payos.vn/docs/tich-hop-webhook/kiem-tra-du-lieu-voi-signature/). This file only BUILDS the
// message; the engine does the HMAC (`hmacEquals` to verify): no code here holds the key.

const sortedKeys = (value: unknown): unknown => {
    if (Array.isArray(value)) return value.map(sortedKeys)
    if (value === null || typeof value !== "object") return value
    const source = value as { readonly [member: string]: unknown }
    const sorted: { [member: string]: unknown } = {}
    for (const name of Object.keys(source).sort()) sorted[name] = sortedKeys(source[name])
    return sorted
}

/** A value as the signature page's samples print it: null, undefined and the words "null" / "undefined" are empty; an array or object is JSON with its object keys sorted. */
const signedText = (value: unknown): string => {
    if (value === null || value === undefined) return ""
    if (typeof value === "string") return value === "null" || value === "undefined" ? "" : value
    if (typeof value === "object") return JSON.stringify(sortedKeys(value))
    return String(value)
}

/** The message payOS signs: the members of `data` sorted by name, `name=value` joined with `&`. */
export const signedMessageOf = (data: { readonly [member: string]: unknown }): string =>
    Object.keys(data)
        .sort()
        .map((name) => `${name}=${signedText(data[name])}`)
        .join("&")

/** The members a create request signs (https://payos.vn/docs/api/): the message is built from exactly these. */
export const CREATE_SIGNED_MEMBERS = ["amount", "cancelUrl", "description", "orderCode", "returnUrl"] as const
