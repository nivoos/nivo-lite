// The payOS provider alone: the entry the integration spec builds (`loadProject`) so a case deploys exactly this folder. The shipped package lists these cells in provider-templates.package.ts.
import type { Package } from "@starci/nivoos-sdk"
import { CancelPayment } from "./payment-cancel.cell.ts"
import { CreatePayment } from "./payment-create.cell.ts"
import { GetPayment } from "./payment-get.cell.ts"
import { PayosPaymentPaid } from "./payment-paid.cell.ts"
import { PayosProvider } from "./payos.provider.cell.ts"

export default {
    package: { key: "e2e-payos", version: "1.0.0", author: "e2e" },
    cells: [PayosProvider, CreatePayment, GetPayment, CancelPayment, PayosPaymentPaid],
    agents: [],
} satisfies Package
