import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { dataOf, numberMember, textMember } from "./payos-calls.ts"
import { CREATE_SIGNED_MEMBERS, signedMessageOf } from "./payos-signature.ts"
import type { PayosFields } from "./payos.provider.cell.ts"

export const CreatePaymentInput = z.strictObject({
    orderCode: z.number().int().positive(),
    amount: z.number().int().positive(),
    description: z.string().min(1),
    returnUrl: z.url(),
    cancelUrl: z.url(),
    expiredAt: z.number().int().positive().optional(),
})
export const CreatePaymentOutput = z.strictObject({
    paymentLinkId: z.string().min(1),
    orderCode: z.number().int(),
    checkoutUrl: z.string().min(1),
    qrCode: z.string().nullable(),
    amount: z.number().int(),
    status: z.string().min(1),
})

type Fields = z.infer<typeof PayosFields>
type In = z.infer<typeof CreatePaymentInput>
type Out = z.infer<typeof CreatePaymentOutput>

/**
 * `payos.payments.create`: creates a payment link (`POST /v2/payment-requests`, https://payos.vn/docs/api/). The CALLER chooses `orderCode`
 * (an integer; the docs state no range and no uniqueness rule, only the refusal "payment order already exists"), so a retried node sends the
 * same code and the vendor refuses a second link. The request is signed with the account's Checksum Key over amount, cancelUrl, description,
 * orderCode and returnUrl. A write: an answer lost after sending is `unknown`.
 */
export class CreatePayment implements Operation<typeof CreatePaymentInput, typeof CreatePaymentOutput, Fields, never> {
    readonly key = "payos.payments.create"
    readonly version = 1
    readonly title = { vi: "Tạo link thanh toán", en: "Create a payment link" }
    readonly input = CreatePaymentInput
    readonly output = CreatePaymentOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "payos"
    readonly http = true
    readonly needs = ["apiKey", "checksumKey"] as const
    readonly refusals = [] as const

    run(input: In, reach: OperationReach<Fields, never>): Out {
        const signed = { amount: input.amount, cancelUrl: input.cancelUrl, description: input.description, orderCode: input.orderCode, returnUrl: input.returnUrl }
        const members: { [member: string]: string | number } = {}
        for (const name of CREATE_SIGNED_MEMBERS) members[name] = signed[name]
        const signature = reach.hmacSign({ algorithm: "sha256", secretField: "checksumKey", data: signedMessageOf(members) })
        if (signature.error !== null) return reach.unknown(signature.error.code)
        const response = reach.http({
            method: "POST",
            path: "/v2/payment-requests",
            body: { ...signed, ...(input.expiredAt === undefined ? {} : { expiredAt: input.expiredAt }), signature: signature.result.hex },
        })
        const data = dataOf(response)
        if (data === null) return reach.byStatus()
        const paymentLinkId = textMember(data, "paymentLinkId")
        const checkoutUrl = textMember(data, "checkoutUrl")
        const orderCode = numberMember(data, "orderCode")
        const amount = numberMember(data, "amount")
        const status = textMember(data, "status")
        if (paymentLinkId === null || checkoutUrl === null || orderCode === null || amount === null || status === null) return reach.byStatus()
        return { paymentLinkId, orderCode, checkoutUrl, qrCode: textMember(data, "qrCode"), amount, status }
    }
}
