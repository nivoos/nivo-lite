import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { PayosPayment } from "./payos.provider.cell.ts"

type Row = z.infer<typeof PayosPayment>

/** `payos.payment.paid`: one signed paid-order webhook is one event on the subject `order:<orderCode>`, keyed by the order code (a repeated delivery is one event). Off until a person switches it on. */
export class PayosPaymentPaid implements Trigger<typeof PayosPayment, typeof PayosPayment> {
    readonly key = "payos.payment.paid"
    readonly version = 1
    readonly title = { vi: "Đơn đã thanh toán", en: "Payment paid" }
    readonly row = PayosPayment
    readonly event = PayosPayment
    readonly provider = "payos"
    readonly dataType = { providerVersion: 1, key: "payos.payment" }
    readonly keyMember = "orderCode"
    readonly subjectKind = "order"
    readonly subjectMember = "orderCode"
    readonly vias = ["webhook"] as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Row> | null {
        return { id: row.orderCode, data: row }
    }
}
