import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { dataOf, numberMember, textMember } from "./payos-calls.ts"
import type { PayosFields } from "./payos.provider.cell.ts"

export const GetPaymentInput = z.strictObject({ orderCode: z.number().int().positive() })
export const PaymentInfo = z.strictObject({
    id: z.string().min(1),
    orderCode: z.number().int(),
    amount: z.number().int(),
    amountPaid: z.number().int().nullable(),
    amountRemaining: z.number().int().nullable(),
    status: z.string().min(1),
})

type Fields = z.infer<typeof PayosFields>

/**
 * `payos.payments.get`: reads a payment link by its order code (`GET /v2/payment-requests/{id}`, https://payos.vn/docs/api/). Declares the
 * refusal `not_found` for an HTTP 404; the docs list "payment not found" but name no status for it (README: unverified).
 */
export class GetPayment implements Operation<typeof GetPaymentInput, typeof PaymentInfo, Fields, "not_found"> {
    readonly key = "payos.payments.get"
    readonly version = 1
    readonly title = { vi: "Xem link thanh toán", en: "Get a payment link" }
    readonly input = GetPaymentInput
    readonly output = PaymentInfo
    readonly semantics = { mutates: false }
    readonly provider = "payos"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["not_found"] as const

    run(input: z.infer<typeof GetPaymentInput>, reach: OperationReach<Fields, "not_found">): z.infer<typeof PaymentInfo> {
        const response = reach.http({ method: "GET", path: `/v2/payment-requests/${input.orderCode}` })
        if (response.status === 404) return reach.refuse("not_found")
        const data = dataOf(response)
        if (data === null) return reach.byStatus()
        const id = textMember(data, "id")
        const orderCode = numberMember(data, "orderCode")
        const amount = numberMember(data, "amount")
        const status = textMember(data, "status")
        if (id === null || orderCode === null || amount === null || status === null) return reach.byStatus()
        return { id, orderCode, amount, amountPaid: numberMember(data, "amountPaid"), amountRemaining: numberMember(data, "amountRemaining"), status }
    }
}
