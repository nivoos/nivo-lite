import type { HttpResponse, JsonValue } from "@starci/nivoos-sdk"

type Json = { readonly [member: string]: JsonValue }

const isObject = (value: JsonValue | undefined): value is Json => value !== undefined && value !== null && typeof value === "object" && !Array.isArray(value)

/** The `data` object of a payOS answer whose wrapper says `code: "00"`, or null (any other answer is the engine's to classify). */
export const dataOf = (response: HttpResponse): Json | null => {
    const body = response.json
    if (response.status !== 200 || !isObject(body) || body["code"] !== "00") return null
    const data = body["data"]
    return isObject(data) ? data : null
}

export const textMember = (data: Json, name: string): string | null => {
    const value = data[name]
    return typeof value === "string" && value !== "" ? value : null
}

export const numberMember = (data: Json, name: string): number | null => {
    const value = data[name]
    return typeof value === "number" && Number.isSafeInteger(value) ? value : null
}
