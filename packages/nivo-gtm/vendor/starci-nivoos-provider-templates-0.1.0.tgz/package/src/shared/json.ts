/** The shared reading helpers of the provider templates: one copy of the object test every operation used to carry itself. Pure; a stored cell takes them by relative import. */

/** A JSON object (not null, not a list). */
export const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/** The member of a JSON object, or undefined when the value is not one. */
export const member = (value: unknown, name: string): unknown => (isObject(value) ? value[name] : undefined)
