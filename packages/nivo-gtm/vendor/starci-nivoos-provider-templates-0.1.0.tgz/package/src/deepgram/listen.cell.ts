import { z } from "zod"
import type { JsonValue, Operation, OperationReach } from "@starci/nivoos-sdk"
import { MediaTranscribe, MediaTranscribeInput } from "../media/capabilities/media-transcribe.capability.ts"
import { mediaRefusalsWithFiles } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { base64Of, srtOf, vttOf } from "../media/captions.ts"
import type { CaptionWord } from "../media/captions.ts"
import type { DeepgramAccount } from "./deepgram.provider.cell.ts"

export const ListenOutput = z.strictObject({
    /** The whole transcript. */
    text: z.string(),
    /** Word timings in milliseconds. */
    words: z.array(z.strictObject({ w: z.string(), startMs: z.number().int().nonnegative(), endMs: z.number().int().nonnegative() })),
    /** One base64 file per requested format, in the order srt, vtt, words (a JSON array of the timings); the engine decodes and stores them (`job.outputs`). */
    files: z.array(z.string()),
    /** The length of the audio in minutes: the unit billed (`job.usage`). */
    audioMinutes: z.number().nonnegative(),
})

type In = z.infer<typeof MediaTranscribeInput>
type Out = z.infer<typeof ListenOutput>
type Refusal = MediaRefusal

type Json = { readonly [member: string]: JsonValue }
const isObject = (value: JsonValue | undefined): value is Json => typeof value === "object" && value !== null && !Array.isArray(value)
const numberOf = (value: JsonValue | undefined): number | null => (typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : null)
const listOf = (value: JsonValue | undefined): ReadonlyArray<JsonValue> => (Array.isArray(value) ? value : [])

/** The timings of an answer: the words of the first alternative (the punctuated form when smart_format gave one), else the utterances; null when the answer has neither shape. Seconds become milliseconds. */
export const timingsOf = (json: JsonValue | undefined): { readonly text: string; readonly words: ReadonlyArray<CaptionWord> } | null => {
    if (!isObject(json) || !isObject(json["results"])) return null
    const results = json["results"]
    const channel = listOf(results["channels"])[0]
    const alternative = isObject(channel) ? listOf(channel["alternatives"])[0] : undefined
    if (!isObject(alternative)) return null
    const words: Array<CaptionWord> = []
    for (const item of listOf(alternative["words"])) {
        if (!isObject(item)) return null
        const word = item["punctuated_word"] ?? item["word"]
        const start = numberOf(item["start"])
        const end = numberOf(item["end"])
        if (typeof word !== "string" || start === null || end === null) return null
        words.push({ w: word, startMs: Math.round(start * 1000), endMs: Math.round(end * 1000) })
    }
    if (words.length === 0) {
        for (const item of listOf(results["utterances"])) {
            if (!isObject(item)) return null
            const start = numberOf(item["start"])
            const end = numberOf(item["end"])
            if (typeof item["transcript"] !== "string" || start === null || end === null) return null
            words.push({ w: item["transcript"], startMs: Math.round(start * 1000), endMs: Math.round(end * 1000) })
        }
    }
    const transcript = alternative["transcript"]
    return { text: typeof transcript === "string" ? transcript : words.map((word) => word.w).join(" "), words }
}

/**
 * `deepgram.listen`: `POST /v1/listen?model=nova-3&language=vi&utterances=true&smart_format=true` with `{ url }` (the engine has replaced the `FileRef` with a signed address the vendor fetches). One
 * long call the engine makes itself (`job.sync`, 300 s): Deepgram has no status read, so the callback form cannot be declared (README). The answer's timings become SRT and VTT through
 * `media/captions.ts`; `files` holds one base64 text per requested format, in the order srt, vtt, words.
 */
export class DeepgramListen implements Operation<typeof MediaTranscribeInput, typeof ListenOutput, DeepgramAccount, Refusal> {
    readonly key = "deepgram.listen"
    readonly version = 1
    readonly title = { vi: "Chuyển giọng nói thành chữ (Deepgram)", en: "Transcribe speech (Deepgram)" }
    readonly input = MediaTranscribeInput
    readonly output = ListenOutput
    // $0.0052 per minute is Deepgram's multilingual price, the higher of the two nova-3 prices (README): the hold never falls short
    readonly semantics = { mutates: true, timeoutMs: 300_000, metered: { usage: "units", price: { usdPerUnit: 0.0052 }, estimate: { units: { fixed: 1 } } } } as const
    readonly provider = "deepgram"
    readonly http = true
    readonly implements = MediaTranscribe
    readonly needs = ["apiKey"] as const
    readonly refusals = mediaRefusalsWithFiles
    readonly job = { sync: true, timeoutMs: 300_000, outputs: { path: "files", as: "base64" }, usage: { path: "audioMinutes", unit: "audio_minutes" } } as const
    readonly wire = {
        errorField: "err_code",
        errorCodes: { "Bad Request": "input_invalid", ASR_PAYMENT_REQUIRED: "quota_exceeded", ASR_UNPROCESSABLE_ENTITY: "input_unreachable" },
        transientCodes: { TOO_MANY_REQUESTS: { retryAfterSeconds: 30 } },
    } as const

    run(input: In, reach: OperationReach<DeepgramAccount, Refusal>): Out {
        const language = input.language ?? "vi"
        const response = reach.http({
            method: "POST",
            path: "/v1/listen",
            query: { model: "nova-3", language: language === "auto" ? "multi" : language, utterances: true, smart_format: true },
            headers: { "content-type": "application/json" },
            body: { url: input.source.file },
        })
        const timings = response.status === 200 ? timingsOf(response.json) : null
        if (timings === null) return reach.byStatus()
        const metadata = isObject(response.json) ? response.json["metadata"] : undefined
        const duration = isObject(metadata) ? numberOf(metadata["duration"]) : null
        const options = { maxLineChars: input.maxLineChars ?? 42 }
        const files = (input.formats ?? ["srt"]).map((format) =>
            format === "srt" ? base64Of(srtOf(timings.words, options)) : format === "vtt" ? base64Of(vttOf(timings.words, options)) : base64Of(JSON.stringify(timings.words)),
        )
        return { text: timings.text, words: timings.words.map((word) => ({ w: word.w, startMs: word.startMs, endMs: word.endMs })), files, audioMinutes: duration === null ? 0 : duration / 60 }
    }
}
