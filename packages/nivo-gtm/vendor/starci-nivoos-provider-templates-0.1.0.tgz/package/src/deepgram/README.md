# deepgram

Deepgram speech-to-text for `media.transcribe` (spec A section 1.7, lane gm-p-captions). Pages read 2026-11-18. Anything not on a cited page is marked UNVERIFIED.

## What it is
- Provider `deepgram`, `accountOwner: "platform"`. Account field `apiKey` (secret). The instance makes the account at boot from the custody variable of spec A section 7 (the name is the upper-case form of nivo-media-deepgram-api-key; no typed env reader declares it yet, so it is not written out here); a workspace never sees or edits it. The key is the owner's: no real key was entered here.
- Operation `deepgram.listen` implements `media.transcribe`. It maps the vendor's answer and the shared pure mapper of this package (the captions file of the media folder) (SRT, VTT) to the output. It never loops on a status read.
- Logo: neutral monogram; Deepgram's brand terms were not checked.

## Auth (was UNVERIFIED, now resolved)
- `Authorization: Token <api key>`: https://developers.deepgram.com/docs/pre-recorded-audio (read 2026-11-18). Declared as `auth: { scheme: "header", name: "authorization", prefix: "Token ", secretField: "apiKey" }`.

## Request
- `POST https://api.deepgram.com/v1/listen?model=nova-3&language=vi&utterances=true&smart_format=true`, `Content-Type: application/json`, body `{ "url": "<signed url>" }`: same page. The `FileRef` of `source` is replaced by the engine with a short-lived signed address; the vendor fetches it, so there is no upload.
- Language: `vi` -> `language=vi`; `en` -> `language=en`; `auto` -> `language=multi` (nova-3 multilingual, https://developers.deepgram.com/docs/models-languages-overview as cited by spec A; the page was not re-read). Vietnamese on nova-3 is from spec A; no WER is published.
- Cost: $0.0043/min (nova-3 mono), $0.0052 multi (https://deepgram.com/pricing, from spec A, not re-read). Units reported: `audio_minutes` = `metadata.duration` / 60.

## Answer used
- `metadata.request_id`, `metadata.duration` (seconds).
- `results.channels[0].alternatives[0]`: `transcript`, `words[]` of `{ word, start, end, confidence, punctuated_word }` (`punctuated_word` with `smart_format`), times in seconds (pre-recorded-audio page; times in seconds are from the utterances page https://developers.deepgram.com/docs/utterances).
- `results.utterances[]`: `{ start, end, transcript, words, id }`, seconds (utterances page). The `pre-recorded-audio` page does not mention `utterances`; the utterances page does.
- Captions are made from `punctuated_word` timings when present, else from `word`, else from the utterances (each utterance is split into words and its time shared by length, see the mapper in the captions file of the media folder). Deepgram has no SRT parameter; the mapper does it (spec A section 1.7). Diacritics pass through untouched.

## Errors (https://developers.deepgram.com/docs/errors, read 2026-11-18)
Body `{ err_code, err_msg, request_id }` (so `wire.errorField = "err_code"`), except invalid json (code) which uses `category`.
| status | err_code | refusal |
|---|---|---|
| 400 | `Bad Request` (corrupt or unsupported audio, or a URL without a JSON content type) | `input_invalid` |
| 400 | invalid json (code) | not mapped (our bug): classified by the engine's table |
| 401 | invalid auth (code), insufficient permissions (code) | engine table (platform alert) |
| 402 | asr payment required (code) | `quota_exceeded` |
| 422 | asr unprocessable entity (code) | `input_unreachable` (the page says the audio was incomplete or interrupted) |
| 429 | too many requests (code) | `wire.transientCodes`, 30 s |
The page lists no code for "the URL could not be fetched" in speech-to-text (remote content error (code) is in the text-to-speech section): such a failure is expected as `Bad Request` and is mapped to `input_invalid`. TODO: confirm with a real call.

## Short and long files: decision
- Deepgram has NO status or get-by-request-id endpoint, and does not store transcripts (pre-recorded-audio page: the response is the only chance to read it). `callback=` answers `{ request_id }` at once and POSTs the result to the callback URL once, retried 10 times 30 s apart (https://developers.deepgram.com/docs/callback). A job of the `status` form needs a read operation, which Deepgram does not offer, so the callback form cannot be declared.
- Decision: every file takes the **`job.sync`** path with `timeoutMs: 300000` (the platform maximum for a sync operation, which runs in the media worker). Deepgram transcribes far faster than real time (UNVERIFIED figure: no page read gives one), so 5 minutes covers long recordings. A file that does not finish ends as `job_timeout` (the engine's refusal). `callback=` is not used; the unsigned callback door of spec A section 2.7 is not needed by this provider.

## Output files
`job.outputs = { path: "files", as: "base64" }`: the operation answers `files`, one base64 string per requested format in the order `srt`, `vtt`, `words` (a JSON array `[{ w, startMs, endMs }]`), plus `text` and `words`. The engine decodes, stores, probes and builds the `MediaFile` list (spec A section 3). UNVERIFIED: the engine's lift of an ARRAY at `outputs.path` and its naming of each file by position; gm-jobs owns it.

## Recorded exchanges
No real key: the fixtures under `be/src/tests/fixtures/e2e/providers/deepgram/` are built from the documented examples above and marked `documented`, not recorded. A sync job has no pending sequence, so there is none.
