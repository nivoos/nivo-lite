import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"

/** What the platform account of Deepgram holds: the API key, from the instance's custody env `NIVO_MEDIA_DEEPGRAM_API_KEY` (never typed in a workspace). */
export const DeepgramFields = z.strictObject({
    /** The public name of the account (the identity): the instance writes "platform". */
    account: z.string().min(1),
    apiKey: z.string().min(1),
})

export type DeepgramAccount = z.infer<typeof DeepgramFields>

/**
 * `deepgram`: speech to text (nova-3) for `media.transcribe`. A platform account: NIVO's key, metered in NIVO credit, never connectable in a workspace. The key travels as
 * `Authorization: Token <key>` (https://developers.deepgram.com/docs/pre-recorded-audio). See README.md.
 */
export class DeepgramProvider implements Provider<typeof DeepgramFields, z.ZodObject<{}>, {}> {
    readonly key = "deepgram"
    readonly version = 1
    readonly title = { vi: "Deepgram", en: "Deepgram" }
    readonly description = {
        vi: "Chuyển giọng nói thành chữ và phụ đề (SRT, VTT) cho tiếng Việt và các ngôn ngữ khác.",
        en: "Turns speech into text and captions (SRT, VTT) in Vietnamese and other languages.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = DeepgramFields
    readonly secrets = ["apiKey"] as const
    readonly form = {
        account: { label: { vi: "Tên tài khoản", en: "Account name" }, help: { vi: "Tên hiển thị của tài khoản nền tảng.", en: "The display name of the platform account." }, kind: "text", order: 0 },
        apiKey: { label: { vi: "Khoá API", en: "API key" }, help: { vi: "Do nền tảng giữ; không nhập trong không gian làm việc.", en: "Held by the platform; never entered in a workspace." }, kind: "secret", order: 1 },
    } as const
    readonly identityField = "account"
    readonly kind = "base"
    readonly accountOwner = "platform"
    readonly base = { fixed: "https://api.deepgram.com" }
    readonly auth = { scheme: "header", name: "authorization", prefix: "Token ", secretField: "apiKey" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly dataTypes = {}
}
