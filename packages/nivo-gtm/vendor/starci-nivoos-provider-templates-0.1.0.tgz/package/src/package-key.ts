/** The package key: the ONE place it is written; every provider, operation and trigger key of the package starts with its own provider key. */
export const PACKAGE_KEY = "provider-templates"
