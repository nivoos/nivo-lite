import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { GeoLookup, GeoLookupInput, GeoLookupOutput } from "./geo-lookup.capability.ts"
import type { NominatimAccount } from "./nominatim.provider.cell.ts"

type In = z.infer<typeof GeoLookupInput>
type Out = z.infer<typeof GeoLookupOutput>

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)
const numberOf = (value: unknown): number | null => {
    const parsed = typeof value === "number" ? value : typeof value === "string" && value !== "" ? Number(value) : Number.NaN
    return Number.isFinite(parsed) ? parsed : null
}

/**
 * `nominatim.geo.lookup`: the best match of an address (`GET /search?q=<address>&format=jsonv2&limit=1`, optionally `countrycodes`). Nominatim writes `lat` and `lon` as TEXT; they are read as numbers
 * here. An empty list is the vendor's "no such place": declared as `address_not_found`, so a node can leave `location` empty and say so. A read, and the one geocoding door: no node or template calls a vendor.
 */
export class GeocodeAddress implements Operation<typeof GeoLookupInput, typeof GeoLookupOutput, NominatimAccount, "address_not_found"> {
    readonly key = "nominatim.geo.lookup"
    readonly version = 1
    readonly title = { vi: "Tìm toạ độ từ địa chỉ", en: "Find the point of an address" }
    readonly input = GeoLookupInput
    readonly output = GeoLookupOutput
    readonly semantics = { mutates: false }
    readonly provider = "nominatim"
    readonly http = true
    readonly implements = GeoLookup
    readonly needs = ["baseUrl", "userAgent"] as const
    readonly refusals = ["address_not_found"] as const

    run(input: In, reach: OperationReach<NominatimAccount, "address_not_found">): Out {
        const query: { [name: string]: string | number } = { q: input.address, format: "jsonv2", limit: 1 }
        if (input.countryCode !== undefined) query["countrycodes"] = input.countryCode
        const answer = reach.http({ method: "GET", path: "/search", query })
        if (answer.status !== 200 || !Array.isArray(answer.json)) return reach.byStatus()
        const first: unknown = answer.json[0]
        if (first === undefined) return reach.refuse("address_not_found")
        if (!isObject(first)) return reach.unknown("search_shape")
        const lat = numberOf(first["lat"])
        const lng = numberOf(first["lon"])
        if (lat === null || lng === null || lat < -90 || lat > 90 || lng < -180 || lng > 180) return reach.unknown("search_shape")
        const label = first["display_name"]
        const kind = first["addresstype"] ?? first["type"]
        return { point: { lat, lng }, label: typeof label === "string" ? label : input.address, kind: typeof kind === "string" ? kind : "place" }
    }
}
