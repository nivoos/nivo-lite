import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const StatusInput = z.strictObject({})
export const StatusOutput = z.strictObject({ message: z.string() })

/** `nominatim.status.get`: the connect test: the server's own status (`GET /status?format=json`, `status` 0 and `message` "OK" when it can answer searches). */
export class NominatimStatus implements Operation<typeof StatusInput, typeof StatusOutput, never> {
    readonly key = "nominatim.status.get"
    readonly version = 1
    readonly title = { vi: "Trạng thái máy chủ bản đồ", en: "Map server status" }
    readonly input = StatusInput
    readonly output = StatusOutput
    readonly semantics = { mutates: false }
    readonly provider = "nominatim"
    readonly http = true
    readonly needs = ["baseUrl", "userAgent"] as const
    readonly refusals = [] as const

    run(_input: z.infer<typeof StatusInput>, reach: OperationReach<never>): z.infer<typeof StatusOutput> {
        const answer = reach.http({ method: "GET", path: "/status", query: { format: "json" } })
        if (answer.status !== 200 || typeof answer.json !== "object" || answer.json === null || Array.isArray(answer.json)) return reach.byStatus()
        const body = answer.json as { readonly [member: string]: unknown }
        if (body["status"] !== 0) return reach.unknown("status_not_ok")
        return { message: typeof body["message"] === "string" ? body["message"] : "OK" }
    }
}
