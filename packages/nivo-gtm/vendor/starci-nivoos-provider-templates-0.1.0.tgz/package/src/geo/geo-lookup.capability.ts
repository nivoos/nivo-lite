import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"

export const GeoLookupInput = z.strictObject({
    /** The address as a person writes it: street, ward, district, city. */
    address: z.string().min(3).max(300),
    /** Look only in this country (two letters, ISO 3166-1 alpha-2, lower case): `vn`. */
    countryCode: z.string().regex(/^[a-z]{2}$/u).optional(),
})

export const GeoLookupOutput = z.strictObject({
    /** The point a map pin goes at: the `geo` field value of an object (`{ lat, lng }`, degrees). */
    point: z.strictObject({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) }),
    /** The place the geocoder matched, written out in full: show it to a person who checks the pin. */
    label: z.string(),
    /** What the match is (`house`, `road`, `suburb`, `city`, ...): the coarser it is, the less exact the pin. */
    kind: z.string(),
})

/** `geo.lookup`: the provider-neutral name of "address in, map point out"; an operation of any geocoder implements it and declares `address_not_found`. A write of an object's `location` is the caller's own step. */
export class GeoLookup implements Capability<typeof GeoLookupInput, typeof GeoLookupOutput> {
    readonly key = "geo.lookup"
    readonly version = 1
    readonly title = { vi: "Tìm toạ độ từ địa chỉ", en: "Find the point of an address" }
    readonly input = GeoLookupInput
    readonly output = GeoLookupOutput
    readonly semantics = { mutates: false }
}
