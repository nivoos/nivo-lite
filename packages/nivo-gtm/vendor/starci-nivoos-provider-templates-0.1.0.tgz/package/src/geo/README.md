# nominatim (geo.lookup)

Address to map point, behind a provider. Nothing here calls a vendor from a cell except through the engine's provider door (`reach.http`, base and `User-Agent` set by the account).
Vendor facts below were written from the vendor's public pages by memory of them and NOT re-fetched in this lane (2026-11-18): every one marked UNVERIFIED must be checked against the page cited before the first real account.

## What it is
- Capability `geo.lookup` (`geo-lookup.capability.ts`): `{ address, countryCode? }` -> `{ point: { lat, lng }, label, kind }`. Any geocoder implements it; `point` is the value of a `geo` field.
- Provider `nominatim`: account fields `baseUrl` (https, public, identity) and `userAgent` (public). No secret, `auth.scheme: "none"`; the engine attaches `User-Agent` from the account (`auth.headers`), a source cannot set it.
- Operations: `nominatim.geo.lookup` (read; implements `geo.lookup`; declares `address_not_found`), `nominatim.status.get` (read; the connect test).
- A node that fills an object's `location` calls `geo.lookup` (or the operation) and writes the point itself: the template never geocodes.

## Vendor facts (UNVERIFIED, re-check)
- Search: `GET {base}/search?q=<free text>&format=jsonv2&limit=1[&countrycodes=vn]`, answer a JSON list of places: `lat` and `lon` as TEXT, `display_name`, `type`, `addresstype`, `importance`; an empty list means no match (https://nominatim.org/release-docs/latest/api/Search/).
- Status: `GET {base}/status?format=json` answers `{ "status": 0, "message": "OK" }` when it works (https://nominatim.org/release-docs/latest/api/Status/).
- Public server usage policy: at most 1 request a second, a valid `User-Agent` that identifies the application, no bulk geocoding, results may be cached (https://operations.osmfoundation.org/policies/nominatim/). For volume, host Nominatim or point `baseUrl` at a service with the same `/search` answer.
- Data is OpenStreetMap's (ODbL); show the attribution where the pins are shown.
- Logo: neutral monogram (`mark: "monogram"`).

## Gaps
- ENGINE GAP: read-operation rate limit. `ProviderRate` (`rate.perAccount`) covers mutating operations only, so nothing in the engine holds the public server to 1 request a second for `nominatim.geo.lookup`. Pacing is IT logic and belongs in the engine, so it is deliberately NOT done in a workflow or in this package; declare it on the provider once the engine takes a rate for read operations (lane/engine-provider-decl `wire` had no such field when checked 2026-11-18; the branch was not yet on origin).
- No recorded fixtures yet and no unit specs (lane order).
