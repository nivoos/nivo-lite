import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { NominatimStatus } from "./status.cell.ts"

/** What an account of a Nominatim-shaped geocoder holds, all public: its address and the name the engine sends as `User-Agent`. */
export const NominatimFields = z.strictObject({
    baseUrl: z.url().startsWith("https://"),
    userAgent: z.string().min(8).max(200),
})

export type NominatimAccount = z.infer<typeof NominatimFields>

/**
 * `nominatim`: address to point through the Nominatim API (OpenStreetMap's geocoder, or a Nominatim you host, or a service with the same `/search` answer). No credential: the public server
 * asks that every client names itself in `User-Agent` and keeps to one request a second (see README.md), so the account holds the name and the engine attaches it. The cell never calls the
 * vendor itself: every request goes through the engine's provider door.
 */
export class NominatimProvider implements Provider<typeof NominatimFields, z.ZodObject<{}>, {}> {
    readonly key = "nominatim"
    readonly version = 1
    readonly title = { vi: "Bản đồ OpenStreetMap (Nominatim)", en: "OpenStreetMap geocoder (Nominatim)" }
    readonly description = {
        vi: "Đổi một địa chỉ thành toạ độ để ghim lên bản đồ. Dùng máy chủ Nominatim công cộng hoặc máy chủ bạn tự dựng.",
        en: "Turns an address into a map point. Uses the public Nominatim server or one you host yourself.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = NominatimFields
    readonly secrets = [] as const
    readonly form = {
        baseUrl: {
            label: { vi: "Địa chỉ máy chủ", en: "Server address" },
            help: { vi: "Máy chủ công cộng chỉ nên dùng cho khối lượng nhỏ; khối lượng lớn hãy tự dựng Nominatim.", en: "The public server is for small volumes only; host Nominatim yourself for more." },
            placeholder: { vi: "https://nominatim.openstreetmap.org", en: "https://nominatim.openstreetmap.org" },
            kind: "url",
            order: 1,
        },
        userAgent: {
            label: { vi: "Tên ứng dụng gửi kèm", en: "Application name sent along" },
            help: { vi: "Máy chủ công cộng yêu cầu một tên nhận diện ứng dụng và cách liên hệ, ví dụ \"tenphongkham-geocoder/1.0 (lienhe@congty.vn)\".", en: "The public server requires a name that identifies the application and how to reach you, for example \"myshop-geocoder/1.0 (contact@myshop.example)\"." },
            kind: "text",
            order: 2,
        },
    } as const
    readonly identityField = "baseUrl"
    readonly kind = "base"
    readonly base = { field: "baseUrl" } as const
    readonly auth = { scheme: "none", headers: { "user-agent": { field: "userAgent" } } } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly connectTest = "nominatim.status.get"
    /** Source: https://nominatim.org/release-docs/latest/api/Search/ and the usage policy https://operations.osmfoundation.org/policies/nominatim/ (see README.md). */
    readonly setup = [
        setup.fields({
            key: "server",
            title: { vi: "Máy chủ và tên ứng dụng", en: "Server and application name" },
            body: {
                vi: "Nhập địa chỉ máy chủ Nominatim và tên ứng dụng gửi kèm mỗi yêu cầu. Máy chủ công cộng giới hạn một yêu cầu mỗi giây và không dành cho khối lượng lớn.",
                en: "Enter the address of the Nominatim server and the application name sent with each request. The public server allows one request a second and is not for bulk use.",
            },
            fields: ["baseUrl", "userAgent"],
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra kết nối", en: "Check the connection" }, operation: NominatimStatus }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = {}
}
