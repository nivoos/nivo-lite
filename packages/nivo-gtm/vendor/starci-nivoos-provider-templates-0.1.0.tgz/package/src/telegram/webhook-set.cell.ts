import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

/** `webhookSecret` is the account's own secret token, which the engine attaches by name (the author's code never holds it elsewhere). */
export const WebhookSetInput = z.strictObject({ url: z.string().min(1), webhookSecret: z.string().min(1) })
export const WebhookSetOutput = z.strictObject({ registered: z.literal(true) })

/** `telegram.webhook.set`: setWebhook with the URL of the account and its secret token; `message` updates and button presses (`callback_query`) are asked for. */
export class TelegramWebhookSet implements Operation<typeof WebhookSetInput, typeof WebhookSetOutput> {
    readonly key = "telegram.webhook.set"
    readonly version = 2
    readonly title = { vi: "Đăng ký webhook", en: "Register the webhook" }
    readonly input = WebhookSetInput
    readonly output = WebhookSetOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "telegram"
    readonly http = true
    readonly needs = ["botToken"] as const
    readonly refusals = [] as const

    run(input: z.infer<typeof WebhookSetInput>, reach: OperationReach): z.infer<typeof WebhookSetOutput> {
        const body = {
            url: input.url,
            allowed_updates: ["message", "callback_query"],
            secret_token: input.webhookSecret,
        }
        const answer = reach.http({ method: "POST", path: "/setWebhook", body })
        if (answer.status !== 200) return reach.byStatus()
        return { registered: true }
    }
}
