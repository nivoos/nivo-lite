import { z } from "zod"
import { TelegramAttachment } from "./attachment.ts"

// The rows a Telegram account keeps. A leaf: it imports no cell, so the provider and its triggers can both read it without a load cycle.

/** A kept message from a chat the bot is in (its words, or its caption when it carries a file, and the files it carries by reference): the update id (the key), the message, the chat and the sender. Ids are kept as text (they are 64-bit integers at Telegram). */
export const TelegramMessage = z.strictObject({
    updateId: z.string().regex(/^\d+$/u),
    messageId: z.string().regex(/^\d+$/u),
    chatId: z.string().regex(/^-?\d+$/u),
    chatType: z.enum(["private", "group", "supergroup", "channel"]),
    fromId: z.string().regex(/^\d+$/u),
    fromIsBot: z.boolean(),
    fromUsername: z.string().optional(),
    fromName: z.string(),
    text: z.string(),
    attachments: z.array(TelegramAttachment).optional(),
    sentAt: z.string(),
})

/**
 * A button pressed under a message the bot sent (an inline keyboard): the update id (the key), the press id to answer, the person who pressed, the chat and message the button was under and the data
 * the button carries (1-64 bytes, as the bot set it). The press has no date of its own: `sentAt` is the date of the message it was under.
 */
export const TelegramCallback = z.strictObject({
    updateId: z.string().regex(/^\d+$/u),
    callbackId: z.string().min(1),
    chatId: z.string().regex(/^-?\d+$/u),
    messageId: z.string().regex(/^\d+$/u),
    fromId: z.string().regex(/^\d+$/u),
    fromIsBot: z.boolean(),
    fromUsername: z.string().optional(),
    fromName: z.string(),
    data: z.string().min(1).max(64),
    sentAt: z.string(),
})
