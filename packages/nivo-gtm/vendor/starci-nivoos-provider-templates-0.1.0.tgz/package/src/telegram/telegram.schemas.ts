import { z } from "zod"
import { TelegramAttachment } from "./attachment.ts"

// The rows a Telegram account keeps. A leaf: it imports no cell, so the provider and its triggers can both read it without a load cycle.

/** A kept message from a chat the bot is in (its words, or its caption when it carries a file, and the files it carries by reference): the update id (the key), the message, the chat and the sender. Ids are kept as text (they are 64-bit integers at Telegram). */
export const TelegramMessage = z.strictObject({
    updateId: z.string().regex(/^\d+$/u),
    messageId: z.string().regex(/^\d+$/u),
    chatId: z.string().regex(/^-?\d+$/u),
    chatType: z.enum(["private", "group", "supergroup", "channel"]),
    fromId: z.string().regex(/^\d+$/u),
    fromIsBot: z.boolean(),
    fromUsername: z.string().optional(),
    fromName: z.string(),
    text: z.string(),
    /** The command the vendor marked in the message (a `bot_command` entity at the start, without the slash and the bot name; a command addressed to another bot, and `start` (a deep link, the way a customer arrives), are none). Absent: the message carries no command. */
    botCommand: z.string().regex(/^[A-Za-z0-9_]{1,32}$/u).optional(),
    attachments: z.array(TelegramAttachment).optional(),
    sentAt: z.string(),
})

/**
 * A button pressed under a message the bot sent (an inline keyboard): the update id (the key), the press id to answer, the person who pressed, the chat and message the button was under and the data
 * the button carries (1-64 bytes, as the bot set it). The press has no date of its own: `sentAt` is the date of the message it was under.
 */
export const TelegramCallback = z.strictObject({
    updateId: z.string().regex(/^\d+$/u),
    callbackId: z.string().min(1),
    chatId: z.string().regex(/^-?\d+$/u),
    messageId: z.string().regex(/^\d+$/u),
    fromId: z.string().regex(/^\d+$/u),
    fromIsBot: z.boolean(),
    fromUsername: z.string().optional(),
    fromName: z.string(),
    data: z.string().min(1).max(64),
    sentAt: z.string(),
})

const isRecord = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)

/**
 * The bot command of a message, read only from what the vendor marked (an entity of type `bot_command` that starts the text), never from the words: `/cmd` and `/cmd@<this bot>` give `cmd`; a command addressed to
 * another bot, a text with no such entity and `/start` (the deep link a customer arrives with) give `undefined`. A pure mapping.
 */
export const botCommandOf = (message: { readonly [member: string]: unknown }, botUsername: () => string): string | undefined => {
    const { text, entities } = message
    if (typeof text !== "string" || !Array.isArray(entities)) return undefined
    const marked = entities.find((entity: unknown) => isRecord(entity) && entity["type"] === "bot_command" && entity["offset"] === 0 && typeof entity["length"] === "number")
    if (!isRecord(marked) || typeof marked["length"] !== "number") return undefined
    const [name = "", addressed] = text.slice(1, marked["length"]).split("@")
    if (!text.startsWith("/") || !/^[A-Za-z0-9_]{1,32}$/u.test(name) || name.toLowerCase() === "start") return undefined
    if (addressed !== undefined && addressed.toLowerCase() !== botUsername().toLowerCase()) return undefined
    return name
}
