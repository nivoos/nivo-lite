import { z } from "zod"
import type { DataTypes, Delivery, ProofRequest, Provider, ProviderReach, ReceiveResult } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { attachmentsOfMessage } from "./attachment.ts"
import { TelegramMe } from "./me.cell.ts"
import { TelegramMessageReceived } from "./message-received.cell.ts"
import { TelegramCallback, TelegramMessage } from "./telegram.schemas.ts"
import { TelegramWebhookSet } from "./webhook-set.cell.ts"

export { TelegramCallback, TelegramMessage }

/** What an account of a Telegram bot connects with: the bot's public username, the token BotFather gave (secret) and the webhook secret token (secret, generated here). */
export const TelegramFields = z.strictObject({
    botUsername: z.string().min(1),
    botToken: z.string().min(1),
    webhookSecret: z.string().regex(/^[A-Za-z0-9_-]{1,256}$/u),
})

/** The one header Telegram proves a webhook delivery with (the `secret_token` given to setWebhook, sent as `X-Telegram-Bot-Api-Secret-Token`). */
export const TelegramProof = z.strictObject({ "x-telegram-bot-api-secret-token": z.string().optional() })

export const TelegramData = {
    "telegram.message": { value: TelegramMessage, keyMembers: ["updateId"], occurredAtMember: "sentAt" },
    "telegram.callback": { value: TelegramCallback, keyMembers: ["updateId"], occurredAtMember: "sentAt" },
} as const satisfies DataTypes

type Fields = z.infer<typeof TelegramFields>
type Proof = z.infer<typeof TelegramProof>

const isObject = (value: unknown): value is { readonly [member: string]: unknown } => typeof value === "object" && value !== null && !Array.isArray(value)
const whole = (value: unknown): string | null => (typeof value === "number" && Number.isSafeInteger(value) ? String(value) : null)

type CallbackResult = ReceiveResult<typeof TelegramData>

/** The row of a `callback_query` update: the press, who pressed, and the message the button was under. A press with no data or under a message the bot can no longer name is ignored. */
const callbackRowOf = (updateId: string, pressed: unknown): CallbackResult => {
    if (!isObject(pressed)) return { kind: "invalid", why: "callback_shape" }
    const { from, message, data } = pressed
    const callbackId = pressed["id"]
    if (typeof callbackId !== "string" || callbackId === "" || !isObject(from)) return { kind: "invalid", why: "callback_shape" }
    // the button spinner is ended at once by the door (the declared `immediate` operation, no text); the decision text goes later as an edit of the card
    const immediate = { callbackId }
    if (typeof data !== "string" || data === "" || !isObject(message)) return { kind: "ignored", why: "no_data_or_message", immediate }
    const messageId = whole(message["message_id"])
    const chat = message["chat"]
    const chatId = isObject(chat) ? whole(chat["id"]) : null
    const fromId = whole(from["id"])
    const isBot = from["is_bot"]
    const firstName = from["first_name"]
    if (messageId === null || chatId === null || fromId === null || typeof isBot !== "boolean" || typeof firstName !== "string") return { kind: "invalid", why: "callback_shape" }
    const date = message["date"]
    const username = from["username"]
    return {
        kind: "rows",
        immediate,
        rows: [
            {
                type: "telegram.callback",
                key: updateId,
                value: {
                    updateId,
                    callbackId,
                    chatId,
                    messageId,
                    fromId,
                    fromIsBot: isBot,
                    ...(typeof username === "string" ? { fromUsername: username } : {}),
                    fromName: firstName,
                    data,
                    sentAt: new Date((typeof date === "number" ? date : 0) * 1000).toISOString(),
                },
            },
        ],
    }
}

/**
 * `telegram`: a Telegram bot (Bot API). Calls go to https://api.telegram.org/bot<token>/<method> (the token is a path credential). Deliveries
 * are proved by the secret token in `X-Telegram-Bot-Api-Secret-Token`; the registration is the operation `telegram.webhook.set`. A `message`
 * update with a sender and a text is kept, and so is a `callback_query` (a button pressed under a message the bot sent) with its data (one row per `update_id`, so a re-delivery is one row);
 * every other update is ignored.
 */
export class TelegramProvider implements Provider<typeof TelegramFields, typeof TelegramProof, typeof TelegramData> {
    readonly key = "telegram"
    readonly version = 3
    readonly title = { vi: "Telegram", en: "Telegram" }
    readonly fields = TelegramFields
    readonly secrets = ["botToken", "webhookSecret"] as const
    readonly description = {
        vi: "Bot Telegram: nhận tin nhắn của khách qua webhook và gửi tin nhắn trả lời bằng Bot API.",
        en: "A Telegram bot: receives customers' messages by webhook and replies through the Bot API.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        botUsername: {
            label: { vi: "Tên bot", en: "Bot username" },
            help: { vi: "Tên người dùng của bot, chọn khi tạo bot với @BotFather.", en: "The bot's username, chosen when you create the bot with @BotFather." },
            placeholder: { vi: "ten_cua_bot", en: "my_shop_bot" },
            kind: "text",
            order: 1,
        },
        botToken: {
            label: { vi: "Mã bot (token)", en: "Bot token" },
            help: { vi: "@BotFather gửi mã này khi bạn gõ /newbot; dùng /token để lấy mã mới.", en: "@BotFather sends it when you send /newbot; /token issues a new one." },
            kind: "secret",
            order: 2,
        },
        webhookSecret: {
            label: { vi: "Mã bí mật webhook", en: "Webhook secret token" },
            help: {
                vi: "Telegram gửi mã này trong tiêu đề X-Telegram-Bot-Api-Secret-Token; bấm Tự sinh, NIVO tự đăng ký webhook.",
                en: "Telegram sends it in the X-Telegram-Bot-Api-Secret-Token header; generate it and NIVO registers the webhook.",
            },
            kind: "secret",
            order: 3,
            generate: { bytes: 32, encoding: "hex" },
        },
    } as const
    readonly identityField = "botUsername"
    readonly kind = "contact"
    readonly base = { fixed: "https://api.telegram.org" }
    readonly auth = { scheme: "path_token", secretField: "botToken", template: "/bot{secret}" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly connectTest = "telegram.me"
    readonly webhook = {
        proof: TelegramProof,
        ack: { status: 200, body: { ok: true } },
        refusedStatus: 401,
        registration: { kind: "operation", operation: "telegram.webhook.set" },
        // a pressed button shows a spinner until the bot answers: the door runs `telegram.callback.answer` (no text) right after the press commits, before the 200; the real work stays queued
        immediate: { operation: "telegram.callback.answer" },
    } as const
    /** Sources: https://core.telegram.org/bots/features (creating a bot with @BotFather, `/newbot`, `/token`), https://core.telegram.org/bots/api#setwebhook (webhook, secret token). */
    readonly setup = [
        setup.guide({
            key: "create-bot",
            title: { vi: "Tạo bot với @BotFather", en: "Create the bot with @BotFather" },
            body: {
                vi: "1. Mở Telegram và nhắn `/newbot` cho **@BotFather**.\n2. Đặt tên và tên người dùng cho bot (tên người dùng chọn lúc này là tên bot bạn sẽ nhập ở bước sau).\n3. @BotFather gửi lại **mã bot (token)**, giữ nó kín; mất mã thì gõ `/token`.\n\nGhi chú: trong nhóm, bot mặc định chỉ thấy lệnh và tin trả lời nó (chế độ riêng tư); tin nhắn riêng thì thấy hết.",
                en: "1. Open Telegram and send `/newbot` to **@BotFather**.\n2. Pick a name and a username for the bot (the username you choose here is the bot name you enter in the next step).\n3. @BotFather sends back the **bot token**; keep it private, and send `/token` if you lose it.\n\nNote: in groups a bot sees only commands and replies to it by default (privacy mode); in private chats it sees everything.",
            },
            link: { label: { vi: "Tài liệu Telegram về bot", en: "Telegram's bot documentation" }, url: "https://core.telegram.org/bots/features" },
        }),
        setup.fields({
            key: "token",
            title: { vi: "Nhập mã bot", en: "Enter the bot token" },
            body: {
                vi: "Dán tên người dùng và mã bot. Bấm **Tự sinh** ở mã bí mật webhook: Telegram sẽ gửi mã này kèm mỗi tin để NIVO biết tin thật.",
                en: "Paste the bot username and the token. Press **Generate** on the webhook secret: Telegram sends it with every update so NIVO knows it is genuine.",
            },
            fields: ["botUsername", "botToken", "webhookSecret"],
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra bot", en: "Check the bot" }, operation: TelegramMe, show: "username" }),
        setup.webhook({
            key: "webhook",
            title: { vi: "Đăng ký webhook", en: "Register the webhook" },
            body: { vi: "NIVO gọi `setWebhook` của Telegram với địa chỉ của tài khoản này và mã bí mật bạn vừa tạo.", en: "NIVO calls Telegram's `setWebhook` with this account's address and the secret you just made." },
            register: TelegramWebhookSet,
        }),
        setup.waitEvent({
            key: "first-message",
            title: { vi: "Nhắn thử cho bot", en: "Send the bot a message" },
            body: { vi: "Quét mã QR (hoặc mở liên kết) và gửi một tin nhắn cho bot. Trang tự cập nhật khi NIVO nhận được tin.", en: "Scan the QR code (or open the link) and send the bot a message. This page updates when NIVO receives it." },
            trigger: TelegramMessageReceived,
            timeout: "10m",
            qr: { url: "https://t.me/{username}" },
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = TelegramData

    /** A delivery is Telegram's for this account when it carries the account's secret token. */
    prove(request: ProofRequest<Proof>, reach: ProviderReach<Fields>): boolean {
        const presented = request.headers["x-telegram-bot-api-secret-token"]
        return typeof presented === "string" && reach.secretEquals("webhookSecret", presented)
    }

    receive(delivery: Delivery, _reach: ProviderReach<Fields>): ReceiveResult<typeof TelegramData> {
        const update = delivery.json
        if (!isObject(update)) return { kind: "invalid", why: "not_an_object" }
        const updateId = whole(update["update_id"])
        if (updateId === null) return { kind: "invalid", why: "no_update_id" }
        const pressed = update["callback_query"]
        if (pressed !== undefined) return callbackRowOf(updateId, pressed)
        const message = update["message"]
        if (message === undefined) return { kind: "ignored", why: "not_a_message_update" }
        if (!isObject(message)) return { kind: "invalid", why: "message_shape" }
        const { chat, from, date } = message
        const messageId = whole(message["message_id"])
        if (messageId === null || !isObject(chat) || typeof date !== "number") return { kind: "invalid", why: "message_shape" }
        const attachments = attachmentsOfMessage(message)
        const words = typeof message["text"] === "string" ? message["text"] : typeof message["caption"] === "string" ? message["caption"] : null
        if (!isObject(from) || (words === null && attachments.length === 0)) return { kind: "ignored", why: "no_sender_or_text" }
        const chatId = whole(chat["id"])
        const chatType = chat["type"]
        const fromId = whole(from["id"])
        const isBot = from["is_bot"]
        const firstName = from["first_name"]
        if (chatId === null || fromId === null || typeof isBot !== "boolean" || typeof firstName !== "string") return { kind: "invalid", why: "message_shape" }
        if (chatType !== "private" && chatType !== "group" && chatType !== "supergroup" && chatType !== "channel") return { kind: "invalid", why: "chat_type" }
        const username = from["username"]
        return {
            kind: "rows",
            rows: [
                {
                    type: "telegram.message",
                    key: updateId,
                    value: {
                        updateId,
                        messageId,
                        chatId,
                        chatType,
                        fromId,
                        fromIsBot: isBot,
                        ...(typeof username === "string" ? { fromUsername: username } : {}),
                        fromName: firstName,
                        text: words ?? "",
                        ...(attachments.length === 0 ? {} : { attachments }),
                        sentAt: new Date(date * 1000).toISOString(),
                    },
                },
            ],
        }
    }
}
