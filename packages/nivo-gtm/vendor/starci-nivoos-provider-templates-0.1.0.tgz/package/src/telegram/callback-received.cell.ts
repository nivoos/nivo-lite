import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { TelegramCallback } from "./telegram.schemas.ts"

type Row = z.infer<typeof TelegramCallback>

/**
 * `telegram.callback.received`: one pressed inline button is one event keyed by its update id. Its subject is the press itself, so a press never queues behind a run of the person; it is on by default.
 * The engine reads it to answer an approval card (the data of the button names the stop and the choice): `memberChannel` (a `press`) declares the Telegram provider a channel a member links on and names the event members that
 * hold who pressed, the button's data, the press id, and the chat and message the button was under. A workflow may take it too.
 *
 * Version 2: adds `memberChannel` (the engine no longer knows this trigger by its key).
 */
export class TelegramCallbackReceived implements Trigger<typeof TelegramCallback, typeof TelegramCallback> {
    readonly key = "telegram.callback.received"
    readonly version = 2
    readonly title = { vi: "Nhấn nút trong tin nhắn Telegram", en: "Telegram button pressed" }
    readonly row = TelegramCallback
    readonly event = TelegramCallback
    readonly provider = "telegram"
    readonly dataType = { providerVersion: 2, key: "telegram.callback" }
    readonly keyMember = "updateId"
    readonly subjectKind = "callback"
    readonly subjectMember = "callbackId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    readonly memberChannel = { kind: "press", pressedByMember: "fromId", dataMember: "data", pressIdMember: "callbackId", chatMember: "chatId", messageMember: "messageId" } as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Row> | null {
        return { id: row.updateId, data: row }
    }
}
