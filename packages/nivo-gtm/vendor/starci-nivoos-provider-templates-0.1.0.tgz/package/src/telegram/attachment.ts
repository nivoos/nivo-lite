import { z } from "zod"

/**
 * What Telegram said about one file of a message, as the event keeps it (the SDK's `ChannelAttachment`). The Bot API hands out a `file_id`, not an address (an address needs a `getFile` call and
 * carries the bot token), so the attachment is a reference: `ref` is the `file_id`, and there is no `url`.
 */
export const TelegramAttachment = z.strictObject({
    kind: z.enum(["image", "file", "audio", "video"]),
    ref: z.string().min(1).max(512),
    name: z.string().min(1).optional(),
    bytes: z.number().int().nonnegative().optional(),
})

type Attachment = z.infer<typeof TelegramAttachment>

const objectOf = (value: unknown): { readonly [member: string]: unknown } | null =>
    typeof value === "object" && value !== null && !Array.isArray(value) ? (value as { readonly [member: string]: unknown }) : null

const sizeOf = (value: unknown): number | undefined => (typeof value === "number" && Number.isSafeInteger(value) && value >= 0 ? value : undefined)

const one = (kind: Attachment["kind"], part: unknown, name?: unknown): Attachment | null => {
    const found = objectOf(part)
    const ref = found?.["file_id"]
    if (typeof ref !== "string" || ref === "") return null
    const bytes = sizeOf(found?.["file_size"])
    return { kind, ref, ...(typeof name === "string" && name !== "" ? { name } : {}), ...(bytes === undefined ? {} : { bytes }) }
}

/**
 * The files of a Telegram message: its `photo` (the sizes of one picture: the last, the largest, is kept), `document`, `voice`, `audio`, `video` and `video_note`. A message carries at most one of them;
 * the text of such a message is its `caption`.
 */
export const attachmentsOfMessage = (message: { readonly [member: string]: unknown }): Array<Attachment> => {
    const photos = message["photo"]
    const largest = Array.isArray(photos) ? photos[photos.length - 1] : undefined
    const document = objectOf(message["document"])
    const found = [
        one("image", largest),
        one("file", document, document?.["file_name"]),
        one("audio", message["voice"]),
        one("audio", message["audio"], objectOf(message["audio"])?.["file_name"]),
        one("video", message["video"], objectOf(message["video"])?.["file_name"]),
        one("video", message["video_note"]),
    ]
    return found.filter((attachment): attachment is Attachment => attachment !== null)
}
