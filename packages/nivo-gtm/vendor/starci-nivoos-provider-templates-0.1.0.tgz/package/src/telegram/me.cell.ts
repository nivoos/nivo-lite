import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const MeInput = z.strictObject({})
export const MeOutput = z.strictObject({ botId: z.string(), username: z.string() })

/** `telegram.me`: the connect test: getMe, the bot's own identity (one read; a bad token is the vendor's 401). */
export class TelegramMe implements Operation<typeof MeInput, typeof MeOutput> {
    readonly key = "telegram.me"
    readonly version = 1
    readonly title = { vi: "Thông tin bot", en: "Who is the bot" }
    readonly input = MeInput
    readonly output = MeOutput
    readonly semantics = { mutates: false }
    readonly provider = "telegram"
    readonly http = true
    readonly needs = ["botToken"] as const
    readonly refusals = [] as const

    run(_input: z.infer<typeof MeInput>, reach: OperationReach): z.infer<typeof MeOutput> {
        const answer = reach.http({ method: "GET", path: "/getMe" })
        if (answer.status !== 200 || typeof answer.json !== "object" || answer.json === null || Array.isArray(answer.json)) return reach.byStatus()
        const result = (answer.json as { readonly [member: string]: unknown })["result"]
        if (typeof result !== "object" || result === null || Array.isArray(result)) return reach.unknown("getMe_shape")
        const { id, username } = result as { readonly [member: string]: unknown }
        if (typeof id !== "number" || typeof username !== "string") return reach.unknown("getMe_shape")
        return { botId: String(id), username }
    }
}
