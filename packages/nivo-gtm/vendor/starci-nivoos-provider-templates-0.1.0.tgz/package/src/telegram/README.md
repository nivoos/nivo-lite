# telegram (Telegram Bot API)

Provider key `telegram`. Auth: the account's bot token goes in the request path (`path_token`, template `/bot{secret}`) on base `https://api.telegram.org`. Webhook: proved by the secret token header; registered by the operation `telegram.webhook.set`. Logo: neutral monogram (Telegram's brand terms were not fetched, so no official mark is shipped).

| Cell | What it does |
| --- | --- |
| `telegram.provider.cell.ts` | fields `botUsername` (public, identity), `botToken` (secret), `webhookSecret` (secret, generated 32 bytes hex); `prove` compares `X-Telegram-Bot-Api-Secret-Token`; `receive` keeps one `telegram.message` row per `update_id`, and one `telegram.callback` row per pressed inline button (provider version 2) |
| `me.cell.ts` | `telegram.me` = `getMe`, the connect test (read) |
| `webhook-set.cell.ts` | `telegram.webhook.set` = `setWebhook` with `url`, `secret_token`, `allowed_updates: ["message", "callback_query"]` |
| `send-message.cell.ts` | `telegram.messages.send` = `sendMessage`, optional `buttons` (rows of inline buttons `{ text, data }`); refusal `chat_forbidden` on HTTP 403; 429 transient |
| `edit-message.cell.ts` | `telegram.messages.edit` = `editMessageText` (no keyboard, so the buttons go away); a 400 (same text) answers `edited` |
| `callback-answer.cell.ts` | `telegram.callback.answer` = `answerCallbackQuery` (ends the spinner, shows a short notice); a 400 (late or second answer) answers `answered` |
| `callback-received.cell.ts` | trigger `telegram.callback.received`: one pressed inline button per update id, subject = the press; the engine reads it to answer an approval card |
| `message-received.cell.ts` | trigger `telegram.message.received`: event key `updateId`, subject `contact:<fromId>`, data carries `chatType` and `fromIsBot` for the workflow to branch on |

## Vendor facts and where they come from (fetched 2026-11-16)

- Method URL `https://api.telegram.org/bot<token>/METHOD_NAME`, HTTPS, GET or POST, JSON body allowed: https://core.telegram.org/bots/api (Making requests).
- `setWebhook`: `url`, `max_connections` 1-100, `allowed_updates`, `drop_pending_updates`, `secret_token` (1-256 characters, only `A-Z a-z 0-9 _ -`), sent in the header `X-Telegram-Bot-Api-Secret-Token` on every webhook request; while a webhook is set `getUpdates` does not work: https://core.telegram.org/bots/api#setwebhook.
- Webhook needs TLS (TLS 1.2+), ports 443, 80, 88, 8443; Telegram connects from 149.154.160.0/20 and 91.108.4.0/22: https://core.telegram.org/bots/webhooks.
- Response envelope: `ok`, on success `result`, on failure `description` and `error_code`, optional `parameters` (ResponseParameters): https://core.telegram.org/bots/api (Making requests).
- `sendMessage`: `text` 1-4096 characters after entities parsing, `chat_id` Integer or String (`@username` of a channel), optional `reply_parameters`, `parse_mode`; returns the sent `Message`: https://core.telegram.org/bots/api#sendmessage. `getMe` takes no parameters and returns a `User`: https://core.telegram.org/bots/api#getme.
- `Update.update_id` Integer; `Update.message` optional (at most one optional update field is set); `Message`: `message_id`, `date` (Unix time), `chat`, `from` (optional), `text` (optional); `Chat.type` is `private`, `group`, `supergroup` or `channel`; `User`: `id`, `is_bot`, `first_name`, `username` optional: https://core.telegram.org/bots/api (Available types).
- Bot creation: send `/newbot` to @BotFather; token looks like `110201543:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw`; `/token` replaces a lost token: https://core.telegram.org/bots/features. Privacy mode is on by default in groups (a bot sees commands, replies to it and all private-chat messages): same page.
- Limits: about 1 message per second in one chat, 20 per minute in a group, about 30 per second when broadcasting; beyond them 429: https://core.telegram.org/bots/faq.

## Not confirmed (said, not guessed)

- `ResponseParameters.retry_after` (used for the 429 wait) and the 403 meaning "the bot may not write to that chat (blocked or removed)": the pages fetched did not show the ResponseParameters table or the error-code text. The code reads `parameters.retry_after` only when it is a number, else the engine's own 429 table decides; HTTP 403 is mapped to `chat_forbidden` by status, not by the description text.
- Whether Telegram retries a delivery answered non-2xx, and for how long, and `update_id` ordering guarantees: not on the pages fetched. Deduplication is by `update_id` (the data type key), which is safe either way.
- Whether a bot may message a user who never started it: not stated on the pages fetched; such a send would come back as the vendor's refusal.
- Official logo redistribution terms: not fetched; monogram used.

## Webhook registration

The registration operation takes `{ url, webhookSecret }` and sends the secret as `secret_token`. The connect door attaches the account's generated `webhookSecret` to the input by name (it is a generated secret field the operation's input declares), so Telegram sends the secret in `X-Telegram-Bot-Api-Secret-Token` and `prove` compares it in constant time.

## Attachments

A message with a `photo` (the largest size is kept), `document`, `voice`, `audio`, `video` or `video_note` is kept, with its `caption` as its words. The event's `attachments` carry `{ kind, ref, name?, bytes? }` where `ref` is the `file_id`: the Bot API gives an address only through `getFile`, whose download address carries the bot token, so no address is kept and none is handed to a cell. Fetching the bytes by `file_id` is a later operation. A sticker or any other message with neither words nor a file is still ignored.

## Start payload

A person who opens `https://t.me/<bot>?start=<payload>` and presses Start sends the text `/start <payload>`. When the text is exactly that, with a payload of 1-64 characters from `A-Z a-z 0-9 _ -` (Telegram's own alphabet for the parameter), the event of `telegram.message.received` (version 4) gains `startParam: string`. The text is kept as it is and the stored `telegram.message` row does not change, so the old event shape is a subset of the new one. `/start` with no payload, a payload over 64 characters or outside the alphabet, and ordinary text give no `startParam`. The parse is `translate`'s pure mapping (no branch on words). Recorded deliveries: `be/src/tests/fixtures/e2e/providers/telegram/start-param.exchanges.ts`. Part 2 (a `refMember` on the trigger so the engine records a touch at intake) waits for gm-sdk and gm-families.
