import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

/** One button of an inline keyboard: its words and the data it hands back when pressed (1-64 bytes). */
export const InlineButton = z.strictObject({ text: z.string().min(1).max(64), data: z.string().min(1).max(64) })

export const SendMessageInput = z.strictObject({
    chatId: z.string().min(1),
    text: z.string().min(1).max(4096),
    replyToMessageId: z.number().int().positive().optional(),
    /** Rows of buttons under the message (at most 8 rows of 8). */
    buttons: z.array(z.array(InlineButton).min(1).max(8)).min(1).max(8).optional(),
})
export const SendMessageOutput = z.strictObject({ messageId: z.string(), chatId: z.string(), sentAt: z.string() })

type Refusal = "chat_forbidden"

const member = (value: unknown, name: string): unknown => (typeof value === "object" && value !== null && !Array.isArray(value) ? (value as { readonly [key: string]: unknown })[name] : undefined)

/**
 * `telegram.messages.send`: sendMessage (text 1-4096 characters, optional rows of inline buttons). A 403 is the vendor saying the bot may not write to that chat (the person
 * blocked it, or it was removed): the declared refusal `chat_forbidden`. A 429 is transient (waiting the vendor's `retry_after` when it gives one).
 */
export class TelegramSendMessage implements Operation<typeof SendMessageInput, typeof SendMessageOutput, never, Refusal> {
    readonly key = "telegram.messages.send"
    readonly version = 3
    readonly title = { vi: "Gửi tin nhắn Telegram", en: "Send a Telegram message" }
    readonly input = SendMessageInput
    readonly output = SendMessageOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "telegram"
    readonly http = true
    readonly needs = ["botToken"] as const
    readonly refusals = ["chat_forbidden"] as const
    // the line sender of this channel: the person's id on the account is the chat id of a private chat
    readonly sendsLine = { identity: "channel", input: { chatId: "{to}", text: "{text}" } } as const

    run(input: z.infer<typeof SendMessageInput>, reach: OperationReach<never, Refusal>): z.infer<typeof SendMessageOutput> {
        // a numeric chat id goes as an integer; an @channelusername goes as text
        const chat = /^-?\d+$/u.test(input.chatId) ? Number(input.chatId) : input.chatId
        const answer = reach.http({
            method: "POST",
            path: "/sendMessage",
            body: {
                chat_id: chat,
                text: input.text,
                ...(input.replyToMessageId === undefined ? {} : { reply_parameters: { message_id: input.replyToMessageId } }),
                ...(input.buttons === undefined ? {} : { reply_markup: { inline_keyboard: input.buttons.map((row) => row.map((button) => ({ text: button.text, callback_data: button.data }))) } }),
            },
        })
        if (answer.status === 403) return reach.refuse("chat_forbidden")
        if (answer.status === 429) {
            const retryAfter = member(member(answer.json, "parameters"), "retry_after")
            return typeof retryAfter === "number" ? reach.transient("rate_limited", retryAfter) : reach.byStatus()
        }
        if (answer.status !== 200) return reach.byStatus()
        const result = member(answer.json, "result")
        const messageId = member(result, "message_id")
        const date = member(result, "date")
        const chatId = member(member(result, "chat"), "id")
        if (typeof messageId !== "number" || typeof date !== "number" || typeof chatId !== "number") return reach.unknown("sendMessage_shape")
        return { messageId: String(messageId), chatId: String(chatId), sentAt: new Date(date * 1000).toISOString() }
    }
}
