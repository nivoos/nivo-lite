import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { TelegramMessage } from "./telegram.schemas.ts"

/** The payload of a deep link (`https://t.me/<bot>?start=<payload>`): 1-64 characters of Telegram's own alphabet. */
const START_PAYLOAD = /^[A-Za-z0-9_-]{1,64}$/u
const START_TEXT = /^\/start ([A-Za-z0-9_-]{1,64})$/u

/**
 * The event of a kept message: the chat type and `fromIsBot` are data a workflow branches on (a group chat or a bot is not a customer in a private chat).
 * `startParam` is present only when the text is `/start <payload>` with a valid payload; the text itself is kept as it is. The rest is the stored row, so the old shape is a subset.
 */
export const MessageEvent = TelegramMessage.extend({ startParam: z.string().regex(START_PAYLOAD).optional() })

/** The deep-link payload of a `/start <payload>` text, or `undefined` (no payload, a payload over 64 characters or outside the alphabet, or ordinary text). A pure mapping. */
export const startParamOf = (text: string): string | undefined => START_TEXT.exec(text)?.[1]

type Row = z.infer<typeof TelegramMessage>

/** `telegram.message.received`: one kept message (text, or a caption and the files it carries by reference) is one event keyed by its update id (with `startParam` when the text is `/start <payload>`), on the subject `contact:<fromId>`, on by default. A message of a person in a private chat is also a customer line (`line`), and one the vendor marked as a bot command is also a command of the member who sent it (`memberChannel`, kind `command`, on `botCommand`). Version 5 adds `botCommand` and `memberChannel`. */
export class TelegramMessageReceived implements Trigger<typeof TelegramMessage, typeof MessageEvent> {
    readonly key = "telegram.message.received"
    readonly version = 5
    readonly title = { vi: "Nhận tin nhắn Telegram", en: "Telegram message received" }
    readonly row = TelegramMessage
    readonly event = MessageEvent
    readonly provider = "telegram"
    readonly dataType = { providerVersion: 2, key: "telegram.message" }
    readonly keyMember = "updateId"
    readonly subjectKind = "contact"
    readonly subjectMember = "fromId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    // a private chat with a person is a customer line; a bot's message or a group is not
    readonly line = {
        identity: "channel",
        contactMember: "fromId",
        textMember: "text",
        nameMember: "fromName",
        filesMember: "attachments",
        only: [
            { member: "chatType", equals: "private" },
            { member: "fromIsBot", equals: false },
        ],
    } as const

    // a message the vendor marked as a bot command, from a person on their own channel, is a command of that member (`botCommand`; `/start` is no command: it is how a customer arrives)
    readonly memberChannel = { kind: "command", commandMember: "botCommand", senderMember: "fromId", chatMember: "chatId", directWhen: { member: "chatType", equals: "private" } } as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<z.infer<typeof MessageEvent>> | null {
        const startParam = startParamOf(row.text)
        return { id: row.updateId, data: startParam === undefined ? row : { ...row, startParam } }
    }
}
