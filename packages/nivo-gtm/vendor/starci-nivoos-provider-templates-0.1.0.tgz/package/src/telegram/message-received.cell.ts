import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { TelegramMessage } from "./telegram.provider.cell.ts"

/** The event of a kept message: the chat type and `fromIsBot` are data a workflow branches on (a group chat or a bot is not a customer in a private chat). */
export const MessageEvent = TelegramMessage

type Row = z.infer<typeof TelegramMessage>

/** `telegram.message.received`: one kept message (text, or a caption and the files it carries by reference) is one event keyed by its update id, on the subject `contact:<fromId>`, on by default. A message of a person in a private chat is also a customer line (`line`). */
export class TelegramMessageReceived implements Trigger<typeof TelegramMessage, typeof MessageEvent> {
    readonly key = "telegram.message.received"
    readonly version = 3
    readonly title = { vi: "Nhận tin nhắn Telegram", en: "Telegram message received" }
    readonly row = TelegramMessage
    readonly event = MessageEvent
    readonly provider = "telegram"
    readonly dataType = { providerVersion: 2, key: "telegram.message" }
    readonly keyMember = "updateId"
    readonly subjectKind = "contact"
    readonly subjectMember = "fromId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    // a private chat with a person is a customer line; a bot's message or a group is not
    readonly line = {
        identity: "channel",
        contactMember: "fromId",
        textMember: "text",
        nameMember: "fromName",
        filesMember: "attachments",
        only: [
            { member: "chatType", equals: "private" },
            { member: "fromIsBot", equals: false },
        ],
    } as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Row> | null {
        return { id: row.updateId, data: row }
    }
}
