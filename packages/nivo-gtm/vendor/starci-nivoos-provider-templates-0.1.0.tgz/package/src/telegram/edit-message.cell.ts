import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const EditMessageInput = z.strictObject({ chatId: z.string().min(1), messageId: z.string().regex(/^\d+$/u), text: z.string().min(1).max(4096) })
export const EditMessageOutput = z.strictObject({ edited: z.literal(true) })

/**
 * `telegram.messages.edit`: editMessageText. It rewrites a message the bot sent and, because the call carries no keyboard, takes its inline buttons away: the way a decided approval card stops being
 * pressable. Telegram answers 400 when the text is the same as it was; that is a rewrite already done, so it answers `edited`.
 */
export class TelegramEditMessage implements Operation<typeof EditMessageInput, typeof EditMessageOutput> {
    readonly key = "telegram.messages.edit"
    readonly version = 1
    readonly title = { vi: "Sửa tin nhắn Telegram", en: "Edit a Telegram message" }
    readonly input = EditMessageInput
    readonly output = EditMessageOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "telegram"
    readonly http = true
    readonly needs = ["botToken"] as const
    readonly refusals = [] as const

    run(input: z.infer<typeof EditMessageInput>, reach: OperationReach): z.infer<typeof EditMessageOutput> {
        const chat = /^-?\d+$/u.test(input.chatId) ? Number(input.chatId) : input.chatId
        const answer = reach.http({ method: "POST", path: "/editMessageText", body: { chat_id: chat, message_id: Number(input.messageId), text: input.text } })
        if (answer.status === 200 || answer.status === 400) return { edited: true }
        return reach.byStatus()
    }
}
