import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"

export const CallbackAnswerInput = z.strictObject({ callbackId: z.string().min(1), text: z.string().max(200).optional() })
export const CallbackAnswerOutput = z.strictObject({ answered: z.literal(true) })

/**
 * `telegram.callback.answer`: answerCallbackQuery. It ends the spinner on the button the person pressed and shows them a short notice (up to 200 characters) as a toast. A press answered late or twice
 * is the vendor's 400, which is not an error of ours: the operation answers `answered` for it (the button was settled either way).
 */
export class TelegramCallbackAnswer implements Operation<typeof CallbackAnswerInput, typeof CallbackAnswerOutput> {
    readonly key = "telegram.callback.answer"
    readonly version = 1
    readonly title = { vi: "Trả lời nút bấm", en: "Answer a button press" }
    readonly input = CallbackAnswerInput
    readonly output = CallbackAnswerOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "telegram"
    readonly http = true
    readonly needs = ["botToken"] as const
    readonly refusals = [] as const

    run(input: z.infer<typeof CallbackAnswerInput>, reach: OperationReach): z.infer<typeof CallbackAnswerOutput> {
        const answer = reach.http({
            method: "POST",
            path: "/answerCallbackQuery",
            body: { callback_query_id: input.callbackId, ...(input.text === undefined ? {} : { text: input.text }) },
        })
        if (answer.status === 200 || answer.status === 400) return { answered: true }
        return reach.byStatus()
    }
}
