import { z } from "zod"
import type { JsonValue, Operation, OperationReach } from "@starci/nivoos-sdk"

export const OaProfileInput = z.strictObject({})
export const OaProfileOutput = z.strictObject({ oaId: z.string().min(1), name: z.string() })

type Out = z.infer<typeof OaProfileOutput>

const membersOf = (value: JsonValue | undefined): { readonly [member: string]: JsonValue } | null =>
    value === undefined || value === null || typeof value !== "object" || Array.isArray(value) ? null : (value as { readonly [member: string]: JsonValue })

/**
 * `zalo.oa.profile`: the connect test: reads the id and name of the OA the token belongs to (Open API v2.0 `getoa`). A rejected token
 * (`error` -216 or -124 in a 200 answer) is the declared refusal `auth_failed`, which marks the account `needs_reauth`.
 */
export class OaProfile implements Operation<typeof OaProfileInput, typeof OaProfileOutput, never, "auth_failed"> {
    readonly key = "zalo.oa.profile"
    readonly version = 1
    readonly title = { vi: "Thông tin Official Account", en: "Official Account profile" }
    readonly input = OaProfileInput
    readonly output = OaProfileOutput
    readonly semantics = { mutates: false }
    readonly provider = "zalo"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = ["auth_failed"] as const

    run(_input: z.infer<typeof OaProfileInput>, reach: OperationReach<never, "auth_failed">): Out {
        const response = reach.http({ method: "GET", path: "/v2.0/oa/getoa" })
        if (response.status !== 200) return reach.byStatus()
        const body = membersOf(response.json)
        const error = body?.["error"]
        if (error === -216 || error === -124) return reach.refuse("auth_failed")
        const data = membersOf(body?.["data"])
        const oaId = data?.["oa_id"]
        const name = data?.["name"]
        const id = typeof oaId === "string" || typeof oaId === "number" ? String(oaId) : ""
        return error === 0 && id !== "" ? { oaId: id, name: typeof name === "string" ? name : "" } : reach.byStatus()
    }
}
