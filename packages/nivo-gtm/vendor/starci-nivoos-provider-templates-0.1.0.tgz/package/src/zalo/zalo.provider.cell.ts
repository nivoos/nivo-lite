import { z } from "zod"
import type { DataTypes, Delivery, ProofRequest, Provider, ProviderReach, ReceiveResult } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { attachmentsOfMessage } from "./attachment.ts"
import { ZaloMessageReceived } from "./message-received.cell.ts"
import { OaProfile } from "./oa-profile.cell.ts"
import { ZaloMessage } from "./zalo.schemas.ts"

export { ZaloMessage }

/**
 * What an account of Zalo Official Account connects with: the app id (public), the OA secret key the webhook is signed with, the OA access token
 * and, optionally, the refresh token the person keeps for the day the access token ends.
 */
export const ZaloFields = z.strictObject({
    appId: z.string().min(1),
    oaSecretKey: z.string().min(1),
    accessToken: z.string().min(1),
    refreshToken: z.string().min(1).optional(),
})

/** The one header a Zalo delivery is proved by. */
export const ZaloProof = z.strictObject({ "x-zevent-signature": z.string().optional() })

/** The raw rows a Zalo account keeps, by data type. */
export const ZaloData = {
    "zalo.message": { value: ZaloMessage, keyMembers: ["msgId"], occurredAtMember: "at" },
} as const satisfies DataTypes

type Fields = z.infer<typeof ZaloFields>
type Proof = z.infer<typeof ZaloProof>

const EVENT_KINDS: { readonly [event: string]: "text" | "image" | "file" } = { user_send_text: "text", user_send_image: "image", user_send_file: "file" }

/** The `timestamp` member of the body, read from the raw text (a `try` is refused in a cell, so the body is not parsed here). */
const TIMESTAMP = /"timestamp"\s*:\s*"?(\d+)"?/u

const scalarOf = (source: unknown, member: string): string => {
    if (source === null || typeof source !== "object" || Array.isArray(source)) return ""
    const value = (source as { readonly [member: string]: unknown })[member]
    return typeof value === "string" || typeof value === "number" ? String(value) : ""
}

/**
 * `zalo`: a Zalo Official Account. A delivery to the generic webhook door is proved by the signature header `x-zevent-signature` (see README: the formula is V1's, not yet
 * confirmed against the current vendor page); a customer's text, picture or file
 * event is kept as one `zalo.message` row; every other event is ignored.
 */
export class ZaloProvider implements Provider<typeof ZaloFields, typeof ZaloProof, typeof ZaloData> {
    readonly key = "zalo"
    readonly version = 2
    readonly title = { vi: "Zalo Official Account", en: "Zalo Official Account" }
    readonly fields = ZaloFields
    readonly secrets = ["oaSecretKey", "accessToken", "refreshToken"] as const
    readonly description = {
        vi: "Nhận tin nhắn khách gửi tới Official Account qua webhook và gửi tin tư vấn trả lời.",
        en: "Receives the messages customers send to your Official Account by webhook and sends customer-service replies.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        appId: { label: { vi: "App ID", en: "App ID" }, help: { vi: "Mã ứng dụng Zalo trên developers.zalo.me.", en: "The id of your app on developers.zalo.me." }, kind: "text", order: 1 },
        oaSecretKey: {
            label: { vi: "Khoá bí mật OA", en: "OA secret key" },
            help: { vi: "Khoá bí mật của Official Account trong cấu hình webhook của ứng dụng; dùng để kiểm tra chữ ký.", en: "The OA secret key in the app's webhook settings; used to check the signature." },
            kind: "secret",
            order: 2,
        },
        accessToken: {
            label: { vi: "Access token của OA", en: "OA access token" },
            help: { vi: "Access token của Official Account (hết hạn sau khoảng một giờ).", en: "The Official Account's access token (it ends after about an hour)." },
            kind: "secret",
            order: 3,
        },
        refreshToken: {
            label: { vi: "Refresh token", en: "Refresh token" },
            help: { vi: "Tuỳ chọn: refresh token để bạn tự làm mới access token.", en: "Optional: the refresh token you keep to renew the access token yourself." },
            kind: "secret",
            order: 4,
        },
    } as const
    readonly identityField = "appId"
    readonly kind = "contact"
    readonly base = { fixed: "https://openapi.zalo.me" }
    readonly auth = { scheme: "header", secretField: "accessToken", name: "access_token" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly connectTest = "zalo.oa.profile"
    readonly webhook = { proof: ZaloProof, ack: { status: 200 }, refusedStatus: 401, registration: { kind: "copy" } } as const
    /** Zalo's own docs (developers.zalo.me) are rendered by script and could not be read (see the README): the vendor screens below are said to be unknown, not guessed. */
    readonly setup = [
        setup.guide({
            key: "app",
            title: { vi: "Chuẩn bị ứng dụng Zalo OA", en: "Prepare the Zalo OA app" },
            body: {
                vi: "Bạn cần **App ID**, **Secret key của OA** và **access token** của Official Account. Cách tạo ứng dụng và lấy token trên developers.zalo.me chưa được ghi lại ở đây (trang tài liệu của Zalo không đọc được); xem tài liệu Zalo.",
                en: "You need the **App ID**, the OA's **secret key** and an **access token** of the Official Account. How to create the app and get the token at developers.zalo.me is not recorded here (Zalo's doc pages could not be read); see the Zalo docs.",
            },
            link: { label: { vi: "Zalo for Developers", en: "Zalo for Developers" }, url: "https://developers.zalo.me/" },
        }),
        setup.fields({ key: "credentials", title: { vi: "Nhập thông tin", en: "Enter the details" }, fields: ["appId", "oaSecretKey", "accessToken", "refreshToken"] }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra OA", en: "Check the OA" }, operation: OaProfile, show: "name" }),
        setup.guide({
            key: "dashboard",
            title: { vi: "Khai báo webhook ở Zalo", en: "Declare the webhook at Zalo" },
            body: {
                vi: "Dán **địa chỉ webhook ở bước tiếp theo** vào cấu hình webhook của ứng dụng trên developers.zalo.me. Vị trí các nút cụ thể chưa được ghi lại ở đây.",
                en: "Paste the **webhook address of the next step** into the app's webhook setting at developers.zalo.me. The exact place of the buttons is not recorded here.",
            },
        }),
        setup.webhook({ key: "webhook", title: { vi: "Địa chỉ webhook", en: "Webhook address" } }),
        setup.waitEvent({
            key: "first-message",
            title: { vi: "Nhắn thử cho OA", en: "Message the OA" },
            body: { vi: "Từ một tài khoản Zalo đã quan tâm OA, nhắn một tin cho OA; trang cập nhật khi NIVO nhận được.", en: "From a Zalo account that follows the OA, send the OA a message; this page updates when NIVO receives it." },
            trigger: ZaloMessageReceived,
            timeout: "10m",
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = ZaloData

    /**
     * The V1 rule: `sha256(appId + body + timestamp + oaSecretKey)`, a plain digest keyed by appending the OA secret key (not an HMAC), compared in
     * constant time by the engine (`digestEquals`; the secret never enters this code). It fails closed: a wrong or absent signature, a body
     * without a `timestamp`, or a missing app id proves nothing.
     */
    prove(request: ProofRequest<Proof>, reach: ProviderReach<Fields>): boolean {
        const header = request.headers["x-zevent-signature"]
        if (typeof header !== "string" || header.trim() === "") return false
        // the event time as Zalo wrote it in the body (a number or a text); the signature binds the whole body, so a misread time only fails the proof
        const timestamp = TIMESTAMP.exec(request.body)?.[1] ?? ""
        const appId = reach.account().appId
        if (timestamp === "" || typeof appId !== "string" || appId === "") return false
        return reach.digestEquals("sha256", [appId, request.body, timestamp, { secret: "oaSecretKey" }], header.trim().replace(/^mac=/iu, "").toLowerCase())
    }

    /** One customer message per delivery; follow, unfollow, seen and every other event are ignored. */
    receive(delivery: Delivery, _reach: ProviderReach<Fields>): ReceiveResult<typeof ZaloData> {
        const body = delivery.json
        if (body === null || body === undefined || typeof body !== "object" || Array.isArray(body)) return { kind: "invalid", why: "not_an_object" }
        const kind = EVENT_KINDS[scalarOf(body, "event_name")]
        if (kind === undefined) return { kind: "ignored", why: "not_a_customer_message" }
        const message = (body as { readonly [member: string]: unknown })["message"]
        const msgId = scalarOf(message, "msg_id")
        const userId = scalarOf((body as { readonly [member: string]: unknown })["sender"], "id")
        const millis = Number(scalarOf(body, "timestamp"))
        if (msgId === "" || userId === "" || !Number.isFinite(millis) || millis <= 0) return { kind: "invalid", why: "message_shape" }
        const attachments = attachmentsOfMessage(message)
        return { kind: "rows", rows: [{ type: "zalo.message", key: msgId, value: { msgId, userId, kind, text: scalarOf(message, "text"), ...(attachments.length === 0 ? {} : { attachments }), at: new Date(millis).toISOString() } }] }
    }
}
