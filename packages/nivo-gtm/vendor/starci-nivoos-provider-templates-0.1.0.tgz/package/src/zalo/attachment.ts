import { z } from "zod"

/** What Zalo said about one file of a message, as the event keeps it (the SDK's `ChannelAttachment`): an https address, a kind, and a name and size when Zalo gave them. */
export const ZaloAttachment = z.strictObject({
    kind: z.enum(["image", "file", "audio", "video"]),
    url: z.string().min(1),
    name: z.string().min(1).optional(),
    bytes: z.number().int().nonnegative().optional(),
})

const KINDS: { readonly [type: string]: "image" | "file" | "audio" | "video" } = { image: "image", file: "file", audio: "audio", video: "video" }

const objectOf = (value: unknown): { readonly [member: string]: unknown } | null =>
    typeof value === "object" && value !== null && !Array.isArray(value) ? (value as { readonly [member: string]: unknown }) : null

/** A size Zalo wrote as a number or as digits in a text, else undefined. */
const sizeOf = (value: unknown): number | undefined => {
    const bytes = typeof value === "number" ? value : typeof value === "string" && /^\d{1,15}$/u.test(value) ? Number(value) : Number.NaN
    return Number.isSafeInteger(bytes) && bytes >= 0 ? bytes : undefined
}

/**
 * The attachments of a Zalo message: `message.attachments` is a list of `{ type, payload: { url, size?, name? } }`. An entry with no address, or of a type this provider does not carry,
 * is left out (the message is still kept, with its words). The shape comes from V1's traffic and is not re-read on the vendor page (README).
 */
export const attachmentsOfMessage = (message: unknown): Array<z.infer<typeof ZaloAttachment>> => {
    const listed = objectOf(message)?.["attachments"]
    if (!Array.isArray(listed)) return []
    const out: Array<z.infer<typeof ZaloAttachment>> = []
    for (const entry of listed) {
        const one = objectOf(entry)
        const payload = objectOf(one?.["payload"])
        const type = one?.["type"]
        const kind = typeof type === "string" ? KINDS[type] : undefined
        const url = payload?.["url"]
        if (kind === undefined || typeof url !== "string" || url === "") continue
        const name = payload?.["name"]
        const bytes = sizeOf(payload?.["size"])
        out.push({ kind, url, ...(typeof name === "string" && name !== "" ? { name } : {}), ...(bytes === undefined ? {} : { bytes }) })
    }
    return out
}
