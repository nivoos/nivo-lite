// The zalo provider alone: the entry the integration spec builds (`loadProject`) so a case deploys exactly this folder. The shipped package lists these cells in provider-templates.package.ts.
import type { Package } from "@starci/nivoos-sdk"
import { ZaloMessageReceived } from "./message-received.cell.ts"
import { OaProfile } from "./oa-profile.cell.ts"
import { ZaloSendMessage } from "./send-message.cell.ts"
import { ZaloProvider } from "./zalo.provider.cell.ts"

export default {
    package: { key: "e2e-zalo", version: "1.0.0", author: "e2e" },
    cells: [ZaloProvider, OaProfile, ZaloSendMessage, ZaloMessageReceived],
    agents: [],
} satisfies Package
