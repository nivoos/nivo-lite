import { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { ZaloAttachment } from "./attachment.ts"
import { ZaloMessage } from "./zalo.provider.cell.ts"

/** The event of a customer message: the message itself. */
export const MessageEvent = z.strictObject({
    msgId: z.string().min(1),
    userId: z.string().min(1),
    kind: z.enum(["text", "image", "file"]),
    text: z.string(),
    attachments: z.array(ZaloAttachment).optional(),
    at: z.string(),
})

type Row = z.infer<typeof ZaloMessage>
type Event = z.infer<typeof MessageEvent>

/** `zalo.message.received`: one kept customer message is one event, on the subject `person:<userId>`, on by default. */
export class ZaloMessageReceived implements Trigger<typeof ZaloMessage, typeof MessageEvent> {
    readonly key = "zalo.message.received"
    readonly version = 3
    readonly title = { vi: "Khách nhắn tin Zalo", en: "Zalo message received" }
    readonly row = ZaloMessage
    readonly event = MessageEvent
    readonly provider = "zalo"
    readonly dataType = { providerVersion: 2, key: "zalo.message" }
    readonly keyMember = "msgId"
    readonly subjectKind = "person"
    readonly subjectMember = "userId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    // every customer message (a picture or a file has no words) is a customer line
    readonly line = { identity: "channel", contactMember: "userId", textMember: "text", filesMember: "attachments" } as const

    translate(row: Row, _reach: TriggerReach): TriggerEvent<Event> | null {
        return { id: row.msgId, data: { msgId: row.msgId, userId: row.userId, kind: row.kind, text: row.text, ...(row.attachments === undefined ? {} : { attachments: row.attachments }), at: row.at } }
    }
}
