# zalo (Zalo Official Account)

Receives the messages customers send to an OA by webhook and sends customer-service (CS) text replies.

## Source of every fact

The vendor's docs (developers.zalo.me) are rendered by script: a fetch on 2026-11-16 returned only page titles, and a web search found no
page that states the signature formula. So NO fact below is confirmed against the vendor's current page. Each comes from V1 code that ran against
real Zalo traffic (the Zalo integration of the nivo-auth-ux app and its zalo-inbox module); re-check them on developers.zalo.me before going live.

| Fact | Value | V1 source |
| --- | --- | --- |
| API origin | `https://openapi.zalo.me` | zalo.config.ts |
| Credential | header `access_token: <OA access token>` | zalo.client.ts |
| Send CS text | `POST /v3.0/oa/message/cs`, body `{ recipient: { user_id }, message: { text } }`; answer `{ error, message, data: { message_id } }` with `error: 0` on success; a failure is `error != 0` in a 200 answer | zalo.client.ts |
| OA profile (connect test) | `GET /v2.0/oa/getoa` -> `data.oa_id`, `data.name` | zalo.client.ts |
| Inbound event | `event_name` `user_send_text` / `user_send_image` / `user_send_file`, `sender.id`, `message.msg_id`, `message.text`, `timestamp` (epoch ms) | zalo.normalise.policy.ts |
| Inbound attachments | `message.attachments`: a list of `{ type: "image"|"file"|..., payload: { url, size?, name? } }`; `size` may be a number or digits in a text. Kept as the event's `attachments` (kind, https `url`, `name`, `bytes`); an entry with no address or of another type is left out | V1 (not re-read on the vendor page; check before going live) |
| Refusal numbers | -230, -232 reply window closed; -213 not a follower; -115, -137, -144, -211 quota; -216, -124 token rejected | zalo-failure.policy.ts |
| Webhook retries | Zalo retries anything but a 200 (ack 200, empty body) | zalo.webhook.ts |

## Webhook signature

Header `x-zevent-signature`, value `mac=<hex>`. The rule is V1's: `sha256(appId + rawBody + timestamp + oaSecretKey)`, a plain digest with the
secret appended (not an HMAC). `prove` checks it with `reach.digestEquals("sha256", [appId, body, timestamp, { secret: "oaSecretKey" }], hex)`: the
engine joins the parts, substitutes the secret inside, and compares in constant time, so the code never holds the key. It fails closed. The rule
is still V1's, not re-read on a current vendor page; the fixture builds its signed samples with the same formula, so the spec proves the code, not Zalo.

## OAuth is not used

Zalo's flow differs from the engine's generic one: the authorize URL takes `app_id` (the engine sends `client_id` and `response_type`), the token
call carries the app secret in a `secret_key` header with a form body, and the refresh token is single use (V1: zalo-oauth.policy.ts,
zalo.client.ts). So the account is the `fields` way: the person pastes the OA access token (about an hour of life in V1's fallback), so for now the
person renews it by hand with "update secrets". Automatic renewal needs an engine change; not done here.

## Rate (OA message quota)

The SDK `Provider` has no `rate` prop yet (the approved workflow pattern adds it), so none is declared. The quota is Zalo's, per OA; its numbers are not
recorded here (unknown). Meanwhile an exhausted quota comes back from `zalo.messages.send` as the declared refusal `quota_exhausted`.

## Cells

- `zalo.provider.cell.ts`: fields `appId`, `oaSecretKey`, `accessToken`, `refreshToken?` (secrets: the last three); webhook door by `copy`; data type `zalo.message`.
- `oa-profile.cell.ts` `zalo.oa.profile` (read, the connect test; `auth_failed` marks `needs_reauth`).
- `send-message.cell.ts` `zalo.messages.send` (act; refusals `window_closed`, `not_follower`, `quota_exhausted`, `auth_failed`; any other error number is `unknown`; Zalo takes no idempotency key, so a retry after `unknown` can send twice).
- `message-received.cell.ts` trigger `zalo.message.received`, subject `person:<userId>`, on by default.
- `zalo.package.ts`: the entry the integration spec builds; not part of the shipped package.
- Logo: neutral monogram `Z` (`mark: "monogram"`); Zalo's own mark was not checked for redistribution terms.

- The follow-ref field is unconfirmed: whether Zalo hands a reference (a tagged follow link) to the OA at follow time is not shown by any page fetched. NIVO Web records a tagged follow to check it.
