import { z } from "zod"
import { ZaloAttachment } from "./attachment.ts"

// The row a Zalo account keeps. A leaf: it imports no cell, so the provider and its trigger can both read it without a load cycle.

/** A kept customer message: its id, who wrote it, its kind (`text`, `image`, `file`), the text ("" for a picture or a file), the files it carries (when Zalo named any) and when it was sent. */
export const ZaloMessage = z.strictObject({
    msgId: z.string().min(1),
    userId: z.string().min(1),
    kind: z.enum(["text", "image", "file"]),
    text: z.string(),
    attachments: z.array(ZaloAttachment).optional(),
    at: z.string(),
})
