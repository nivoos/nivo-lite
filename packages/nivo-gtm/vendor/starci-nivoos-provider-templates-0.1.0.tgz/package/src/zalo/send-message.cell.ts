import { z } from "zod"
import type { JsonValue, Operation, OperationReach } from "@starci/nivoos-sdk"

export const SendMessageInput = z.strictObject({ userId: z.string().min(1), text: z.string().min(1) })
export const SendMessageOutput = z.strictObject({ ok: z.literal(true), messageId: z.string().min(1) })

type In = z.infer<typeof SendMessageInput>
type Out = z.infer<typeof SendMessageOutput>
type Code = "window_closed" | "not_follower" | "quota_exhausted" | "auth_failed"

/** Zalo's numeric errors this operation DECLARES, from V1's table (README: not re-verified against the current vendor page). */
const CODE_OF: { readonly [zaloError: number]: Code } = {
    [-230]: "window_closed",
    [-232]: "window_closed",
    [-213]: "not_follower",
    [-115]: "quota_exhausted",
    [-137]: "quota_exhausted",
    [-144]: "quota_exhausted",
    [-211]: "quota_exhausted",
    [-216]: "auth_failed",
    [-124]: "auth_failed",
}

const membersOf = (value: JsonValue | undefined): { readonly [member: string]: JsonValue } | null =>
    value === undefined || value === null || typeof value !== "object" || Array.isArray(value) ? null : (value as { readonly [member: string]: JsonValue })

/**
 * `zalo.messages.send`: sends a customer-service text to one person who wrote to the OA. Zalo answers HTTP 200 with `{ error, message, data }`;
 * `error: 0` is a send. Closed reply window, not a follower, quota exhausted and a rejected token are facts about the world and are DECLARED
 * refusals; any other numeric error, or an answer that is not that shape, is `unknown` (the message may or may not have gone). Zalo takes no
 * idempotency key, so a repeated attempt after an unknown outcome can send twice.
 */
export class ZaloSendMessage implements Operation<typeof SendMessageInput, typeof SendMessageOutput, never, Code> {
    readonly key = "zalo.messages.send"
    readonly version = 2
    readonly title = { vi: "Gửi tin tư vấn Zalo", en: "Send a Zalo customer-service message" }
    readonly input = SendMessageInput
    readonly output = SendMessageOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "zalo"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = ["window_closed", "not_follower", "quota_exhausted", "auth_failed"] as const
    // the line sender of this channel: the person's id on the OA is the user id
    readonly sendsLine = { identity: "channel", input: { userId: "{to}", text: "{text}" } } as const

    run(input: In, reach: OperationReach<never, Code>): Out {
        const response = reach.http({ method: "POST", path: "/v3.0/oa/message/cs", body: { recipient: { user_id: input.userId }, message: { text: input.text } } })
        if (response.status !== 200) return reach.byStatus()
        const body = membersOf(response.json)
        const error = body?.["error"]
        if (typeof error !== "number") return reach.unknown("zalo_answer_unreadable")
        if (error !== 0) {
            const code = CODE_OF[error]
            if (code === "window_closed") return reach.refuse("window_closed")
            if (code === "not_follower") return reach.refuse("not_follower")
            if (code === "quota_exhausted") return reach.refuse("quota_exhausted")
            if (code === "auth_failed") return reach.refuse("auth_failed")
            return reach.unknown(`zalo_error_${error}`)
        }
        const messageId = membersOf(body?.["data"])?.["message_id"]
        return typeof messageId === "string" && messageId !== "" ? { ok: true, messageId } : reach.unknown("zalo_message_id_missing")
    }
}
