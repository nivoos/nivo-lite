import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { member } from "../shared/json.ts"

export const SendMessageInput = z.strictObject({ userId: z.string().min(1), text: z.string().min(1) })
export const SendMessageOutput = z.strictObject({ ok: z.literal(true), messageId: z.string().min(1) })

type In = z.infer<typeof SendMessageInput>
type Out = z.infer<typeof SendMessageOutput>
type Code = "window_closed" | "not_follower" | "quota_exhausted" | "auth_failed"

/**
 * `zalo.messages.send`: sends a customer-service text to one person who wrote to the OA. Zalo answers HTTP 200 with `{ error, message, data }`;
 * `error: 0` is a send. Closed reply window, not a follower, quota exhausted and a rejected token are facts about the world and are DECLARED
 * refusals, mapped by the engine from the declared wire's table of Zalo's numeric errors (from V1's table; README: not re-verified against the current vendor page); any other numeric error, or an answer that is not that shape, is `unknown` (the message may or may not have gone). Zalo takes no
 * idempotency key, so a repeated attempt after an unknown outcome can send twice.
 */
export class ZaloSendMessage implements Operation<typeof SendMessageInput, typeof SendMessageOutput, never, Code> {
    readonly key = "zalo.messages.send"
    readonly version = 3
    readonly title = { vi: "Gửi tin tư vấn Zalo", en: "Send a Zalo customer-service message" }
    readonly input = SendMessageInput
    readonly output = SendMessageOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "zalo"
    readonly http = true
    readonly needs = ["accessToken"] as const
    readonly refusals = ["window_closed", "not_follower", "quota_exhausted", "auth_failed"] as const
    // the wire is the engine's: only a 200 reaches the code; Zalo's numeric `error` is read by the engine and mapped to the declared refusal; every other status is classified by the engine's one table
    readonly wire = {
        ok: [200],
        errorField: "error",
        errorCodes: {
            "-230": "window_closed",
            "-232": "window_closed",
            "-213": "not_follower",
            "-115": "quota_exhausted",
            "-137": "quota_exhausted",
            "-144": "quota_exhausted",
            "-211": "quota_exhausted",
            "-216": "auth_failed",
            "-124": "auth_failed",
        },
    } as const
    // the line sender of this channel: the person's id on the OA is the user id
    readonly sendsLine = { identity: "channel", input: { userId: "{to}", text: "{text}" } } as const

    run(input: In, reach: OperationReach<never, Code>): Out {
        const response = reach.http({ method: "POST", path: "/v3.0/oa/message/cs", body: { recipient: { user_id: input.userId }, message: { text: input.text } } })
        const error = member(response.json, "error")
        if (typeof error !== "number") return reach.unknown("zalo_answer_unreadable")
        if (error !== 0) return reach.unknown(`zalo_error_${error}`)
        const messageId = member(member(response.json, "data"), "message_id")
        return typeof messageId === "string" && messageId !== "" ? { ok: true, messageId } : reach.unknown("zalo_message_id_missing")
    }
}
