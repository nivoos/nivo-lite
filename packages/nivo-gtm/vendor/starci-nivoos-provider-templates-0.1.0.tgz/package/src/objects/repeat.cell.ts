import { z } from "zod"
import type { Node, NodeReach, ObjectCreate } from "@starci/nivoos-sdk"

const Scalar = z.union([z.string(), z.number(), z.boolean(), z.null()])
/** A member of the values the node makes an object of: a scalar, a list of scalars, or one level of members (a `geo` point, a money amount). */
const Member = z.union([Scalar, z.array(Scalar), z.record(z.string(), Scalar)])

export const RepeatInput = z.strictObject({
    /** The object type the instances are of, as its key (`sales.shift`). */
    type: z.string().min(1).max(120),
    /** The first instance as it is, every member of it: the others copy it and move the members named in `shift`. */
    values: z.record(z.string(), Member),
    /** The members of `values` that hold a date (`2026-12-01`) or an ISO date and time (`2026-12-01T08:00:00+07:00`); each moves by the rule, and the time of day and the offset stay as written. */
    shift: z.array(z.string().min(1).max(120)).min(1).max(8),
    /** Every how many units. */
    every: z.number().int().min(1).max(365),
    unit: z.enum(["day", "week", "month", "year"]),
    /** Only with `unit: "week"`: the days of the week an instance falls on (its weeks start on Monday). The date of `shift[0]` anchors the weeks; an instance before it is not made. */
    weekdays: z.array(z.enum(["mon", "tue", "wed", "thu", "fri", "sat", "sun"])).min(1).max(7).optional(),
    /** How many instances in all (the first counts); with `until` too, whichever ends first. */
    count: z.number().int().min(1).max(1000).optional(),
    /** The last day (`2026-12-31`, inclusive) an instance may fall on, by the date of `shift[0]`. */
    until: z.string().regex(/^\d{4}-\d{2}-\d{2}$/u).optional(),
    /** Which instance this run makes, from 0; a workflow loop starts at 0 and goes on with `next` until it is null. */
    index: z.number().int().min(0).max(999),
})

export const RepeatOutput = z.strictObject({
    objectId: z.string().min(1),
    version: z.number().int(),
    /** The instance that was made. */
    index: z.number().int(),
    /** How many instances the rule makes in all (cut at the settings' limit). */
    total: z.number().int(),
    /** The date or date and time of `shift[0]` of the instance that was made. */
    at: z.string(),
    /** The index to ask for next, or null when this was the last. */
    next: z.number().int().nullable(),
})

export const RepeatSettings = z.strictObject({
    /** The most instances one rule may make, whatever `count` and `until` ask for. */
    maxInstances: z.number().int().min(1).max(1000).default(366),
})

type In = z.infer<typeof RepeatInput>
type Out = z.infer<typeof RepeatOutput>
type Settings = z.infer<typeof RepeatSettings>

const WEEKDAY_INDEX = { mon: 0, tue: 1, wed: 2, thu: 3, fri: 4, sat: 5, sun: 6 } as const

/** Days since 1970-01-01 of a civil date (proleptic Gregorian). Pure integer maths: no clock, no `Date`. */
const daysOf = (year: number, month: number, day: number): number => {
    const y = month <= 2 ? year - 1 : year
    const era = Math.floor(y / 400)
    const yoe = y - era * 400
    const doy = Math.floor((153 * (month + (month > 2 ? -3 : 9)) + 2) / 5) + day - 1
    const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy
    return era * 146097 + doe - 719468
}

const civilOf = (days: number): { readonly year: number; readonly month: number; readonly day: number } => {
    const shifted = days + 719468
    const era = Math.floor(shifted / 146097)
    const doe = shifted - era * 146097
    const yoe = Math.floor((doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365)
    const doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100))
    const mp = Math.floor((5 * doy + 2) / 153)
    const day = doy - Math.floor((153 * mp + 2) / 5) + 1
    const month = mp < 10 ? mp + 3 : mp - 9
    return { year: yoe + era * 400 + (month <= 2 ? 1 : 0), month, day }
}

const lengthOfMonth = (year: number, month: number): number => daysOf(month === 12 ? year + 1 : year, month === 12 ? 1 : month + 1, 1) - daysOf(year, month, 1)

const two = (n: number): string => (n < 10 ? `0${String(n)}` : String(n))
const four = (n: number): string => (n < 1000 ? `${n < 10 ? "000" : n < 100 ? "00" : "0"}${String(n)}` : String(n))

/** A date or a date with a time: the three numbers of the date and the rest of the text (time of day and offset) kept as written. */
const partsOf = (text: string): { readonly year: number; readonly month: number; readonly day: number; readonly rest: string } | null => {
    const found = /^(\d{4})-(\d{2})-(\d{2})((?:[T ].*)?)$/u.exec(text)
    if (found === null) return null
    const year = Number(found[1])
    const month = Number(found[2])
    const day = Number(found[3])
    if (month < 1 || month > 12 || day < 1 || day > lengthOfMonth(year, month)) return null
    return { year, month, day, rest: found[4] ?? "" }
}

/** What one instance moves by: whole days, or whole months (a month move keeps the day of the month, cut to the month's last day). */
interface Move {
    readonly days: number
    readonly months: number
}

const movedText = (text: string, move: Move, member: string): string => {
    const parts = partsOf(text)
    if (parts === null) throw new Error(`objects.repeat: ${member} is not a date or an ISO date and time: ${text}`)
    if (move.months !== 0) {
        const total = parts.year * 12 + (parts.month - 1) + move.months
        const year = Math.floor(total / 12)
        const month = total - year * 12 + 1
        return `${four(year)}-${two(month)}-${two(Math.min(parts.day, lengthOfMonth(year, month)))}${parts.rest}`
    }
    const civil = civilOf(daysOf(parts.year, parts.month, parts.day) + move.days)
    return `${four(civil.year)}-${two(civil.month)}-${two(civil.day)}${parts.rest}`
}

const lastDayOf = (until: string | undefined): number | null => {
    if (until === undefined) return null
    const parts = partsOf(until)
    if (parts === null) throw new Error(`objects.repeat: until is not a date: ${until}`)
    return daysOf(parts.year, parts.month, parts.day)
}

/** Every instance the rule makes, in order: how each moves from the template (the first may be the template itself). Bounded by `limit`, by `count` and by `until` on the date of the anchor member. */
const movesOf = (input: In, anchor: string, limit: number): ReadonlyArray<Move> => {
    const parts = partsOf(anchor)
    if (parts === null) throw new Error(`objects.repeat: ${input.shift[0] ?? ""} is not a date or an ISO date and time: ${anchor}`)
    const first = daysOf(parts.year, parts.month, parts.day)
    const cap = Math.min(limit, input.count ?? limit)
    const last = lastDayOf(input.until)
    const moves: Array<Move> = []
    if (input.unit === "week" && input.weekdays !== undefined) {
        const monday = first - ((((first + 3) % 7) + 7) % 7)
        const days = Array.from(new Set(input.weekdays.map((name) => WEEKDAY_INDEX[name]))).sort((a, b) => a - b)
        for (let week = 0; week < 1000; week += 1) {
            for (const day of days) {
                const date = monday + week * input.every * 7 + day
                if (date < first) continue
                if ((last !== null && date > last) || moves.length >= cap) return moves
                moves.push({ days: date - first, months: 0 })
            }
        }
        return moves
    }
    for (let step = 0; moves.length < cap && step < 1000; step += 1) {
        const move: Move =
            input.unit === "day" ? { days: step * input.every, months: 0 }
            : input.unit === "week" ? { days: step * input.every * 7, months: 0 }
            : { days: 0, months: step * input.every * (input.unit === "year" ? 12 : 1) }
        if (last !== null) {
            const at = partsOf(movedText(anchor, move, input.shift[0] ?? ""))
            if (at !== null && daysOf(at.year, at.month, at.day) > last) return moves
        }
        moves.push(move)
    }
    return moves
}

/**
 * `objects.repeat` (Lặp đối tượng theo lịch): makes the instances of a recurring thing (a shift, a class, a maintenance) AHEAD of time as real objects of one type, so a calendar shows
 * instances and knows no rule. One run makes ONE instance (a node has one act: `object.create`): the object of `values` with the members of `shift` moved by the rule. A workflow makes them
 * all with `core.loop`: start `index` at 0, run this step, go on with `next` while it is not null. Nothing is made past `settings.maxInstances`. Moves are calendar moves on the written date:
 * a time of day and an offset stay as written (no zone rules here), a month move keeps the day of the month cut to the month's last day (31 January +1 month is 28 or 29 February). A type
 * with a unique value keeps a re-run from making a second one: the refusal comes back and stops the run at this step.
 */
export class ObjectsRepeat implements Node<typeof RepeatInput, typeof RepeatOutput, typeof RepeatSettings> {
    readonly key = "objects.repeat"
    readonly version = 1
    readonly title = { vi: "Lặp đối tượng theo lịch", en: "Repeat an object on a schedule" }
    readonly input = RepeatInput
    readonly output = RepeatOutput
    readonly settings = RepeatSettings
    readonly reads = []
    readonly mutation = "object.create"

    run(input: In, reach: NodeReach<Settings>): Out {
        const anchor = input.values[input.shift[0] ?? ""]
        if (typeof anchor !== "string") throw new Error(`objects.repeat: values.${input.shift[0] ?? ""} is not a date or an ISO date and time`)
        const moves = movesOf(input, anchor, reach.settings.maxInstances)
        const move = moves[input.index]
        if (move === undefined) throw new Error(`objects.repeat: the rule makes ${String(moves.length)} instances, there is no instance ${String(input.index)}`)
        const values: { [member: string]: z.infer<typeof Member> } = { ...input.values }
        for (const member of input.shift) {
            const text = input.values[member]
            if (typeof text !== "string") throw new Error(`objects.repeat: values.${member} is not a date or an ISO date and time`)
            values[member] = movedText(text, move, member)
        }
        const { result, error } = reach.call<ObjectCreate>("object.create", { type: input.type, values })
        if (error) throw error
        const at = values[input.shift[0] ?? ""]
        return { objectId: result.id, version: result.version, index: input.index, total: moves.length, at: typeof at === "string" ? at : anchor, next: input.index + 1 < moves.length ? input.index + 1 : null }
    }
}
