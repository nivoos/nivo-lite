# social (the provider-neutral social family)

No provider lives here: this folder holds the capability and event-kind classes that every social provider (`meta`, `telegram`, `zalo`, `youtube`, `tiktok`, `buffer`) imports for `implements` and `family`, and that `@starci/nivoos-social` lists in its `catalogue`. A package names only the family, so it never imports a vendor. Design: spec B (social distribution), sections 0 and 1.1-1.4.

| Class | Key | Kind |
| --- | --- | --- |
| `SocialPostPublish` | `social.post.publish` | write, outside, `dispatch: "fanout"` over `targets` (an account id, or `{ account, channel }`) |
| `SocialPostMetrics` | `social.post.metrics` | read |
| `SocialCommentReply` | `social.comment.reply` | write, outside |
| `SocialCommentHide` | `social.comment.hide` | write, outside |
| `SocialLeadGet` | `social.lead.get` | read |
| `SocialCommentReceived` | `social.comment.received` | event kind, subject `social-thread` |
| `SocialMessageReceived` | `social.message.received` | event kind, subject `contact` |
| `SocialLeadReceived` | `social.lead.received` | event kind, subject `social-lead` |

- Every capability names its account by the input member `account` (`Capability.accountMember`), so the call door picks the right provider account when several are bound.
- Every write is `semantics: { mutates: true, outside: true }`, so its step asks a person.
- `shapes.ts` holds `SocialChannelKind`, `MediaRef` (its `file` is a drive path the engine signs, never a vendor URL), `PostKind`, `Author` and the shared post draft.
- Each capability file also exports its refusal list (`SOCIAL_*_REFUSALS`); an operation that implements it declares a subset in `refusals`.
- Event dedupe keys: comment `<accountId>:<commentId>:<verb>`, message `<accountId>:<messageId>`, lead `<accountId>:<leadId>`. The vendor trigger that feeds a family builds them; the event kind only types the data.
- `social.lead.received` carries ids only; the details come from `social.lead.get`.
