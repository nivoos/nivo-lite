import { z } from "zod"
import type { EventKind } from "@starci/nivoos-sdk"

/** A message a person sent to the account, as any vendor reports it. `ref` is the code of an `m.me` / `ig.me` link or a Telegram `/start`; the dedupe key is `<accountId>:<messageId>`. */
export const SocialMessageReceivedData = z.strictObject({
    provider: z.string().min(1),
    accountId: z.string().min(1),
    messageId: z.string().min(1),
    senderId: z.string().min(1),
    text: z.string(),
    ref: z.string().min(1).optional(),
    adId: z.string().min(1).optional(),
    replyToCommentId: z.string().min(1).optional(),
    sentAt: z.string().min(1),
})

/** `social.message.received`: the family of a direct message on a social account; the subject is the contact. */
export class SocialMessageReceived implements EventKind<typeof SocialMessageReceivedData> {
    readonly key = "social.message.received"
    readonly version = 1
    readonly title = { vi: "Có tin nhắn mới", en: "Message received" }
    readonly event = SocialMessageReceivedData
    readonly subjectKind = "contact"
    readonly vias = ["internal"] as const
}
