import { z } from "zod"
import type { EventKind } from "@starci/nivoos-sdk"

/** A lead a vendor announced by its id; the details are read with `social.lead.get`. The dedupe key is `<accountId>:<leadId>`. */
export const SocialLeadReceivedData = z.strictObject({
    provider: z.string().min(1),
    accountId: z.string().min(1),
    leadId: z.string().min(1),
    formId: z.string().min(1),
    adId: z.string().min(1).optional(),
    campaignId: z.string().min(1).optional(),
    sentAt: z.string().min(1),
})

/** `social.lead.received`: the family of a lead-form answer; the subject is `social-lead:<leadId>`. */
export class SocialLeadReceived implements EventKind<typeof SocialLeadReceivedData> {
    readonly key = "social.lead.received"
    readonly version = 1
    readonly title = { vi: "Có khách tiềm năng mới", en: "Lead received" }
    readonly event = SocialLeadReceivedData
    readonly subjectKind = "social-lead"
    readonly vias = ["internal"] as const
}
