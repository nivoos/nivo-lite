import { z } from "zod"
import type { EventKind } from "@starci/nivoos-sdk"
import { Author, SocialAttachment } from "../shapes.ts"

/** A comment under a post of the account, as any vendor reports it. `isOwn` is set by the provider from the account's identity; the dedupe key is `<accountId>:<commentId>:<verb>`. */
export const SocialCommentReceivedData = z.strictObject({
    provider: z.string().min(1),
    accountId: z.string().min(1),
    verb: z.enum(["add", "edit", "remove"]),
    commentId: z.string().min(1),
    postId: z.string().min(1),
    parentId: z.string().min(1).optional(),
    rootId: z.string().min(1),
    author: Author,
    isOwn: z.boolean(),
    text: z.string(),
    attachments: z.array(SocialAttachment).optional(),
    sentAt: z.string().min(1),
})

/** `social.comment.received`: the family a vendor trigger declares so that a workflow takes comments once, whichever vendor they come from; the subject is the author's contact, else `social-thread:<rootId>`. */
export class SocialCommentReceived implements EventKind<typeof SocialCommentReceivedData> {
    readonly key = "social.comment.received"
    readonly version = 1
    readonly title = { vi: "Có bình luận mới", en: "Comment received" }
    readonly event = SocialCommentReceivedData
    readonly subjectKind = "social-thread"
    readonly vias = ["internal"] as const
}
