import { z } from "zod"

/** The channel a social account publishes to: one value per way the family reaches an audience. */
export const SocialChannelKind = z.enum(["facebook_page", "instagram", "tiktok", "youtube", "zalo_oa", "telegram_channel", "buffer_profile"])

/** A file of a post: `file` is a drive path of the workspace that the engine signs when a vendor needs an address; it is never a vendor URL. */
export const MediaRef = z.strictObject({
    kind: z.enum(["image", "video"]),
    file: z.string().min(1).max(500),
    alt: z.string().max(300).optional(),
    coverAtMs: z.number().int().min(0).optional(),
})

/** What a post is, as the vendor can take it: the vendor refuses `kind_unsupported` for a kind it has no way to publish. */
export const PostKind = z.enum(["text", "link", "image", "carousel", "video", "reel", "short", "story", "article"])

/** Who wrote a comment: the vendor's id, and the name and handle when the vendor gave them. */
export const Author = z.strictObject({ id: z.string().min(1).max(320), name: z.string().max(200).optional(), handle: z.string().max(100).optional() })

/** One file a comment carries, as the SDK's `ChannelAttachment` keeps it: an https address or the vendor's own reference, a kind, and a name and size when given. */
export const SocialAttachment = z.strictObject({
    kind: z.string().min(1),
    url: z.string().min(1).optional(),
    ref: z.string().min(1).optional(),
    name: z.string().min(1).optional(),
    bytes: z.number().int().nonnegative().optional(),
})

/** The account a social call runs on: the id of a bound, active account of the provider that implements the capability. Every capability names it by the member `account`. */
export const SocialAccount = z.string().min(1).max(100)

/** How a post is shown: the options a vendor honours, and ignores when it has no such switch. */
export const PostOptions = z.strictObject({
    privacy: z.enum(["public", "followers", "private"]).optional(),
    allowComments: z.boolean().optional(),
    madeForKids: z.boolean().optional(),
    aiGenerated: z.boolean().optional(),
})

/** What a post needs to go out; `social.post.schedule` adds the instant. */
export const PostDraft = z.strictObject({
    account: SocialAccount,
    kind: PostKind,
    text: z.string().max(63206),
    title: z.string().max(150).optional(),
    link: z.string().max(2000).optional(),
    media: z.array(MediaRef).max(20),
    refCode: z.string().min(1).max(40).optional(),
    options: PostOptions.optional(),
})

/** The refusals of every publish: shared by `social.post.publish` and `social.post.schedule`. */
export const PUBLISH_REFUSALS = ["kind_unsupported", "media_invalid", "text_too_long", "quota_exhausted", "account_restricted", "audit_required", "auth_failed"] as const
