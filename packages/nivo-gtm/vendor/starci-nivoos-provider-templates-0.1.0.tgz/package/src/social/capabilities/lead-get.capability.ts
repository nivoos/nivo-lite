import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { SocialAccount } from "../shapes.ts"

export const SocialLeadGetInput = z.strictObject({
    account: SocialAccount,
    leadId: z.string().min(1),
})

export const SocialLeadGetOutput = z.strictObject({
    leadId: z.string().min(1),
    formId: z.string().min(1),
    adId: z.string().optional(),
    campaignId: z.string().optional(),
    at: z.string().min(1),
    /** What the person filled in: one entry per form field, with every value it held. */
    fields: z.array(z.strictObject({ name: z.string(), values: z.array(z.string()) })),
})

/** The refusals an operation implementing `social.lead.get` declares. */
export const SOCIAL_LEAD_GET_REFUSALS = ["lead_gone", "auth_failed"] as const

/** `social.lead.get`: the details of a lead the vendor announced by its id only; a read. */
export class SocialLeadGet implements Capability<typeof SocialLeadGetInput, typeof SocialLeadGetOutput> {
    readonly key = "social.lead.get"
    readonly version = 1
    readonly title = { vi: "Lấy thông tin khách tiềm năng", en: "Get a lead" }
    readonly input = SocialLeadGetInput
    readonly output = SocialLeadGetOutput
    readonly semantics = { mutates: false }
    readonly accountMember = "account"
}
