import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { SocialAccount } from "../shapes.ts"

export const SocialCommentHideInput = z.strictObject({
    account: SocialAccount,
    commentId: z.string().min(1),
    hidden: z.boolean(),
})

export const SocialCommentHideOutput = z.strictObject({ hidden: z.boolean() })

/** The refusals an operation implementing `social.comment.hide` declares. */
export const SOCIAL_COMMENT_HIDE_REFUSALS = ["comment_gone", "hide_unsupported", "auth_failed"] as const

/** `social.comment.hide`: hide a comment from the audience, or show it again. */
export class SocialCommentHide implements Capability<typeof SocialCommentHideInput, typeof SocialCommentHideOutput> {
    readonly key = "social.comment.hide"
    readonly version = 1
    readonly title = { vi: "Ẩn bình luận", en: "Hide a comment" }
    readonly input = SocialCommentHideInput
    readonly output = SocialCommentHideOutput
    readonly semantics = { mutates: true, outside: true }
    readonly accountMember = "account"
}
