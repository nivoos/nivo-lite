import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { PostDraft, PUBLISH_REFUSALS } from "../shapes.ts"

export const SocialPostScheduleInput = PostDraft.extend({
    /** The instant the post goes out (ISO 8601). */
    at: z.iso.datetime({ offset: true }),
})

export const SocialPostScheduleOutput = z.strictObject({
    scheduledId: z.string().min(1),
    at: z.string().min(1),
    /** `true` when the vendor holds the post and publishes it itself. A vendor with no scheduling refuses `schedule_unsupported` instead. */
    native: z.boolean(),
})

/** The refusals an operation implementing `social.post.schedule` declares. */
export const SOCIAL_POST_SCHEDULE_REFUSALS = [...PUBLISH_REFUSALS, "schedule_window", "schedule_unsupported"] as const

/** `social.post.schedule`: "let this vendor publish this post at that instant"; a vendor with no scheduling refuses `schedule_unsupported`, and the engine then holds the act itself. */
export class SocialPostSchedule implements Capability<typeof SocialPostScheduleInput, typeof SocialPostScheduleOutput> {
    readonly key = "social.post.schedule"
    readonly version = 1
    readonly title = { vi: "Hẹn giờ đăng bài", en: "Schedule a post" }
    readonly input = SocialPostScheduleInput
    readonly output = SocialPostScheduleOutput
    readonly semantics = { mutates: true, outside: true }
    readonly accountMember = "account"
}
