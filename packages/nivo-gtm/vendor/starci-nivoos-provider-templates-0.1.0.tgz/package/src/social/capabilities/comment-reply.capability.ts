import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { SocialAccount } from "../shapes.ts"

export const SocialCommentReplyInput = z.strictObject({
    account: SocialAccount,
    commentId: z.string().min(1),
    postId: z.string().min(1).optional(),
    text: z.string().min(1).max(8000),
    /** Answer in private (a message to the author) instead of in public under the comment. */
    private: z.boolean().optional(),
})

export const SocialCommentReplyOutput = z.strictObject({
    replyId: z.string().min(1),
    private: z.boolean(),
})

/** The refusals an operation implementing `social.comment.reply` declares. */
export const SOCIAL_COMMENT_REPLY_REFUSALS = ["comment_gone", "window_closed", "private_reply_unsupported", "quota_exhausted", "auth_failed"] as const

/** `social.comment.reply`: "answer this comment", in public or in private; it leaves the company, so its step asks a person. */
export class SocialCommentReply implements Capability<typeof SocialCommentReplyInput, typeof SocialCommentReplyOutput> {
    readonly key = "social.comment.reply"
    readonly version = 1
    readonly title = { vi: "Trả lời bình luận", en: "Reply to a comment" }
    readonly input = SocialCommentReplyInput
    readonly output = SocialCommentReplyOutput
    readonly semantics = { mutates: true, outside: true }
    readonly accountMember = "account"
}
