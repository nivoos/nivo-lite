import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { PostDraft, PUBLISH_REFUSALS, SocialAccount, SocialChannelKind } from "../shapes.ts"

/** What an OPERATION that publishes takes: one post on one account (the engine fills `account` from the target). */
export const SocialPostPublishInput = PostDraft

export const SocialPostPublishOutput = z.strictObject({
    postId: z.string().optional(),
    url: z.string().optional(),
    /** The post waits in the vendor's drafts for a person to finish it (TikTok while the app is unaudited). */
    inbox: z.boolean().optional(),
})

/** One target of a publish: an account of the agent, and the channel of it when it reaches several (a Facebook Page and its Instagram account). */
export const PublishTarget = z.union([SocialAccount, z.strictObject({ account: SocialAccount, channel: SocialChannelKind.optional() })])

/** What the CAPABILITY takes: the post, once, and the explicit `targets` it goes to. `account` is the engine's, set on each target's own call; a caller never gives it. */
export const SocialPostPublishCallInput = PostDraft.extend({ account: SocialAccount.optional(), targets: z.array(PublishTarget).min(1).max(20) })

/**
 * One target's result, in the door's envelope (`CallResult`): `done` with the operation's output, `pending` with the ticket of the job the engine follows (it ends in `engine.job.finished`), or `refused`
 * with the refusal and its detail. Each target is one of the three on its own.
 */
export const SocialPostPublishCallOutput = z.strictObject({
    results: z.array(
        z.strictObject({
            account: z.string(),
            channel: z.string().nullable(),
            status: z.enum(["done", "pending", "refused"]),
            output: SocialPostPublishOutput.optional(),
            ticket: z.strictObject({ jobId: z.string(), etaSeconds: z.number().optional(), estimateCredits: z.number().optional() }).optional(),
            refusal: z.string().optional(),
            detail: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
        }),
    ),
})

/** The refusals an operation implementing `social.post.publish` declares. */
export const SOCIAL_POST_PUBLISH_REFUSALS = PUBLISH_REFUSALS

/**
 * `social.post.publish`: the provider-neutral name of "publish this post on these accounts"; it leaves the company, so its step asks a person. `dispatch: "fanout"`: one act per target, each with its own intent key, retry and
 * result, no fallback, and a partial success is a valid answer. A target's `channel` picks the operation among the ones of its account's provider (Instagram is a target of the same Meta account).
 */
export class SocialPostPublish implements Capability<typeof SocialPostPublishCallInput, typeof SocialPostPublishCallOutput> {
    readonly key = "social.post.publish"
    readonly version = 1
    readonly title = { vi: "Đăng bài lên kênh", en: "Publish a post" }
    readonly input = SocialPostPublishCallInput
    readonly output = SocialPostPublishCallOutput
    readonly semantics = { mutates: true, outside: true }
    readonly accountMember = "account"
    readonly dispatch = "fanout" as const
}
