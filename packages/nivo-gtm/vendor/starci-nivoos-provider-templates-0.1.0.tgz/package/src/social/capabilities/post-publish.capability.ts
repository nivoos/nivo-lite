import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { PostDraft, PUBLISH_REFUSALS } from "../shapes.ts"

export const SocialPostPublishInput = PostDraft

export const SocialPostPublishOutput = z.strictObject({
    /** `published` the post is live; `processing` the vendor still works on it (the `jobId` follows it); `inbox` the post waits in the vendor's drafts for a person to finish it. */
    state: z.enum(["published", "processing", "inbox"]),
    postId: z.string().optional(),
    url: z.string().optional(),
    jobId: z.string().optional(),
})

/** The refusals an operation implementing `social.post.publish` declares. */
export const SOCIAL_POST_PUBLISH_REFUSALS = PUBLISH_REFUSALS

/** `social.post.publish`: the provider-neutral name of "publish this post on that account"; it leaves the company, so its step asks a person. */
export class SocialPostPublish implements Capability<typeof SocialPostPublishInput, typeof SocialPostPublishOutput> {
    readonly key = "social.post.publish"
    readonly version = 1
    readonly title = { vi: "Đăng bài lên kênh", en: "Publish a post" }
    readonly input = SocialPostPublishInput
    readonly output = SocialPostPublishOutput
    readonly semantics = { mutates: true, outside: true }
    readonly accountMember = "account"
}
