import { z } from "zod"
import type { Capability } from "@starci/nivoos-sdk"
import { SocialAccount } from "../shapes.ts"

export const SocialPostMetricsInput = z.strictObject({
    account: SocialAccount,
    postIds: z.array(z.string().min(1)).min(1).max(50),
})

/** A metric a vendor has no counterpart for is left out; it is never filled with a vendor name. */
export const SocialPostMetricsOutput = z.strictObject({
    items: z.array(z.strictObject({
        postId: z.string().min(1),
        at: z.string().min(1),
        views: z.number().nonnegative().optional(),
        reach: z.number().nonnegative().optional(),
        likes: z.number().nonnegative().optional(),
        comments: z.number().nonnegative().optional(),
        shares: z.number().nonnegative().optional(),
        saves: z.number().nonnegative().optional(),
        clicks: z.number().nonnegative().optional(),
        watchSeconds: z.number().nonnegative().optional(),
    })),
    /** The post ids the vendor cannot report. */
    unsupported: z.array(z.string()),
})

/** The refusals an operation implementing `social.post.metrics` declares. */
export const SOCIAL_POST_METRICS_REFUSALS = ["auth_failed"] as const

/** `social.post.metrics`: the numbers of posts, in normalised names; a read. */
export class SocialPostMetrics implements Capability<typeof SocialPostMetricsInput, typeof SocialPostMetricsOutput> {
    readonly key = "social.post.metrics"
    readonly version = 1
    readonly title = { vi: "Số liệu bài đăng", en: "Post metrics" }
    readonly input = SocialPostMetricsInput
    readonly output = SocialPostMetricsOutput
    readonly semantics = { mutates: false }
    readonly accountMember = "account"
}
