import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { AvatarSpeak, AvatarSpeakInput } from "../media/capabilities/avatar-speak.capability.ts"
import { mediaRefusalsWithFiles } from "../media/schemas.ts"
import type { MediaRefusal } from "../media/schemas.ts"
import { member } from "../shared/json.ts"
import type { HeygenAccount } from "./heygen.provider.cell.ts"
import { HEYGEN_ERROR_FIELD, HEYGEN_TRANSIENT } from "./wire.ts"

/** The capability's input plus the member the engine fills with its per-job nudge address (`job.callback`). Exactly one of `script` and `audio` is the engine's check. */
export const VideosCreateInput = AvatarSpeakInput.extend({ callbackUrl: z.string().min(1).optional() })
export const VideosCreateOutput = z.strictObject({
    /** The vendor job id: the engine reads it at `job.vendorJobId`. */
    videoId: z.string().min(1),
    /** The vendor word at submit (`waiting`). */
    status: z.string().min(1),
})

type In = z.infer<typeof VideosCreateInput>
type Out = z.infer<typeof VideosCreateOutput>
type Refusal = MediaRefusal

/** The ratios HeyGen documents (README); 3:4 and 4:3 are not among them. */
const ASPECTS: ReadonlyArray<string> = ["16:9", "9:16", "4:5", "1:1"]

/**
 * `heygen.videos.create`: `POST /v3/videos` with `type: "avatar"`. The vendor renders asynchronously: the declared job makes the ENGINE read `heygen.videos.get` until `completed`, then collect the video and the SRT.
 * `script` goes with `voice_id`; `audio` (a `FileRef`, which the engine has replaced with a signed address) goes as `audio_url` (spec A section 1.9 rule 2: a Vietnamese voice from `voice.speak`).
 * The price is a placeholder ("giá tạm") until HeyGen's per-second price is confirmed (README).
 */
export class HeygenVideosCreate implements Operation<typeof VideosCreateInput, typeof VideosCreateOutput, HeygenAccount, Refusal> {
    readonly key = "heygen.videos.create"
    readonly version = 1
    readonly title = { vi: "Tạo video người dẫn AI (HeyGen)", en: "Create AI presenter video (HeyGen)" }
    readonly input = VideosCreateInput
    readonly output = VideosCreateOutput
    // 0.05 USD per second is a PLACEHOLDER: no HeyGen page read gives a price (README). The estimate shows it labelled "giá tạm".
    readonly semantics = { mutates: true, metered: { usage: "units", price: { usdPerUnit: 0.05 }, estimate: { units: { textLength: "script", per: 15 } } } } as const
    readonly provider = "heygen"
    readonly http = true
    readonly implements = AvatarSpeak
    readonly needs = ["apiKey"] as const
    readonly refusals = mediaRefusalsWithFiles
    readonly wire = {
        errorField: HEYGEN_ERROR_FIELD,
        errorCodes: { invalid_parameter: "input_invalid", avatar_not_usable: "input_invalid", resource_not_ready: "input_invalid" },
        transientCodes: HEYGEN_TRANSIENT,
        idempotency: { header: "Idempotency-Key" },
    } as const
    readonly job = {
        status: "heygen.videos.get",
        vendorJobId: "videoId",
        state: { path: "status", pending: ["pending", "processing"], done: ["completed"], failed: ["failed"] },
        outputs: { path: "files", as: "url" },
        poll: { firstAfterMs: 20_000, everyMs: 15_000, maxEveryMs: 60_000, factor: 1.5 },
        timeoutMs: 30 * 60_000,
        callback: { inputMember: "callbackUrl" },
        usage: { path: "duration", unit: "video_seconds" },
    } as const

    run(input: In, reach: OperationReach<HeygenAccount, Refusal>): Out {
        if (!ASPECTS.includes(input.aspect)) return reach.refuse("input_invalid")
        const background: JsonObject | undefined =
            input.background === undefined ? undefined : typeof input.background === "string" ? { type: "color", value: input.background } : { type: "image", url: input.background.file }
        const body: JsonObject = {
            type: "avatar",
            avatar_id: input.avatar,
            engine: { type: "avatar_iv" },
            aspect_ratio: input.aspect,
            ...(input.resolution === undefined ? {} : { resolution: input.resolution }),
            ...(input.script === undefined ? {} : { script: input.script }),
            ...(input.voice === undefined ? {} : { voice_id: input.voice }),
            ...(input.audio === undefined ? {} : { audio_url: input.audio.file }),
            ...(background === undefined ? {} : { background }),
            ...(input.captions === true ? { caption: { file_format: "srt" } } : {}),
            ...(input.callbackUrl === undefined ? {} : { callback_url: input.callbackUrl }),
        }
        const response = reach.http({ method: "POST", path: "/v3/videos", headers: { "content-type": "application/json" }, body })
        const data = member(response.json, "data")
        const videoId = member(data, "video_id")
        const status = member(data, "status")
        return typeof videoId === "string" && videoId !== "" ? { videoId, status: typeof status === "string" && status !== "" ? status : "waiting" } : reach.unknown("create_shape")
    }
}
