import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { member } from "../shared/json.ts"
import type { HeygenAccount } from "./heygen.provider.cell.ts"
import { HEYGEN_ERROR_FIELD, HEYGEN_TRANSIENT } from "./wire.ts"

export const VideosGetInput = z.strictObject({ vendorJobId: z.string().min(1) })
export const VideosGetOutput = z.strictObject({
    id: z.string().min(1),
    /** `pending`, `processing`, `completed` or `failed`. */
    status: z.string().min(1),
    /** The addresses the engine downloads at collect: the video first, then the SRT when there is one. Empty until `completed`. */
    files: z.array(z.string()),
    /** Seconds of video: the unit billed (`job.usage`); 0 until known. */
    duration: z.number().nonnegative(),
    failureCode: z.string().optional(),
    failureMessage: z.string().optional(),
})

type Refusal = "auth_failed"

/**
 * `heygen.videos.get`: `GET /v3/videos/{id}`, the read the engine polls. The `video_url` is presigned and short-lived, so the engine reads it fresh at collect (README).
 */
export class HeygenVideosGet implements Operation<typeof VideosGetInput, typeof VideosGetOutput, HeygenAccount, Refusal> {
    readonly key = "heygen.videos.get"
    readonly version = 1
    readonly title = { vi: "Trạng thái video HeyGen", en: "HeyGen video status" }
    readonly input = VideosGetInput
    readonly output = VideosGetOutput
    readonly semantics = { mutates: false }
    readonly provider = "heygen"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: HEYGEN_ERROR_FIELD, transientCodes: HEYGEN_TRANSIENT } as const

    run(input: z.infer<typeof VideosGetInput>, reach: OperationReach<HeygenAccount, Refusal>): z.infer<typeof VideosGetOutput> {
        const answer = reach.http({ method: "GET", path: `/v3/videos/${encodeURIComponent(input.vendorJobId)}` })
        const data = member(answer.json, "data")
        const id = member(data, "id")
        const status = member(data, "status")
        if (typeof id !== "string" || id === "" || typeof status !== "string" || status === "") return reach.unknown("video_shape")
        const video = member(data, "video_url")
        const subtitle = member(data, "subtitle_url")
        const duration = member(data, "duration")
        const code = member(data, "failure_code")
        const message = member(data, "failure_message")
        const files: Array<string> = []
        if (status === "completed" && typeof video === "string" && video !== "") {
            files.push(video)
            if (typeof subtitle === "string" && subtitle !== "") files.push(subtitle)
        }
        return {
            id,
            status,
            files,
            duration: typeof duration === "number" && duration >= 0 ? duration : 0,
            ...(typeof code === "string" ? { failureCode: code } : {}),
            ...(typeof message === "string" ? { failureMessage: message } : {}),
        }
    }
}
