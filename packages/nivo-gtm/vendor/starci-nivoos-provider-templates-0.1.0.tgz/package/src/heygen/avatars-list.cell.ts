import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { isObject, member } from "../shared/json.ts"
import type { HeygenAccount } from "./heygen.provider.cell.ts"
import { HEYGEN_ERROR_FIELD, HEYGEN_TRANSIENT } from "./wire.ts"

export const AvatarsListInput = z.strictObject({
    /** `public` (HeyGen's preset avatars) or `private`; absent: public only, because custom avatars are not built (spec A O3). */
    ownership: z.enum(["public", "private"]).optional(),
    /** The cursor of the previous page. */
    token: z.string().min(1).optional(),
})
export const AvatarsListOutput = z.strictObject({
    avatars: z.array(
        z.strictObject({
            /** The value of `avatar` in `avatar.speak`. */
            id: z.string().min(1),
            name: z.string(),
            avatarType: z.string(),
            previewImageUrl: z.string().optional(),
            defaultVoiceId: z.string().optional(),
            engines: z.array(z.string()),
        }),
    ),
    nextToken: z.string().optional(),
})

type Refusal = "auth_failed"
const text = (value: unknown): string | undefined => (typeof value === "string" && value !== "" ? value : undefined)

/** `heygen.avatars.list`: `GET /v3/avatars/looks` (one page of up to 50; the `id` of a look is the `avatar_id` of a video). */
export class HeygenAvatarsList implements Operation<typeof AvatarsListInput, typeof AvatarsListOutput, HeygenAccount, Refusal> {
    readonly key = "heygen.avatars.list"
    readonly version = 1
    readonly title = { vi: "Danh sách người dẫn HeyGen", en: "HeyGen presenters" }
    readonly input = AvatarsListInput
    readonly output = AvatarsListOutput
    readonly semantics = { mutates: false }
    readonly provider = "heygen"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: HEYGEN_ERROR_FIELD, transientCodes: HEYGEN_TRANSIENT } as const

    run(input: z.infer<typeof AvatarsListInput>, reach: OperationReach<HeygenAccount, Refusal>): z.infer<typeof AvatarsListOutput> {
        const answer = reach.http({
            method: "GET",
            path: "/v3/avatars/looks",
            query: { ownership: input.ownership ?? "public", limit: 50, ...(input.token === undefined ? {} : { token: input.token }) },
        })
        const items = member(answer.json, "data")
        if (!Array.isArray(items)) return reach.unknown("avatars_shape")
        const avatars: z.infer<typeof AvatarsListOutput>["avatars"] = []
        for (const item of items as ReadonlyArray<unknown>) {
            if (!isObject(item)) return reach.unknown("avatar_shape")
            const id = text(item["id"])
            if (id === undefined) return reach.unknown("avatar_shape")
            const preview = text(item["preview_image_url"])
            const voice = text(item["default_voice_id"])
            const engines = item["supported_api_engines"]
            avatars.push({
                id,
                name: text(item["name"]) ?? "",
                avatarType: text(item["avatar_type"]) ?? "",
                ...(preview === undefined ? {} : { previewImageUrl: preview }),
                ...(voice === undefined ? {} : { defaultVoiceId: voice }),
                engines: Array.isArray(engines) ? (engines as ReadonlyArray<unknown>).filter((engine): engine is string => typeof engine === "string") : [],
            })
        }
        const next = text(member(answer.json, "next_token"))
        return { avatars, ...(next === undefined ? {} : { nextToken: next }) }
    }
}
