# heygen

HeyGen v3 AI presenter for `avatar.speak` (spec A section 1.5, lane gm-p-heygen). Pages read 2026-11-18. v1 and v2 reached end of support on 2026-10-31, so only v3 is used. Anything not on a cited page is marked UNVERIFIED.

## What it is
- Provider `heygen`, `accountOwner: "platform"`, base `https://api.heygen.com`. Account field `apiKey` (secret), from the instance custody variable of spec A section 7 (the upper-case form of nivo-media-heygen-api-key; no typed reader declares it yet). A workspace never sees it. No real key was entered here.
- Auth: header `x-api-key` (https://developers.heygen.com/reference/create-video). `Authorization: Bearer` is the documented alternative and is not used.
- Logo: neutral monogram; HeyGen's brand terms were not checked.
- Not built: `heygen.avatars.create` (custom or photo avatars, owner decision O3: stock avatars only).

## Operations
| key | wire | notes |
|---|---|---|
| `heygen.videos.create` (implements `avatar.speak`) | `POST /v3/videos` | declares the job; `wire.idempotency` header `Idempotency-Key` from the intent key |
| `heygen.videos.get` | `GET /v3/videos/{id}` | the status read the engine polls |
| `heygen.avatars.list` | `GET /v3/avatars/looks?ownership=public&limit=50` | `id` of a look is the `avatar_id` |
| `heygen.voices.list` | `GET /v3/models/audio/voices?type=public&language=vi&limit=50` | |

### create
- Body (schema `CreateVideoFromAvatar`, `additionalProperties: false`): `type: "avatar"`, `avatar_id`, `engine: { type: "avatar_iv" }`, `aspect_ratio`, `resolution` (`4k`, `1080p`, `720p`; 4k is for digital twins and studio avatars, so the capability never sends it), `script` + `voice_id`, or `audio_url` (public http(s) URL; the engine has swapped the `FileRef` for a signed address), `background` (`{ type: "color", value: "#rrggbb" }` or `{ type: "image", url }`), `caption: { file_format: "srt" }`, `callback_url`.
- `aspect_ratio` accepts `16:9`, `9:16`, `4:5`, `5:4`, `1:1`, `auto`. The capability's `3:4` and `4:3` are not accepted: the operation refuses them as `input_invalid` before any call.
- `callback_url` is the engine's per-job nudge address (`job.callback.inputMember = "callbackUrl"`, an optional member the operation adds to the capability's input). HeyGen's webhook is signed (HMAC-SHA256, header `signature`, per spec A); it only nudges, the status read stays authoritative. `callback_id` is not sent: the nudge address already names the job.
- Answer: `{ data: { video_id, status: "waiting", ... } }`. The operation answers `{ videoId, status }`.
- "Exactly one of script and audio" is the engine's check (a Zod schema cannot say it). With neither, HeyGen answers `invalid_parameter`, mapped to `input_invalid`.
- A script without `voice` relies on the avatar's default voice (page: voice_id required "unless avatar_id's default voice is used"). For Vietnamese send `audio` from `voice.speak` (spec A section 1.9 rule 2).

### get and the job
- Answer `data`: `id`, `status` (`pending`, `processing`, `completed`, `failed`), `video_url`, `subtitle_url`, `captioned_video_url`, `duration` (seconds), `failure_code`, `failure_message` (https://developers.heygen.com/reference/get-video).
- Job: states `pending`, `processing` pending; `completed` done; `failed` failed. `outputs = { path: "files", as: "url" }`: `heygen.videos.get` answers `files` as `[video_url]`, plus `subtitle_url` second when present, and only once `completed`. `usage = duration` in `video_seconds`.
- The presigned `video_url` is short lived: the engine downloads at collect, and the status read is made fresh then. No cancel is documented, so none is declared.
- `captioned_video_url` (captions burned in) is not collected: the SRT is the product and `video.compose` burns captions with the brand's style. `caption.style` is left off, which the page documents as "sidecar-only captions".
- Poll ladder 20 s, 15 s growing by 1.5 up to 60 s, deadline 30 minutes: chosen by us, not by a page. UNVERIFIED: typical render time.

## Errors
Body `{ error: { code, message, param, doc_url, errors, request_id } }`, so `wire.errorField = "error.code"` (UNVERIFIED: that the engine reads a dotted path here; the Deepgram lane used a top-level field).
| status | code | handling |
|---|---|---|
| 400 | `invalid_parameter`, `avatar_not_usable` | `input_invalid` |
| 409 | `resource_not_ready` | `input_invalid` (the avatar is not ready) |
| 409 | `request_in_progress` | `transientCodes`, 5 s (same idempotency key still running) |
| 401 | `unauthorized` | the engine's table (platform alert) |
| 429 | `rate_limit_exceeded` | `transientCodes`, 10 s (`Retry-After` is on the answer; UNVERIFIED that the engine reads it, so a fixed fallback is declared) |
UNVERIFIED: the `failure_code` values of a failed video (moderation, quota), so every failed job ends as the engine's generic failure; map them in `job` when a real failure is recorded. `content_refused` and `quota_exceeded` are declared in `refusals` and have no vendor code yet.

## Limits and price
- https://developers.heygen.com/docs/usage-limits: pay-as-you-go concurrency 10; video creation 10 per second; status reads 500 per minute plus 600 per minute per IP. Declared as `rate.perAccount` (10 per second on `heygen.videos.create`). The 500 per minute status budget is far above the poll ladder.
- Script at most 5000 characters (the capability's own limit) and video at most 30 minutes: from spec A, not re-read.
- **Price: UNVERIFIED.** The usage-limits page states no per-second price. `semantics.metered.price = { usdPerUnit: 0.05 }` per `video_seconds` is a PLACEHOLDER, so every presenter estimate is labelled "giá tạm" in the console (DECISIONS 2026-11-18, item 7). Replace it when the owner confirms the plan's price. Estimate: script length at 15 characters per second.

## Voices
`GET /v3/models/audio/voices`: `type` (`private` default, `public`), `limit` 1 to 100 (a public page at most 50), `token` cursor, `language`, `gender`, `age`, `query` (public only). Answer `data[]` of `{ voice_id, mode, name, language, gender, status, preview_audio_url }`, `has_more`, `next_token` (https://developers.heygen.com/reference/list-voices). UNVERIFIED: that `language=vi` is accepted; the page lists no codes and does not mention Vietnamese. TODO: confirm with a real call.

## Avatars
`GET /v3/avatars/looks`: `group_id`, `avatar_type`, `ownership` (`public` or `private`), `limit` 1 to 50, `token`. Answer `data[]` with `id`, `name`, `avatar_type`, `preview_image_url`, `default_voice_id`, `supported_api_engines`, `has_more`, `next_token` (https://developers.heygen.com/reference/list-avatar-looks). `engine: avatar_iv` is sent always; UNVERIFIED: that every public look lists `avatar_iv` in `supported_api_engines` (the list operation returns it so a caller can check).

## Recorded exchanges
No real key: the fixtures under `be/src/tests/fixtures/e2e/providers/heygen/` are built from the documented shapes above and marked `documented`, not recorded. Per operation: success and refusal; for the job, the pending, processing, completed (and failed) sequence of `heygen.videos.get`. The failed-video shape and the webhook body are guesses within the documented fields.
