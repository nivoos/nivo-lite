import { z } from "zod"
import type { Provider } from "@starci/nivoos-sdk"

/** What the platform account of HeyGen holds: the API key, from the instance's custody env the custody variable (never typed in a workspace). */
export const HeygenFields = z.strictObject({
    /** The public name of the account (the identity): the instance writes "platform". */
    account: z.string().min(1),
    apiKey: z.string().min(1),
})

export type HeygenAccount = z.infer<typeof HeygenFields>

/**
 * `heygen`: AI presenter videos (v3 API, https://developers.heygen.com/reference/create-video) for `avatar.speak`. A platform account: NIVO's key, metered in NIVO credit, never connectable in a workspace.
 * The key travels in `x-api-key`. Rates (https://developers.heygen.com/docs/usage-limits): video creation 10 per second per account. See README.md.
 */
export class HeygenProvider implements Provider<typeof HeygenFields, z.ZodObject<{}>, {}> {
    readonly key = "heygen"
    readonly version = 1
    readonly title = { vi: "HeyGen", en: "HeyGen" }
    readonly description = {
        vi: "Người dẫn AI: video một nhân vật đọc kịch bản hoặc khớp môi với tệp âm thanh có sẵn.",
        en: "AI presenter: a video of an avatar reading a script or lip-syncing an audio file you already have.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly fields = HeygenFields
    readonly secrets = ["apiKey"] as const
    readonly form = {
        account: { label: { vi: "Tên tài khoản", en: "Account name" }, help: { vi: "Tên hiển thị của tài khoản nền tảng.", en: "The display name of the platform account." }, kind: "text", order: 0 },
        apiKey: { label: { vi: "Khoá API", en: "API key" }, help: { vi: "Do nền tảng giữ; không nhập trong không gian làm việc.", en: "Held by the platform; never entered in a workspace." }, kind: "secret", order: 1 },
    } as const
    readonly identityField = "account"
    readonly kind = "base"
    readonly accountOwner = "platform"
    readonly base = { fixed: "https://api.heygen.com" }
    readonly auth = { scheme: "header", name: "x-api-key", secretField: "apiKey" } as const
    readonly authWays = [{ kind: "fields" }] as const
    readonly rate = { perAccount: [{ count: 10, per: { seconds: 1 }, operations: ["heygen.videos.create"] }] } as const
    readonly dataTypes = {}
}
