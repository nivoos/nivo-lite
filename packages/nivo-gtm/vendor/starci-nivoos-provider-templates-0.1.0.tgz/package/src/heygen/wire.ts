/** The wire facts shared by the HeyGen operations (README, "Errors"): the error body is `{ error: { code, message } }`. */
export const HEYGEN_ERROR_FIELD = "error.code"

/** 429 `rate_limit_exceeded` carries `Retry-After`; 409 `request_in_progress` is the same idempotency key still running. */
export const HEYGEN_TRANSIENT = { rate_limit_exceeded: { retryAfterSeconds: 10 }, request_in_progress: { retryAfterSeconds: 5 } } as const
