import { z } from "zod"
import type { Operation, OperationReach } from "@starci/nivoos-sdk"
import { isObject, member } from "../shared/json.ts"
import type { HeygenAccount } from "./heygen.provider.cell.ts"
import { HEYGEN_ERROR_FIELD, HEYGEN_TRANSIENT } from "./wire.ts"

export const VoicesListInput = z.strictObject({
    /** A language code; absent: `vi`. UNVERIFIED: HeyGen's page does not list the codes it accepts (README). */
    language: z.string().min(2).max(8).optional(),
    gender: z.enum(["male", "female"]).optional(),
    token: z.string().min(1).optional(),
})
export const VoicesListOutput = z.strictObject({
    voices: z.array(
        z.strictObject({
            /** The value of `voice` in `avatar.speak`. */
            id: z.string().min(1),
            name: z.string(),
            language: z.string().optional(),
            gender: z.string().optional(),
        }),
    ),
    nextToken: z.string().optional(),
})

type Refusal = "auth_failed"
const text = (value: unknown): string | undefined => (typeof value === "string" && value !== "" ? value : undefined)

/** `heygen.voices.list`: `GET /v3/models/audio/voices?type=public&language=vi` (one page of up to 50). For Vietnamese the design answer is `audio` from `voice.speak`, not a HeyGen voice (README). */
export class HeygenVoicesList implements Operation<typeof VoicesListInput, typeof VoicesListOutput, HeygenAccount, Refusal> {
    readonly key = "heygen.voices.list"
    readonly version = 1
    readonly title = { vi: "Danh sách giọng HeyGen", en: "HeyGen voices" }
    readonly input = VoicesListInput
    readonly output = VoicesListOutput
    readonly semantics = { mutates: false }
    readonly provider = "heygen"
    readonly http = true
    readonly needs = ["apiKey"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: HEYGEN_ERROR_FIELD, transientCodes: HEYGEN_TRANSIENT } as const

    run(input: z.infer<typeof VoicesListInput>, reach: OperationReach<HeygenAccount, Refusal>): z.infer<typeof VoicesListOutput> {
        const answer = reach.http({
            method: "GET",
            path: "/v3/models/audio/voices",
            query: { type: "public", language: input.language ?? "vi", limit: 50, ...(input.gender === undefined ? {} : { gender: input.gender }), ...(input.token === undefined ? {} : { token: input.token }) },
        })
        const items = member(answer.json, "data")
        if (!Array.isArray(items)) return reach.unknown("voices_shape")
        const voices: z.infer<typeof VoicesListOutput>["voices"] = []
        for (const item of items as ReadonlyArray<unknown>) {
            if (!isObject(item)) return reach.unknown("voice_shape")
            const id = text(item["voice_id"])
            if (id === undefined) return reach.unknown("voice_shape")
            const language = text(item["language"])
            const gender = text(item["gender"])
            voices.push({ id, name: text(item["name"]) ?? "", ...(language === undefined ? {} : { language }), ...(gender === undefined ? {} : { gender }) })
        }
        const next = text(member(answer.json, "next_token"))
        return { voices, ...(next === undefined ? {} : { nextToken: next }) }
    }
}
