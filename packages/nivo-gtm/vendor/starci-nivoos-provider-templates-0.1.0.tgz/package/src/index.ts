// The provider-templates package as a module: its authored package (what `nivoos package build` turns into seed/provider-templates@<version>.json) and its key.
export { default as providerTemplates } from "./provider-templates.package.ts"
export { PACKAGE_KEY } from "./package-key.ts"
