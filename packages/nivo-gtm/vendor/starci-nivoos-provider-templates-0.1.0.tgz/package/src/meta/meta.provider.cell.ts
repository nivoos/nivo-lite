import { z } from "zod"
import type { Delivery, ProofRequest, Provider, ProviderReach, ReceiveResult } from "@starci/nivoos-sdk"
import { setup } from "@starci/nivoos-sdk"
import { MetaMe } from "./me.cell.ts"
import { MetaPageSubscribe } from "./page-subscribe.cell.ts"
import { MetaMessages } from "./messages.cell.ts"
import { MetaData, rowsOfDelivery } from "./rows.ts"

/**
 * What an account of Meta connects with: ONE Facebook Page and its linked Instagram account. Public: `appId`, `pageId` (the identity) and `igUserId`. Sealed: `appSecret` (the key of the webhook proof), the
 * Page token, and `verifyToken` (the secret of the GET handshake, generated here). `pageToken` and `refreshToken` are optional members because the shared-app sign-in (mode 1, guarded off) fills them;
 * the connect form of mode 2 asks for the token, and every operation needs it.
 */
export const MetaFields = z.strictObject({
    appId: z.string().regex(/^\d{5,25}$/u),
    pageId: z.string().regex(/^\d{5,25}$/u),
    igUserId: z.string().regex(/^\d{5,25}$/u).optional(),
    appSecret: z.string().min(1),
    pageToken: z.string().min(1).optional(),
    refreshToken: z.string().min(1).optional(),
    verifyToken: z.string().regex(/^[A-Za-z0-9_-]{16,256}$/u),
})

/** The one header a delivery is proved by: `sha256=<HMAC-SHA256 of the raw body, keyed by the app secret>`. */
export const MetaProof = z.strictObject({ "x-hub-signature-256": z.string().optional() })

/** The query parameter Meta puts the verify value in during the GET handshake (a parameter NAME, not a value). */
const HANDSHAKE_CHECK = "hub.verify_token"

type Fields = z.infer<typeof MetaFields>
type Proof = z.infer<typeof MetaProof>

/** The permissions of both modes (spec B 2.2): posts and comments, webhooks, Messenger, Lead Ads, and Instagram through Facebook Login. */
const SCOPES = [
    "pages_manage_posts",
    "pages_read_engagement",
    "pages_manage_engagement",
    "pages_read_user_engagement",
    "pages_manage_metadata",
    "pages_messaging",
    "pages_show_list",
    "leads_retrieval",
    "pages_manage_ads",
    "instagram_basic",
    "instagram_content_publish",
    "instagram_manage_comments",
    "instagram_manage_messages",
] as const

/**
 * `meta`: a Facebook Page and its linked Instagram account (Graph API). Calls go to `https://graph.facebook.com/v27.0` with the Page token as a bearer credential. Deliveries are proved by `X-Hub-Signature-256`
 * (HMAC-SHA256 of the raw body under the app secret); the GET handshake answers `hub.challenge` when `hub.verify_token` is the account's `verifyToken`; the registration is `meta.page.subscribe`. A delivery
 * holds up to 1000 changes: every comment (Facebook or Instagram), lead and message in it is one row, and everything else is left out. Two ways to connect: `fields` (the customer's own app, built, the
 * default) and `oauth2` (the shared NIVO app, declared and guarded off until app-scoped routing and App Review exist, see README).
 */
export class MetaProvider implements Provider<typeof MetaFields, typeof MetaProof, typeof MetaData> {
    readonly key = "meta"
    readonly version = 1
    readonly title = { vi: "Meta (Facebook, Instagram)", en: "Meta (Facebook, Instagram)" }
    readonly fields = MetaFields
    readonly secrets = ["appSecret", "pageToken", "refreshToken", "verifyToken"] as const
    readonly description = {
        vi: "Một Trang Facebook và tài khoản Instagram liên kết: đăng bài, trả lời bình luận, nhận tin nhắn Messenger và khách tiềm năng từ quảng cáo.",
        en: "A Facebook Page and its linked Instagram account: publish posts, answer comments, receive Messenger messages and Lead Ads leads.",
    }
    readonly logo = { file: "logo.svg", mark: "monogram" } as const
    readonly form = {
        appId: {
            label: { vi: "Mã ứng dụng (App ID)", en: "App ID" },
            help: { vi: "Mã của ứng dụng Meta bạn tạo trên developers.facebook.com (App settings, Basic).", en: "The id of the Meta app you made at developers.facebook.com (App settings, Basic)." },
            kind: "text",
            order: 1,
        },
        pageId: {
            label: { vi: "Mã Trang Facebook", en: "Facebook Page ID" },
            help: { vi: "Mã số của Trang (trong Giới thiệu của Trang, hoặc Business settings).", en: "The numeric id of the Page (in the Page About section, or Business settings)." },
            kind: "text",
            order: 2,
        },
        igUserId: {
            label: { vi: "Mã tài khoản Instagram", en: "Instagram account ID" },
            help: { vi: "Tuỳ chọn: mã của tài khoản Instagram chuyên nghiệp đã liên kết với Trang. Để trống nếu chỉ dùng Facebook.", en: "Optional: the id of the Instagram professional account linked to the Page. Leave empty to use Facebook only." },
            kind: "text",
            order: 3,
        },
        appSecret: {
            label: { vi: "Khoá bí mật ứng dụng (App Secret)", en: "App secret" },
            help: { vi: "Trong App settings, Basic. NIVO dùng nó để kiểm tra chữ ký của mỗi tin Meta gửi tới.", en: "In App settings, Basic. NIVO uses it to check the signature of every delivery Meta sends." },
            kind: "secret",
            order: 4,
        },
        pageToken: {
            label: { vi: "Mã truy cập của Trang", en: "Page access token" },
            help: { vi: "Mã dài hạn của Trang, hoặc mã System User có gán Trang. Tạo bằng Graph API Explorer hoặc Business settings.", en: "A long-lived Page token, or a System User token with the Page assigned. Made in the Graph API Explorer or Business settings." },
            kind: "secret",
            order: 5,
        },
        refreshToken: {
            label: { vi: "Mã làm mới", en: "Refresh token" },
            help: { vi: "Không cần nhập: chỉ dùng khi kết nối bằng ứng dụng dùng chung của NIVO.", en: "Not entered by hand: used only when connecting with the shared NIVO app." },
            kind: "secret",
            order: 6,
        },
        verifyToken: {
            label: { vi: "Mã xác minh webhook", en: "Webhook verify token" },
            help: { vi: "Bấm Tự sinh, rồi dán đúng mã này vào ô Verify token khi cấu hình Webhooks trong ứng dụng Meta.", en: "Generate it, then paste the same value in the Verify token field when you configure Webhooks in the Meta app." },
            kind: "secret",
            order: 7,
            generate: { bytes: 32, encoding: "hex" },
        },
    } as const
    readonly identityField = "pageId"
    readonly kind = "contact"
    readonly base = { fixed: "https://graph.facebook.com/v27.0" }
    readonly auth = { scheme: "bearer", secretField: "pageToken" } as const
    readonly authWays = [
        { kind: "fields" },
        // mode 1, the shared NIVO app: unusable while META_APP_ID / META_APP_SECRET are unset. Needs app-scoped webhook routing (B S-E1b) and many accounts per sign-in (S-E8), later.
        {
            kind: "oauth2",
            authorizeUrl: "https://www.facebook.com/v27.0/dialog/oauth",
            tokenUrl: "https://graph.facebook.com/v27.0/oauth/access_token",
            scopes: SCOPES,
            clientIdEnv: "META_APP_ID",
            clientSecretEnv: "META_APP_SECRET",
            tokenField: "pageToken",
            refreshField: "refreshToken",
        },
    ] as const
    readonly connectTest = "meta.me"
    /** Instagram allows 100 API posts per rolling 24 hours, enforced at `media_publish` (https://developers.facebook.com/docs/instagram-platform/content-publishing). */
    readonly rate = { perAccount: [{ count: 100, per: { hours: 24 }, operations: ["meta.ig.media.publish"] }] } as const
    readonly webhook = {
        proof: MetaProof,
        ack: { status: 200 },
        refusedStatus: 403,
        registration: { kind: "operation", operation: "meta.page.subscribe" },
        // a delivery holds up to 1000 changes: the default 256 KiB may not hold a full batch
        maxBodyBytes: 1_048_576,
        challenge: { secret: "verifyToken", modeParam: "hub.mode", modeValue: "subscribe", tokenParam: HANDSHAKE_CHECK, echoParam: "hub.challenge" },
    } as const
    /** The Lead Ads fallback: the engine polls the leads when a delivery was lost. */
    readonly poll = { operation: "meta.leads.poll", dataType: "meta.lead", aloneMs: 300_000, besideWebhookMs: 900_000, ratePerSecond: 1, burst: 2, concurrency: 1 } as const
    /** Sources: https://developers.facebook.com/docs/graph-api/webhooks/getting-started (webhooks, Live mode), https://developers.facebook.com/docs/graph-api/reference/page/subscribed_apps/ (subscribe the Page), https://developers.facebook.com/docs/marketing-api/guides/lead-ads/retrieving (Leads Access Manager). */
    readonly setup = [
        setup.guide({
            key: "create-app",
            title: { vi: "Tạo ứng dụng Meta của bạn", en: "Make your own Meta app" },
            body: {
                vi: "1. Vào **developers.facebook.com**, tạo ứng dụng với mục đích \"Quản lý mọi thứ trên Trang của bạn\". Thêm các sản phẩm **Webhooks**, **Messenger**, **Instagram** và **Lead Ads**.\n2. Điền **URL chính sách quyền riêng tư** và **URL xoá dữ liệu** (NIVO sẽ cung cấp trang để dán vào; hiện chưa có địa chỉ).\n3. Chuyển ứng dụng sang chế độ **Live**: chế độ Development không nhận webhook thật.\n4. Cho người quản trị Trang một vai trò trong ứng dụng. Vì bạn là quản trị cả ứng dụng lẫn Trang nên không cần App Review.\n5. Để tuỳ chọn **Require App Secret** ở trạng thái **tắt**.",
                en: "1. Go to **developers.facebook.com** and make an app with the use case \"Manage everything on your Page\". Add the products **Webhooks**, **Messenger**, **Instagram** and **Lead Ads**.\n2. Fill the **privacy policy URL** and the **data deletion URL** (NIVO will give you pages to paste; they have no address yet).\n3. Switch the app to **Live**: Development mode receives no real webhooks.\n4. Give the Page admin a role on the app. You are admin of both the app and the Page, so no App Review is needed.\n5. Leave **Require App Secret** switched **off**.",
            },
            link: { label: { vi: "Hướng dẫn webhook của Meta", en: "Meta webhooks guide" }, url: "https://developers.facebook.com/docs/graph-api/webhooks/getting-started" },
        }),
        setup.fields({
            key: "credentials",
            title: { vi: "Nhập thông tin ứng dụng và Trang", en: "Enter the app and Page details" },
            body: {
                vi: "Dán mã ứng dụng, mã Trang, khoá bí mật và mã truy cập dài hạn của Trang (hoặc mã System User có gán Trang). Bấm **Tự sinh** ở mã xác minh webhook.",
                en: "Paste the app id, the Page id, the app secret and a long-lived Page token (or a System User token with the Page assigned). Press **Generate** on the webhook verify token.",
            },
            fields: ["appId", "pageId", "igUserId", "appSecret", "pageToken", "verifyToken"],
        }),
        setup.check({ key: "verify", title: { vi: "Kiểm tra Trang", en: "Check the Page" }, operation: MetaMe, show: "name" }),
        setup.guide({
            key: "webhooks",
            title: { vi: "Cấu hình Webhooks trong ứng dụng", en: "Configure Webhooks in the app" },
            body: {
                vi: "Trong ứng dụng Meta, mục Webhooks: dán **địa chỉ ở bước tiếp theo** và **mã xác minh** bạn vừa sinh. Với đối tượng **Page**, đăng ký các trường `feed`, `messages`, `messaging_referrals` và `leadgen`; với đối tượng **Instagram**, đăng ký `comments` và `messages` (Instagram chỉ đăng ký được ở đây).",
                en: "In the Meta app, Webhooks: paste the **address from the next step** and the **verify token** you generated. For the **Page** object subscribe `feed`, `messages`, `messaging_referrals` and `leadgen`; for the **Instagram** object subscribe `comments` and `messages` (Instagram can only be subscribed here).",
            },
            link: { label: { vi: "Các trường webhook của Trang", en: "Page webhook fields" }, url: "https://developers.facebook.com/docs/graph-api/webhooks/reference/page" },
        }),
        setup.webhook({
            key: "webhook",
            title: { vi: "Đăng ký Trang với ứng dụng", en: "Subscribe the Page to the app" },
            body: { vi: "NIVO gọi `subscribed_apps` của Trang để Meta bắt đầu gửi các sự kiện của Trang tới địa chỉ webhook.", en: "NIVO calls the Page's `subscribed_apps` so Meta starts sending the Page's events to the webhook address." },
            register: MetaPageSubscribe,
        }),
        setup.guide({
            key: "lead-access",
            title: { vi: "Cho phép ứng dụng đọc khách tiềm năng", en: "Let the app read leads" },
            body: {
                vi: "Chỉ cần nếu bạn chạy quảng cáo Lead Ads: trong **Leads Access Manager**, cấp cho ứng dụng (CRM) quyền truy cập vào Trang.",
                en: "Only if you run Lead Ads: in **Leads Access Manager**, give the app (a CRM) access to the Page.",
            },
            optional: true,
            link: { label: { vi: "Lấy khách tiềm năng", en: "Retrieving leads" }, url: "https://developers.facebook.com/docs/marketing-api/guides/lead-ads/retrieving" },
        }),
        setup.waitEvent({
            key: "first-message",
            title: { vi: "Nhắn thử cho Trang", en: "Message the Page" },
            body: { vi: "Gửi một tin nhắn tới Trang trên Messenger. Trang tự cập nhật khi NIVO nhận được tin. Có thể bỏ qua.", en: "Send the Page a message on Messenger. This page updates when NIVO receives it. You may skip this." },
            optional: true,
            trigger: MetaMessages,
            timeout: "10m",
        }),
        setup.bind({ key: "agents", title: { vi: "Gắn vào tác tử", en: "Attach to agents" } }),
    ] as const
    readonly dataTypes = MetaData

    /** A delivery is Meta's for this account when `X-Hub-Signature-256` is `sha256=` and the HMAC-SHA256 of the raw body under the app secret. */
    prove(request: ProofRequest<Proof>, reach: ProviderReach<Fields>): boolean {
        const header = request.headers["x-hub-signature-256"]
        if (typeof header !== "string" || !header.startsWith("sha256=")) return false
        return reach.hmacEquals({ algorithm: "sha256", secret: "appSecret", message: request.body, presented: header.slice("sha256=".length), encoding: "hex" })
    }

    /** Every comment, lead and message of the delivery, one row each (up to 1000 changes in one POST). */
    receive(delivery: Delivery, reach: ProviderReach<Fields>): ReceiveResult<typeof MetaData> {
        const account = reach.account()
        const rows = rowsOfDelivery(delivery.json, { pageId: account.pageId, igUserId: account.igUserId }, reach.now())
        if (rows === null) return { kind: "invalid", why: "not_a_page_or_instagram_delivery" }
        return rows.length === 0 ? { kind: "ignored", why: "no_comment_lead_or_message" } : { kind: "rows", rows }
    }
}
