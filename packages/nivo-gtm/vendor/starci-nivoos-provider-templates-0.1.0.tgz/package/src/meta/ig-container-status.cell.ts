import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { member } from "../shared/json.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"

export const ContainerStatusInput = z.strictObject({ vendorJobId: z.string().min(1) })
/** `statusCode` is the vendor word (`IN_PROGRESS`, `FINISHED`, `ERROR`, `EXPIRED`, `PUBLISHED`); `id` is the container, which the chained publish takes as `creationId`. */
export const ContainerStatusOutput = z.strictObject({ id: z.string().min(1), statusCode: z.string().min(1) })

type Refusal = "auth_failed"

/** `meta.ig.container.status`: `GET /{container}?fields=status_code`, the read the engine polls for an Instagram post (Meta suggests once a minute for at most 5 minutes). */
export class MetaIgContainerStatus implements Operation<typeof ContainerStatusInput, typeof ContainerStatusOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.container.status"
    readonly version = 1
    readonly title = { vi: "Trạng thái bài Instagram", en: "Instagram post status" }
    readonly input = ContainerStatusInput
    readonly output = ContainerStatusOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof ContainerStatusInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof ContainerStatusOutput> {
        const answer = reach.http({ method: "GET", path: `/${input.vendorJobId}`, query: { fields: "status_code" } })
        const statusCode = member(answer.json, "status_code")
        return typeof statusCode === "string" && statusCode !== "" ? { id: input.vendorJobId, statusCode } : reach.unknown("status_shape")
    }
}
