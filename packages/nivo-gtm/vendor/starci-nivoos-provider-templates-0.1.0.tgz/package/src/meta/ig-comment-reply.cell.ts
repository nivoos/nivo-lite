import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialCommentReplyInput, SocialCommentReplyOutput } from "../social/capabilities/comment-reply.capability.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { idOf } from "./graph.ts"

type Refusal = "comment_gone" | "private_reply_unsupported" | "auth_failed"

/**
 * `meta.ig.comment.reply`: `POST /{ig-comment}/replies` with `message`; the vendor answers `{ id }`. Needs `instagram_manage_comments`, and Advanced Access for an account the app does not own.
 * A private reply through Instagram messaging is not built (`private_reply_unsupported`). Same input and output as the capability; it does not declare `implements` (see README).
 */
export class MetaIgCommentReply implements Operation<typeof SocialCommentReplyInput, typeof SocialCommentReplyOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.comment.reply"
    readonly version = 1
    readonly title = { vi: "Trả lời bình luận Instagram", en: "Reply to an Instagram comment" }
    readonly input = SocialCommentReplyInput
    readonly output = SocialCommentReplyOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["comment_gone", "private_reply_unsupported", "auth_failed"] as const
    readonly external = true
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "100": "comment_gone", "210": "comment_gone" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialCommentReplyInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialCommentReplyOutput> {
        if (input.private === true) return reach.refuse("private_reply_unsupported")
        const replyId = idOf(reach.http({ method: "POST", path: `/${input.commentId}/replies`, body: { message: input.text } }).json)
        return replyId === null ? reach.unknown("reply_shape") : { replyId, private: false }
    }
}
