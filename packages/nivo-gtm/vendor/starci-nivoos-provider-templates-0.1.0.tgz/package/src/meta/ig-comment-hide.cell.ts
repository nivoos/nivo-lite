import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialCommentHideInput, SocialCommentHideOutput } from "../social/capabilities/comment-hide.capability.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { succeeded } from "./graph.ts"

type Refusal = "comment_gone" | "auth_failed"

/**
 * `meta.ig.comment.hide`: `POST /{ig-comment}` with `hide` (true or false). The page read shows the endpoint but not the parameter name or the answer, so `hide` and `{ success }` are from memory (see README).
 * Same input and output as the capability; it does not declare `implements` (see README).
 */
export class MetaIgCommentHide implements Operation<typeof SocialCommentHideInput, typeof SocialCommentHideOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.comment.hide"
    readonly version = 1
    readonly title = { vi: "Ẩn bình luận Instagram", en: "Hide an Instagram comment" }
    readonly input = SocialCommentHideInput
    readonly output = SocialCommentHideOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["comment_gone", "auth_failed"] as const
    readonly external = true
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "100": "comment_gone", "210": "comment_gone" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialCommentHideInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialCommentHideOutput> {
        const answer = reach.http({ method: "POST", path: `/${input.commentId}`, body: { hide: input.hidden } })
        return succeeded(answer.json) ? { hidden: input.hidden } : reach.unknown("hide_shape")
    }
}
