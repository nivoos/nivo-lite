import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialPostMetrics, SocialPostMetricsInput, SocialPostMetricsOutput } from "../social/capabilities/post-metrics.capability.ts"
import { member } from "../shared/json.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"

type Refusal = "auth_failed"
type Item = z.infer<typeof SocialPostMetricsOutput>["items"][number]

/** The number a Graph insight holds: `insights.data[0].values[0].value`; undefined when the metric is missing. */
const insightOf = (node: unknown, name: string): number | undefined => {
    const data = member(member(node, "insights"), "data")
    const found = Array.isArray(data) ? data.find((entry) => member(entry, "name") === name) : undefined
    const values = member(found, "values")
    const value = Array.isArray(values) ? member(values[0], "value") : undefined
    return typeof value === "number" ? value : undefined
}

const countOf = (node: unknown, edge: string): number | undefined => {
    const total = member(member(member(node, edge), "summary"), "total_count")
    return typeof total === "number" ? total : undefined
}

/**
 * `meta.post.metrics`: the numbers of Facebook Page posts, in the normalised names (`social.post.metrics`), from ONE call over the ids (`GET /?ids=a,b&fields=...`, up to 50): `views` is the insight
 * `post_media_view` (the replacement of `post_impressions`, deprecated 2025-11-15), `likes` the reactions total, `comments` and `shares` the counts. A post the answer does not hold (deleted, or not the Page's)
 * is listed in `unsupported`; a number the vendor did not give is left out. The field expansion syntax is the vendor's; it was not exercised (see README).
 */
export class MetaPostMetrics implements Operation<typeof SocialPostMetricsInput, typeof SocialPostMetricsOutput, JsonObject, Refusal> {
    readonly key = "meta.post.metrics"
    readonly version = 1
    readonly title = { vi: "Số liệu bài đăng Facebook", en: "Facebook post metrics" }
    readonly input = SocialPostMetricsInput
    readonly output = SocialPostMetricsOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly implements = SocialPostMetrics
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialPostMetricsInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialPostMetricsOutput> {
        const answer = reach.http({
            method: "GET",
            path: "/",
            query: { ids: input.postIds.join(","), fields: "created_time,reactions.summary(true).limit(0),comments.summary(true).limit(0),shares,insights.metric(post_media_view)" },
        })
        const items: Array<Item> = []
        const unsupported: Array<string> = []
        for (const postId of input.postIds) {
            const node = member(answer.json, postId)
            if (node === undefined) {
                unsupported.push(postId)
                continue
            }
            const created = member(node, "created_time")
            const views = insightOf(node, "post_media_view")
            const likes = countOf(node, "reactions")
            const comments = countOf(node, "comments")
            const shares = member(member(node, "shares"), "count")
            items.push({
                postId,
                at: typeof created === "string" ? created : reach.now(),
                ...(views === undefined ? {} : { views }),
                ...(likes === undefined ? {} : { likes }),
                ...(comments === undefined ? {} : { comments }),
                ...(typeof shares === "number" ? { shares } : {}),
            })
        }
        return { items, unsupported }
    }
}
