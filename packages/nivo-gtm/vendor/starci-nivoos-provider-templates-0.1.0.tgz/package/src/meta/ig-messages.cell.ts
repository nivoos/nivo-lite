import type { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SocialMessageReceived, SocialMessageReceivedData } from "../social/events/message-received.event.ts"
import { MetaMessage } from "./rows.ts"
import { messageEventOf } from "./events.ts"

/** `meta.ig.messages`: a direct message to the linked Instagram account (the Instagram `messages` field, set in the app dashboard), or an entry through an `ig.me` link; the same family event, customer line and `ref` as `meta.messages`. Payload shape from memory (see README). */
export class MetaIgMessages implements Trigger<typeof MetaMessage, typeof SocialMessageReceivedData> {
    readonly key = "meta.ig.messages"
    readonly version = 1
    readonly title = { vi: "Có tin nhắn Instagram mới", en: "Instagram message received" }
    readonly row = MetaMessage
    readonly event = SocialMessageReceivedData
    readonly provider = "meta"
    readonly dataType = { providerVersion: 1, key: "meta.message" }
    readonly keyMember = "messageId"
    readonly subjectKind = "contact"
    readonly subjectMember = "senderId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    readonly line = { identity: "channel", contactMember: "senderId", textMember: "text" } as const
    readonly refMember = "ref"
    readonly family = SocialMessageReceived

    translate(row: z.infer<typeof MetaMessage>, _reach: TriggerReach): TriggerEvent<z.infer<typeof SocialMessageReceivedData>> | null {
        return messageEventOf(row, "instagram")
    }
}
