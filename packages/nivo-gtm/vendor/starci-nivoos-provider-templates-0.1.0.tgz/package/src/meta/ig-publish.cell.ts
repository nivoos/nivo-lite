import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialPostPublishInput, SocialPostPublishOutput } from "../social/capabilities/post-publish.capability.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { idOf } from "./graph.ts"

type Refusal = "kind_unsupported" | "media_invalid" | "text_too_long" | "account_restricted" | "auth_failed"
type Media = z.infer<typeof SocialPostPublishInput>["media"][number]

/** The caption of an Instagram post holds at most 2,200 characters (from memory of the vendor limits: not on the page read, see README). */
const CAPTION_MAX = 2200
/** A carousel holds 2 to 10 items; the children plus the parent are at most the 10 calls one run may make, so 9 items here. */
const CAROUSEL_MAX = 9

/** The address field of a media item: Meta fetches `image_url` or `video_url` itself (the engine signs the drive path first). */
const addressOf = (media: Media): JsonObject => (media.kind === "image" ? { image_url: media.file } : { video_url: media.file })

/**
 * `meta.ig.publish`: step one of an Instagram post: creates the media CONTAINER (`POST /{ig}/media`: a photo, a Reel, a story, or a carousel made of child containers) and answers `processing` with the
 * container id as the job id. The ENGINE follows it (the declared job reads `meta.ig.container.status` until `FINISHED`), then chains `meta.ig.media.publish`, which publishes it. Not `implements`: the call
 * door binds ONE operation to a capability per provider, and the Facebook one holds that place (see README).
 */
export class MetaIgPublish implements Operation<typeof SocialPostPublishInput, typeof SocialPostPublishOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.publish"
    readonly version = 1
    readonly title = { vi: "Đăng bài lên Instagram", en: "Publish to Instagram" }
    readonly input = SocialPostPublishInput
    readonly output = SocialPostPublishOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken", "igUserId"] as const
    readonly refusals = ["kind_unsupported", "media_invalid", "text_too_long", "account_restricted", "auth_failed"] as const
    readonly external = true
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "368": "account_restricted" }, transientCodes: META_TRANSIENT } as const
    readonly job = {
        status: "meta.ig.container.status",
        vendorJobId: "jobId",
        state: { path: "statusCode", pending: ["IN_PROGRESS"], done: ["FINISHED"], failed: ["ERROR", "EXPIRED"] },
        poll: { firstAfterMs: 10_000, everyMs: 30_000, maxEveryMs: 60_000, factor: 1.5 },
        timeoutMs: 15 * 60_000,
        then: { operation: "meta.ig.media.publish", input: { creationId: "job.result.id" } },
    } as const

    run(input: z.infer<typeof SocialPostPublishInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialPostPublishOutput> {
        const account = reach.account() as { readonly igUserId?: string }
        const first = input.media[0]
        if (account.igUserId === undefined) return reach.refuse("account_restricted")
        if (input.text.length > CAPTION_MAX) return reach.refuse("text_too_long")
        const path = `/${account.igUserId}/media`
        if (input.kind === "carousel") {
            if (input.media.length < 2 || input.media.length > CAROUSEL_MAX) return reach.refuse("media_invalid")
            const children = input.media.map((item) => idOf(reach.http({ method: "POST", path, body: { is_carousel_item: true, ...(item.kind === "video" ? { media_type: "VIDEO" } : {}), ...addressOf(item) } }).json))
            const ids = children.filter((id): id is string => id !== null)
            if (ids.length !== children.length) return reach.unknown("carousel_child_shape")
            const parent = idOf(reach.http({ method: "POST", path, body: { media_type: "CAROUSEL", children: ids.join(","), caption: input.text } }).json)
            return parent === null ? reach.unknown("container_shape") : { state: "processing", jobId: parent }
        }
        if (first === undefined || input.media.length !== 1) return reach.refuse(input.kind === "text" || input.kind === "link" || input.kind === "short" || input.kind === "article" ? "kind_unsupported" : "media_invalid")
        let body: JsonObject
        if (input.kind === "image" && first.kind === "image") body = { ...addressOf(first), caption: input.text }
        else if ((input.kind === "video" || input.kind === "reel") && first.kind === "video") body = { media_type: "REELS", ...addressOf(first), caption: input.text }
        else if (input.kind === "story") body = { media_type: "STORIES", ...addressOf(first) }
        else return reach.refuse(input.kind === "image" || input.kind === "video" || input.kind === "reel" ? "media_invalid" : "kind_unsupported")
        const container = idOf(reach.http({ method: "POST", path, body }).json)
        return container === null ? reach.unknown("container_shape") : { state: "processing", jobId: container }
    }
}
