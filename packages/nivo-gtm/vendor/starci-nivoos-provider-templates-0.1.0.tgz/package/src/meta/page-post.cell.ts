import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialPostPublish, SocialPostPublishInput, SocialPostPublishOutput } from "../social/capabilities/post-publish.capability.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { pagePublishPlan, publishedIdOf } from "./page-publish.ts"
import { postUrl } from "./graph.ts"

type Refusal = "kind_unsupported" | "media_invalid" | "account_restricted" | "auth_failed"

/**
 * `meta.page.post`: publishes a post on the Facebook Page (`social.post.publish`): text and link on `/feed`, one image on `/photos`, one video on `/videos`. The privacy and comment options have no switch on a
 * Page post and are ignored. `media[].file` must arrive as an address Meta can fetch (the engine signs the drive path, spec B S-E5); a video is processed by Meta after the call answers. Code 368 (the action is
 * seen as abuse) is `account_restricted`. Reels are not built (the path was not read).
 */
export class MetaPagePost implements Operation<typeof SocialPostPublishInput, typeof SocialPostPublishOutput, JsonObject, Refusal> {
    readonly key = "meta.page.post"
    readonly version = 1
    readonly title = { vi: "Đăng bài lên Trang Facebook", en: "Publish to the Facebook Page" }
    readonly input = SocialPostPublishInput
    readonly output = SocialPostPublishOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly implements = SocialPostPublish
    readonly refusals = ["kind_unsupported", "media_invalid", "account_restricted", "auth_failed"] as const
    readonly external = true
    // Graph has no idempotency header: the engine guards the publish itself (an attempt per intent key, no blind re-send after a lost answer)
    readonly wire = { dedupe: {}, errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "368": "account_restricted" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialPostPublishInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialPostPublishOutput> {
        const account = reach.account() as { readonly pageId: string }
        const plan = pagePublishPlan(input, account.pageId)
        if ("refuse" in plan) return reach.refuse(plan.refuse)
        const answer = reach.http({ method: "POST", path: plan.path, body: plan.body })
        const postId = publishedIdOf(plan.via, answer.json)
        if (postId === null) return reach.unknown("publish_shape")
        return { postId, ...(plan.via === "videos" ? {} : { url: postUrl(postId) }) }
    }
}
