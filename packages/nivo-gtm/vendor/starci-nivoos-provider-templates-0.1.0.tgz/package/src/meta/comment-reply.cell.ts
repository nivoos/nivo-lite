import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialCommentReply, SocialCommentReplyInput, SocialCommentReplyOutput } from "../social/capabilities/comment-reply.capability.ts"
import { member } from "../shared/json.ts"
import { META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { idOf } from "./graph.ts"

type Refusal = "comment_gone" | "window_closed" | "auth_failed"

/**
 * `meta.comment.reply`: answers a comment under a post of the Page (`social.comment.reply`). In public it is `POST /{comment}/comments` with `message`; with `private: true` it is the one private reply
 * Meta allows per comment, within 7 days of it: `POST /{page}/messages` with `recipient.comment_id` (needs `pages_messaging`; a Standard Access app reaches only people with a role on the app). Both paths are ONE
 * operation because only one operation of a provider can implement a capability. Error codes (from memory, see README): 10 on the private path is the closed window, 100 and 210 a comment that is gone,
 * 190, 102 and 200 a token or permission the vendor refuses.
 */
export class MetaCommentReply implements Operation<typeof SocialCommentReplyInput, typeof SocialCommentReplyOutput, JsonObject, Refusal> {
    readonly key = "meta.comment.reply"
    readonly version = 1
    readonly title = { vi: "Trả lời bình luận Facebook", en: "Reply to a Facebook comment" }
    readonly input = SocialCommentReplyInput
    readonly output = SocialCommentReplyOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly implements = SocialCommentReply
    readonly refusals = ["comment_gone", "window_closed", "auth_failed"] as const
    readonly external = true
    readonly wire = {
        errorField: META_ERROR_FIELD,
        errorCodes: { "10": "window_closed", "100": "comment_gone", "210": "comment_gone", "190": "auth_failed", "102": "auth_failed", "200": "auth_failed" },
        transientCodes: META_TRANSIENT,
    } as const

    run(input: z.infer<typeof SocialCommentReplyInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialCommentReplyOutput> {
        if (input.private === true) {
            const account = reach.account() as { readonly pageId: string }
            const sent = reach.http({ method: "POST", path: `/${account.pageId}/messages`, body: { recipient: { comment_id: input.commentId }, message: { text: input.text }, messaging_type: "RESPONSE" } })
            const messageId = member(sent.json, "message_id")
            return typeof messageId === "string" && messageId !== "" ? { replyId: messageId, private: true } : reach.unknown("private_reply_shape")
        }
        const replyId = idOf(reach.http({ method: "POST", path: `/${input.commentId}/comments`, body: { message: input.text } }).json)
        return replyId === null ? reach.unknown("reply_shape") : { replyId, private: false }
    }
}
