import type { z } from "zod"
import type { JsonObject } from "@starci/nivoos-sdk"
import type { PostDraft } from "../social/shapes.ts"

type Draft = z.infer<typeof PostDraft>

/** What a Facebook Page can take of a post: where it goes and its body, or the refusal. */
export type PagePublishPlan =
    | { readonly refuse: "kind_unsupported" | "media_invalid" }
    | { readonly via: "feed" | "photos" | "videos"; readonly path: string; readonly body: JsonObject }

/**
 * Maps a post draft to the Page edge that takes it (spec B 2.1): text and link to `/{page}/feed`, one image to `/{page}/photos` (`url`), one video to `/{page}/videos` (`file_url`). A carousel, a reel,
 * a short, a story or an article is not published here (the Reels path is not read yet, and several photos need an unpublished-photo step), so it is `kind_unsupported`. Pure.
 */
export const pagePublishPlan = (draft: Draft, pageId: string): PagePublishPlan => {
    const first = draft.media[0]
    switch (draft.kind) {
        case "text":
            return { via: "feed", path: `/${pageId}/feed`, body: { message: draft.text } }
        case "link":
            return draft.link === undefined ? { refuse: "media_invalid" } : { via: "feed", path: `/${pageId}/feed`, body: { message: draft.text, link: draft.link } }
        case "image":
            return first === undefined || first.kind !== "image" || draft.media.length !== 1 ? { refuse: "media_invalid" } : { via: "photos", path: `/${pageId}/photos`, body: { url: first.file, caption: draft.text } }
        case "video":
            return first === undefined || first.kind !== "video" || draft.media.length !== 1
                ? { refuse: "media_invalid" }
                : { via: "videos", path: `/${pageId}/videos`, body: { file_url: first.file, description: draft.text, ...(draft.title === undefined ? {} : { title: draft.title }) } }
        default:
            return { refuse: "kind_unsupported" }
    }
}

/** The id the vendor answers a publish with: the post id of a photo, the id of a post or a video. */
export const publishedIdOf = (via: "feed" | "photos" | "videos", json: unknown): string | null => {
    const read = (name: string): string | null => {
        const value = typeof json === "object" && json !== null && !Array.isArray(json) ? (json as Record<string, unknown>)[name] : undefined
        return typeof value === "string" && value !== "" ? value : null
    }
    return via === "photos" ? (read("post_id") ?? read("id")) : read("id")
}
