import { z } from "zod"
import type { JsonObject, Operation, OperationReach, WebhookRegistrationInput } from "@starci/nivoos-sdk"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { succeeded } from "./graph.ts"

/** `url` is the address of the account's door; Meta takes it in the app dashboard, so the call only subscribes the Page (the registration input always carries it). */
export const SubscribeInput = z.strictObject({ url: z.string().min(1) })
export const SubscribeOutput = z.strictObject({ registered: z.literal(true) })

type Refusal = "auth_failed"

/** The Page fields the app is subscribed to: comments and posts (`feed`), Messenger (`messages`, `messaging_referrals`) and Lead Ads (`leadgen`). Instagram fields are set in the app dashboard. */
const FIELDS = ["feed", "messages", "messaging_referrals", "leadgen"] as const

/** `meta.page.subscribe`: `POST /{page}/subscribed_apps` with `subscribed_fields`; answers `{ success: true }`. Needs `pages_manage_metadata`. Source: https://developers.facebook.com/docs/graph-api/reference/page/subscribed_apps/. */
export class MetaPageSubscribe implements Operation<typeof SubscribeInput, typeof SubscribeOutput, JsonObject, Refusal> {
    readonly key = "meta.page.subscribe"
    readonly version = 1
    readonly title = { vi: "Đăng ký nhận sự kiện của Trang", en: "Subscribe the Page to the app" }
    readonly input = SubscribeInput
    readonly output = SubscribeOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT } as const

    run(_input: WebhookRegistrationInput, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SubscribeOutput> {
        const account = reach.account() as { readonly pageId: string }
        const answer = reach.http({ method: "POST", path: `/${account.pageId}/subscribed_apps`, body: { subscribed_fields: [...FIELDS] } })
        return succeeded(answer.json) ? { registered: true } : reach.byStatus()
    }
}
