import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { PostDraft } from "../social/shapes.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { pagePublishPlan, publishedIdOf } from "./page-publish.ts"

/** What Meta takes to hold a post and publish it itself: the post and the instant (ISO 8601). Scheduling is time, so it belongs to the engine (`at` then `social.post.publish`); this stays a Meta-only operation. */
const SocialPostScheduleInput = PostDraft.extend({ at: z.iso.datetime({ offset: true }) })
const SocialPostScheduleOutput = z.strictObject({ scheduledId: z.string().min(1), at: z.string().min(1), native: z.boolean() })

type Refusal = "kind_unsupported" | "media_invalid" | "schedule_window" | "account_restricted" | "auth_failed"

/** The window Meta takes a scheduled post in: from 10 minutes to 30 days after the request (https://developers.facebook.com/docs/pages-api/posts). */
const MIN_SECONDS = 10 * 60
const MAX_SECONDS = 30 * 24 * 60 * 60

/**
 * `meta.page.schedule`: the same edges as `meta.page.post` with `published=false` and `scheduled_publish_time` (Unix seconds), so Meta holds the post and publishes it (`native: true`). An instant outside
 * 10 minutes to 30 days from now is the declared refusal `schedule_window`, with no call. That a photo and a video take the same two fields is not confirmed by the page read (see README).
 */
export class MetaPageSchedule implements Operation<typeof SocialPostScheduleInput, typeof SocialPostScheduleOutput, JsonObject, Refusal> {
    readonly key = "meta.page.schedule"
    readonly version = 1
    readonly title = { vi: "Hẹn giờ đăng lên Trang Facebook", en: "Schedule on the Facebook Page" }
    readonly input = SocialPostScheduleInput
    readonly output = SocialPostScheduleOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["kind_unsupported", "media_invalid", "schedule_window", "account_restricted", "auth_failed"] as const
    readonly external = true
    // Graph has no idempotency header: the engine guards the publish itself (an attempt per intent key, no blind re-send after a lost answer)
    readonly wire = { dedupe: {}, errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "368": "account_restricted" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialPostScheduleInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialPostScheduleOutput> {
        const account = reach.account() as { readonly pageId: string }
        const plan = pagePublishPlan(input, account.pageId)
        if ("refuse" in plan) return reach.refuse(plan.refuse)
        const ahead = (Date.parse(input.at) - Date.parse(reach.now())) / 1000
        if (!(ahead >= MIN_SECONDS && ahead <= MAX_SECONDS)) return reach.refuse("schedule_window")
        const answer = reach.http({ method: "POST", path: plan.path, body: { ...plan.body, published: false, scheduled_publish_time: Math.floor(Date.parse(input.at) / 1000) } })
        const scheduledId = publishedIdOf(plan.via, answer.json)
        if (scheduledId === null) return reach.unknown("schedule_shape")
        return { scheduledId, at: input.at, native: true }
    }
}
