import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialLeadGet, SocialLeadGetInput, SocialLeadGetOutput } from "../social/capabilities/lead-get.capability.ts"
import { member } from "../shared/json.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT_LEADS } from "./wire.ts"

type Refusal = "lead_gone" | "auth_failed"
type Field = z.infer<typeof SocialLeadGetOutput>["fields"][number]

const textOf = (value: unknown): string | undefined => (typeof value === "string" && value !== "" ? value : typeof value === "number" ? String(value) : undefined)

/** The answers of a lead (`field_data: [{ name, values }]`), each with every value it held. */
export const fieldsOf = (data: unknown): Array<Field> => {
    const fields: Array<Field> = []
    for (const entry of Array.isArray(data) ? data : []) {
        const name = member(entry, "name")
        const values = member(entry, "values")
        if (typeof name === "string") fields.push({ name, values: Array.isArray(values) ? values.filter((value): value is string => typeof value === "string") : [] })
    }
    return fields
}

/**
 * `meta.lead.get`: `GET /{leadgen_id}` (`social.lead.get`), the answers of a lead the webhook announced by its id. Needs `leads_retrieval` and the app listed in Leads Access Manager. `campaign_id` is
 * read when the vendor gives it (the documented sample does not show it). Code 100 is a lead that is gone (not confirmed, see README).
 */
export class MetaLeadGet implements Operation<typeof SocialLeadGetInput, typeof SocialLeadGetOutput, JsonObject, Refusal> {
    readonly key = "meta.lead.get"
    readonly version = 1
    readonly title = { vi: "Lấy khách tiềm năng Facebook", en: "Get a Facebook lead" }
    readonly input = SocialLeadGetInput
    readonly output = SocialLeadGetOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly implements = SocialLeadGet
    readonly refusals = ["lead_gone", "auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "100": "lead_gone" }, transientCodes: META_TRANSIENT_LEADS } as const

    run(input: z.infer<typeof SocialLeadGetInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialLeadGetOutput> {
        const answer = reach.http({ method: "GET", path: `/${input.leadId}`, query: { fields: "id,created_time,ad_id,form_id,campaign_id,field_data" } })
        const leadId = textOf(member(answer.json, "id"))
        const formId = textOf(member(answer.json, "form_id"))
        const at = textOf(member(answer.json, "created_time"))
        const adId = textOf(member(answer.json, "ad_id"))
        const campaignId = textOf(member(answer.json, "campaign_id"))
        if (leadId === undefined || formId === undefined || at === undefined) return reach.unknown("lead_shape")
        return { leadId, formId, ...(adId === undefined ? {} : { adId }), ...(campaignId === undefined ? {} : { campaignId }), at, fields: fieldsOf(member(answer.json, "field_data")) }
    }
}
