import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialPostMetricsInput, SocialPostMetricsOutput } from "../social/capabilities/post-metrics.capability.ts"
import { member } from "../shared/json.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"

type Refusal = "auth_failed"
type Item = z.infer<typeof SocialPostMetricsOutput>["items"][number]

const insightOf = (node: unknown, name: string): number | undefined => {
    const data = member(member(node, "insights"), "data")
    const found = Array.isArray(data) ? data.find((entry) => member(entry, "name") === name) : undefined
    const values = member(found, "values")
    const value = Array.isArray(values) ? member(values[0], "value") : undefined
    return typeof value === "number" ? value : undefined
}

/**
 * `meta.ig.metrics`: the numbers of Instagram media in the normalised names, from one call over the ids: `like_count` and `comments_count` as fields, and the insights `views`, `reach`, `saved` (the
 * `saves`) and `shares`. The metric names are from memory (the insights page answered 404 when read), so a media the vendor refuses the set for is listed in `unsupported`. Same shape as the
 * capability; it does not declare `implements` (the Facebook operation holds the capability, see README).
 */
export class MetaIgMetrics implements Operation<typeof SocialPostMetricsInput, typeof SocialPostMetricsOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.metrics"
    readonly version = 1
    readonly title = { vi: "Số liệu bài Instagram", en: "Instagram media metrics" }
    readonly input = SocialPostMetricsInput
    readonly output = SocialPostMetricsOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialPostMetricsInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialPostMetricsOutput> {
        const answer = reach.http({
            method: "GET",
            path: "/",
            query: { ids: input.postIds.join(","), fields: "timestamp,like_count,comments_count,insights.metric(views,reach,saved,shares)" },
        })
        const items: Array<Item> = []
        const unsupported: Array<string> = []
        for (const postId of input.postIds) {
            const node = member(answer.json, postId)
            if (node === undefined) {
                unsupported.push(postId)
                continue
            }
            const at = member(node, "timestamp")
            const likes = member(node, "like_count")
            const comments = member(node, "comments_count")
            const views = insightOf(node, "views")
            const reachCount = insightOf(node, "reach")
            const saves = insightOf(node, "saved")
            const shares = insightOf(node, "shares")
            items.push({
                postId,
                at: typeof at === "string" ? at : reach.now(),
                ...(views === undefined ? {} : { views }),
                ...(reachCount === undefined ? {} : { reach: reachCount }),
                ...(typeof likes === "number" ? { likes } : {}),
                ...(typeof comments === "number" ? { comments } : {}),
                ...(saves === undefined ? {} : { saves }),
                ...(shares === undefined ? {} : { shares }),
            })
        }
        return { items, unsupported }
    }
}
