import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { idOf } from "./graph.ts"

export const MediaPublishInput = z.strictObject({ creationId: z.string().min(1) })
export const MediaPublishOutput = z.strictObject({ postId: z.string().min(1) })

type Refusal = "account_restricted" | "auth_failed"

/**
 * `meta.ig.media.publish`: `POST /{ig}/media_publish` with `creation_id`, the second step of an Instagram post, chained by the engine when the container is `FINISHED`. The 100 posts per rolling
 * 24 hours are enforced here, so the provider's `rate` counts this operation. Meta has no idempotency header: the engine runs this act once per job, and its intent key keeps a retry from doubling it.
 */
export class MetaIgMediaPublish implements Operation<typeof MediaPublishInput, typeof MediaPublishOutput, JsonObject, Refusal> {
    readonly key = "meta.ig.media.publish"
    readonly version = 1
    readonly title = { vi: "Xuất bản bài Instagram", en: "Publish the Instagram post" }
    readonly input = MediaPublishInput
    readonly output = MediaPublishOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken", "igUserId"] as const
    readonly refusals = ["account_restricted", "auth_failed"] as const
    readonly external = true
    // Graph has no idempotency header: the engine guards the publish itself (an attempt per intent key, no blind re-send after a lost answer)
    readonly wire = { dedupe: {}, errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "368": "account_restricted" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof MediaPublishInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof MediaPublishOutput> {
        const account = reach.account() as { readonly igUserId?: string }
        if (account.igUserId === undefined) return reach.refuse("account_restricted")
        const postId = idOf(reach.http({ method: "POST", path: `/${account.igUserId}/media_publish`, body: { creation_id: input.creationId } }).json)
        return postId === null ? reach.unknown("publish_shape") : { postId }
    }
}
