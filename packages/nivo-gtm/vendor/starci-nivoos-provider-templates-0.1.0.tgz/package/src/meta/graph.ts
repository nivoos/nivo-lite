import { member } from "../shared/json.ts"

/** The `id` of a Graph answer, as text; null when there is none. */
export const idOf = (json: unknown): string | null => {
    const id = member(json, "id")
    return typeof id === "string" && id !== "" ? id : typeof id === "number" ? String(id) : null
}

/** The address of a Page post (its id is `<page>_<post>`). */
export const postUrl = (postId: string): string => `https://www.facebook.com/${postId}`

/** Whether a Graph write answered `{ "success": true }`. */
export const succeeded = (json: unknown): boolean => member(json, "success") === true
