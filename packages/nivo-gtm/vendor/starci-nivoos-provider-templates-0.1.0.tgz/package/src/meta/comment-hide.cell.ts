import type { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { SocialCommentHide, SocialCommentHideInput, SocialCommentHideOutput } from "../social/capabilities/comment-hide.capability.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"
import { succeeded } from "./graph.ts"

type Refusal = "comment_gone" | "auth_failed"

/** `meta.comment.hide`: `POST /{comment}` with `is_hidden` (a comment of the Page; the vendor answers `{ success }`). Code 100 or 210 is a comment that is gone (the page confirms neither, see README). */
export class MetaCommentHide implements Operation<typeof SocialCommentHideInput, typeof SocialCommentHideOutput, JsonObject, Refusal> {
    readonly key = "meta.comment.hide"
    readonly version = 1
    readonly title = { vi: "Ẩn bình luận Facebook", en: "Hide a Facebook comment" }
    readonly input = SocialCommentHideInput
    readonly output = SocialCommentHideOutput
    readonly semantics = { mutates: true, outside: true }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly implements = SocialCommentHide
    readonly refusals = ["comment_gone", "auth_failed"] as const
    readonly external = true
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: { ...META_AUTH_CODES, "100": "comment_gone", "210": "comment_gone" }, transientCodes: META_TRANSIENT } as const

    run(input: z.infer<typeof SocialCommentHideInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof SocialCommentHideOutput> {
        const answer = reach.http({ method: "POST", path: `/${input.commentId}`, body: { is_hidden: input.hidden } })
        return succeeded(answer.json) ? { hidden: input.hidden } : reach.unknown("hide_shape")
    }
}
