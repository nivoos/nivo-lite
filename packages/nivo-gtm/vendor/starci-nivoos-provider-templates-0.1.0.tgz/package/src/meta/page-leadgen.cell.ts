import type { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SocialLeadReceived, SocialLeadReceivedData } from "../social/events/lead-received.event.ts"
import { MetaLead } from "./rows.ts"
import { leadEventOf } from "./events.ts"

/**
 * `meta.page.leadgen`: a Lead Ads lead (the `leadgen` field) as the family event `social.lead.received`. The webhook carries ids only, so the event does too; the answers are read with `meta.lead.get`.
 * The lead id is the key, so the webhook and the poll fallback (`meta.leads.poll`) give one event for one lead.
 */
export class MetaPageLeadgen implements Trigger<typeof MetaLead, typeof SocialLeadReceivedData> {
    readonly key = "meta.page.leadgen"
    readonly version = 1
    readonly title = { vi: "Có khách tiềm năng mới từ quảng cáo", en: "Lead Ads lead received" }
    readonly row = MetaLead
    readonly event = SocialLeadReceivedData
    readonly provider = "meta"
    readonly dataType = { providerVersion: 1, key: "meta.lead" }
    readonly keyMember = "leadId"
    readonly subjectKind = "social-lead"
    readonly subjectMember = "leadId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook", "poll"] as const
    readonly family = SocialLeadReceived

    translate(row: z.infer<typeof MetaLead>, _reach: TriggerReach): TriggerEvent<z.infer<typeof SocialLeadReceivedData>> | null {
        return leadEventOf(row)
    }
}
