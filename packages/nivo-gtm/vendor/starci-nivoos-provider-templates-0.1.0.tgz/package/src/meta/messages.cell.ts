import type { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SocialMessageReceived, SocialMessageReceivedData } from "../social/events/message-received.event.ts"
import { MetaMessage } from "./rows.ts"
import { messageEventOf } from "./events.ts"

/**
 * `meta.messages`: a Messenger message to the Page, or an entry through an `m.me` link or an ad (the `messages` and `messaging_referrals` fields), as the family event `social.message.received`. It is a
 * customer line (the person is a contact of the account), and `ref` is the code of the link (`refMember`), so the engine writes a touch from it. The Page's own messages (echoes) are never kept.
 */
export class MetaMessages implements Trigger<typeof MetaMessage, typeof SocialMessageReceivedData> {
    readonly key = "meta.messages"
    readonly version = 1
    readonly title = { vi: "Có tin nhắn Messenger mới", en: "Messenger message received" }
    readonly row = MetaMessage
    readonly event = SocialMessageReceivedData
    readonly provider = "meta"
    readonly dataType = { providerVersion: 1, key: "meta.message" }
    readonly keyMember = "messageId"
    readonly subjectKind = "contact"
    readonly subjectMember = "senderId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    readonly line = { identity: "channel", contactMember: "senderId", textMember: "text" } as const
    readonly refMember = "ref"
    readonly family = SocialMessageReceived

    translate(row: z.infer<typeof MetaMessage>, _reach: TriggerReach): TriggerEvent<z.infer<typeof SocialMessageReceivedData>> | null {
        return messageEventOf(row, "messenger")
    }
}
