# meta (Facebook Page, Messenger, Instagram, Lead Ads)

Provider key `meta`. One account is one Facebook Page and its linked Instagram professional account. Graph API base `https://graph.facebook.com/v27.0` (the version the pages below show), credential: the account Page token as `Authorization: Bearer` (the pages read show the `access_token` parameter; the bearer header is from memory, so it is not confirmed, and a change to `scheme: "query"` with `name: "access_token"` is one line). Logo: neutral monogram (the brand terms of Meta were not fetched).

Design: spec B (social distribution) sections 2.1, 2.2, 6, 7 and 10, and DECISIONS "Meta: two connection modes". Both modes use this one provider and differ only in the account's fields; the engine needs no change.

## Connection modes

| Mode | Status | How |
| --- | --- | --- |
| 2. The customer's own Meta app | built, the default | `authWays: fields`. Public `appId`, `pageId` (identity), `igUserId` (optional). Secrets `appSecret` (webhook proof), `pageToken`, `verifyToken` (generated, 32 bytes hex). The webhook is the per-account door on the customer's instance. The customer is admin of the app and the Page, so Standard Access works with no App Review. |
| 1. The shared NIVO app | declared, guarded off | A second `authWays` entry `oauth2` whose client id and secret env names are declared in `meta.provider.cell.ts`. The engine finds no client when those env values are unset, so the way stays unusable. Not built: it needs B S-E1(b) (app-scoped webhook routing) and S-E8 (many accounts per sign-in), both "later" (owner question O1), and NIVO's Business Verification and App Review. **TODO** when those land: the user token must be exchanged for a Page token per Page, and the webhook becomes app-scoped. |

Because the oauth2 way fills `pageToken` and `refreshToken`, the engine requires both to be optional members of `fields`; every operation therefore lists `pageToken` in `needs`, and the connect form of mode 2 asks for it.

"Require App Secret" stays OFF in the app settings (B section 7): the engine cannot compute `appsecret_proof` (an HMAC of the token keyed by the secret) without a new primitive.

## Cells

| Cell | Key | What |
| --- | --- | --- |
| `meta.provider.cell.ts` (rows and receive logic in `rows.ts`, wire facts in `wire.ts`) | `meta` | fields, `challenge`, `prove` (X-Hub-Signature-256), `receive` (batched, up to 1000 changes), poll way for leads |
| `me.cell.ts` | `meta.me` | `GET /{page}?fields=id,name`, the connect test |
| `page-subscribe.cell.ts` | `meta.page.subscribe` | `POST /{page}/subscribed_apps`, the webhook registration |
| `page-post.cell.ts` | `meta.page.post` | implements `social.post.publish` (feed, photos, videos) |
| `page-schedule.cell.ts` | `meta.page.schedule` | Meta-only, no `implements` (`published=false` + `scheduled_publish_time`); scheduling is time, so the engine's `at` then `social.post.publish` is the way for a workflow |
| `ig-publish.cell.ts`, `ig-container-status.cell.ts`, `ig-media-publish.cell.ts` | `meta.ig.publish`, `meta.ig.container.status`, `meta.ig.media.publish` | container, then `media_publish`; the engine follows `status_code` through the declared job and chains the publish (`job.then`, input path `job.result.id`: the path convention is not confirmed against gm-jobs) |
| `post-metrics.cell.ts` | `meta.post.metrics` | implements `social.post.metrics` (Facebook posts) |
| `ig-metrics.cell.ts` | `meta.ig.metrics` | Instagram media metrics (same output as the capability) |
| `comment-reply.cell.ts` | `meta.comment.reply` | implements `social.comment.reply`, public or private |
| `comment-hide.cell.ts` | `meta.comment.hide` | implements `social.comment.hide` |
| `ig-comment-reply.cell.ts`, `ig-comment-hide.cell.ts` | `meta.ig.comment.reply`, `meta.ig.comment.hide` | Instagram comments |
| `lead-get.cell.ts` | `meta.lead.get` | implements `social.lead.get` (`GET /{leadgen_id}`) |
| `leads-poll.cell.ts` | `meta.leads.poll` | the Lead Ads fallback: `GET /{page}/leadgen_forms`, then `GET /{form}/leads` |
| `page-comment.cell.ts` | `meta.page.comment` | trigger, family `social.comment.received` |
| `messages.cell.ts` | `meta.messages` | trigger, family `social.message.received`, a customer line, `refMember: ref` |
| `page-leadgen.cell.ts` | `meta.page.leadgen` | trigger, family `social.lead.received` |
| `ig-comment.cell.ts`, `ig-messages.cell.ts` | `meta.ig.comment`, `meta.ig.messages` | Instagram triggers, the same families |

Capability binding: `social.post.publish` is a fan-out capability: a call names `targets`, each an account id or `{ account, channel }`. For the one Meta account, a target with no channel reaches the Facebook Page (`meta.page.post`), and `{ channel: "instagram" }` reaches `meta.ig.publish`, which declares that channel. The other Instagram operations (`meta.ig.*` comments, metrics) are callable by key.

The public and the private reply are ONE operation (`meta.comment.reply`, the capability's `private` flag picks the path), because only one operation of a provider can implement a capability.

## Webhook

- GET handshake: `hub.mode=subscribe`, `hub.verify_token` (compared with the account's `verifyToken`), echo `hub.challenge`. Source: https://developers.facebook.com/docs/graph-api/webhooks/getting-started (read 2026-11-18). Declared as `webhook.challenge`; the door answers it.
- Every POST carries `X-Hub-Signature-256: sha256=<HMAC-SHA256(body, appSecret)>`. `prove` strips `sha256=` and uses `hmacEquals` with the secret field `appSecret`.
- Meta retries immediately, then for 36 hours with decreasing frequency, so duplicates are expected: every row has a deterministic key. Updates come in batches of up to 1000 (batching is not guaranteed). Answer `200` to every notification. Same page.
- Registration: `meta.page.subscribe` sends `subscribed_fields` (`feed`, `messages`, `messaging_referrals`, `leadgen`). The response is `{ "success": true }`. It needs `pages_manage_metadata` and `pages_show_list` and a Page token of a person with CREATE_CONTENT, MANAGE or MODERATE. `subscribed_fields` cannot subscribe to Instagram: Instagram `comments` and `messages` are set in the app dashboard. Source: https://developers.facebook.com/docs/graph-api/reference/page/subscribed_apps/ (read 2026-11-18).
- Page field list (`feed`, `messages`, `messaging_referrals`, `leadgen`; no webhooks for Ad Posts but for comments on them; the app must be Live): https://developers.facebook.com/docs/graph-api/webhooks/reference/page.

## Facts and where they come from (read 2026-11-18)

- Publishing to a Page: `POST /{page}/feed` with `message`, `link`, `published`, `scheduled_publish_time` (Unix seconds, ISO 8601, or `strtotime`); the date must be between 10 minutes and 30 days from the request; answer `{ "id": "<page_post_id>" }`. `POST /{page}/photos` with `url`; the answer has an `id` and a `post_id`. Source: https://developers.facebook.com/docs/pages-api/posts.
- Instagram: `POST /{ig}/media` with `image_url` or `video_url` (a public address Meta fetches), `media_type` `REELS` / `STORIES` / `CAROUSEL`, carousel `children` up to 20 containers, `is_carousel_item`; the answer is the container id. `POST /{ig}/media_publish` with `creation_id`. `GET /{container}?fields=status_code`: `EXPIRED`, `ERROR`, `FINISHED`, `PUBLISHED`. 100 API posts per rolling 24 hours, a carousel counts as one, enforced at `media_publish`. Source: https://developers.facebook.com/docs/instagram-platform/content-publishing.
- Throttle codes: 4 (app), 17 (user), 32 (Page API), 613 (custom), and Business Use Case codes 80001 (Pages), 80002 (Instagram), 80005 (Lead Ads), 80006 (Messenger). `X-Business-Use-Case-Usage` is a JSON object keyed by business id, each with `estimated_time_to_regain_access` in minutes. Source: https://developers.facebook.com/docs/graph-api/overview/rate-limiting.
- Comments: `POST /{comment}` with `is_hidden` answers `{ "success": bool }` (Page comments only); a new comment answers `{ "id" }`. Error codes listed: 100, 190, 200, 210, 368, 459, 80001. Source: https://developers.facebook.com/docs/graph-api/reference/comment.
- Private reply: `POST /{page}/messages` with `recipient` naming the comment, within 7 days, one message per comment. Needs `pages_messaging`. Source: https://developers.facebook.com/docs/messenger-platform/discovery/private-replies.
- Instagram comment: `POST /{ig-comment}/replies` with `message`, answer `{ "id" }`. Advanced Access is needed for accounts you do not own. Source: https://developers.facebook.com/docs/instagram-platform/comment-moderation.
- Leads: the leadgen webhook is `object: "page"`, `entry[].changes[]` with `field: "leadgen"` and `value` holding `leadgen_id`, `page_id`, `form_id`, `adgroup_id`, `ad_id`, `created_time`. `GET /{leadgen_id}` answers `id`, `created_time`, `ad_id`, `form_id`, `field_data: [{ name, values }]`. `GET /{form}/leads` answers `data` and `paging.cursors`. Source: https://developers.facebook.com/docs/marketing-api/guides/lead-ads/retrieving.
- Messenger webhook: `entry[].messaging[]` with `sender.id`, `recipient.id`, `timestamp`, `message.mid`, `message.text`, `message.attachments`. Source: https://developers.facebook.com/docs/messenger-platform/webhooks.
- Facebook post insights: `post_impressions` was deprecated on 2025-11-15 and `post_media_view` replaces it. Source: https://developers.facebook.com/documentation/pages-api/platforminsights/page/deprecated-metrics.

## Not confirmed (said, not guessed)

Every item here is built from memory or a secondary source. None was exercised against Meta (this lane had no credential), and the recorded exchanges are built from the documented shapes and marked so.

- The `feed` webhook comment payload (`value.item = "comment"`, `verb`, `comment_id`, `post_id`, `parent_id`, `from.id`, `from.name`, `message`, `created_time`): the Page reference lists field names only.
- The Instagram `comments` and `messages` payload shapes (`changes[].value.id`, `.text`, `.from.id`, `.from.username`, `.media.id`) and the units of `entry.time`: the pages read do not show them.
- The `messaging_referrals` / `referral` shape (`ref`, `source`, `type`, `ad_id`) and `message.is_echo`: not on the pages read.
- The Reels path `/{page}/video_reels` (a start, upload and finish sequence): not read; a `reel` is refused `kind_unsupported` for now.
- The Facebook `/{page}/videos` parameters (`file_url`, `description`): not read.
- Which error code means "private reply window closed" (believed 10 with subcode 2018278), "comment gone" (100 or 210; the page confirms neither) and "Page post limit": codes are mapped from memory.
- The Instagram hide parameter (`hide=true`) and its answer: the page shows the endpoint, not the parameter.
- Post-level Facebook insight metrics other than `post_media_view`, and the Instagram `/{media}/insights` metric names (`views`, `reach`, `likes`, `comments`, `saved`, `shares`); that page answered 404.
- `campaign_id` on a lead: not in the documented sample.
- The Instagram publishing limit: 100 per 24 hours on one passage, 50 for carousels on another (conflict in the vendor's own page); the rate rule uses 100.
- The retry-after of a throttle is in the response HEADER `X-Business-Use-Case-Usage` (a JSON value in minutes), which the engine cannot read as a plain seconds header (`retryAfterHeader` reads a header holding seconds), so a flat `retryAfterSeconds` is declared.
- Instagram `comments` webhooks for accounts that are not yours need Advanced Access (secondary sources).

## Owner setup steps (also the provider's `setup` guide)

1. Create a Business portfolio. Business Verification runs on its own clock and is needed for mode 1.
2. developers.facebook.com: create an app with the use case "Manage everything on your Page"; add Webhooks, Messenger, Instagram and Lead Ads.
3. Set the privacy policy URL to `<web origin>/privacy`, the data deletion instructions URL to `<web origin>/data-deletion`, and the data deletion callback URL (App settings, Advanced) to the account address plus `/deletion` (`<api origin>/webhooks/<accountId>/deletion`; the engine proves the signed request with the sealed `appSecret` and answers `{ url, confirmation_code }`, the url being `<web origin>/data-deletion/status?code=...`), then switch the app to **Live**: Development mode receives no real webhooks.
4. Give the Page admin a role on the app. Generate a long-lived Page token or a System User token with the Page assigned. Paste it with the app id, the Page id and the app secret. NIVO generates the verify token.
5. Webhooks: paste the account's address and the verify token. Subscribe Page `feed`, `messages`, `messaging_referrals`, `leadgen` and Instagram `comments`, `messages`. NIVO then calls `subscribed_apps`.
6. Lead Ads: in Leads Access Manager, give the app (a CRM) access.

## Gaps for the coordinator

- The hosted pages now exist (`/privacy`, `/data-deletion`, `/data-deletion/status`) and so does the callback. The setup guide text in `meta.provider.cell.ts` still says "no address yet"; rewording it means rebuilding the seed and a new provider version, left for a provider lane.
- The event `accountId` is the Page id in the vendor trigger's own event; when the engine writes the family event it replaces it with the NIVO account id (provider admission), so a family consumer never sees a vendor id.
- `contact` is not declared on the comment trigger: the declaration needs a top-level text member of the event, but the family's comment event holds the author in a nested object.
- The `media[].file` of a post is a drive path; the `Media` item is marked as a file member (`nivoos:file`), so the engine signs it into an address before the operation sends it as a `url`.
- Graph has no idempotency header, so `wire.idempotency` is not declared. The publish operations declare `wire.dedupe`: the engine records an attempt per intent key and refuses a blind re-send after a lost answer (a held attempt stops the run until a person releases it; a lookup operation can be declared later to reconcile on its own).
- The recorded exchanges (`be/src/tests/fixtures/e2e/providers/meta/exchanges.ts`) are built from the documented shapes, not recorded with a key.
