/** The wire facts every operation of the Meta provider shares (data only; the engine applies them). Source: https://developers.facebook.com/docs/graph-api/overview/rate-limiting (codes), https://developers.facebook.com/docs/graph-api/reference/comment (error codes). */

/** The Graph API error envelope is `{ "error": { "message", "type", "code", "error_subcode", "fbtrace_id" } }`: the vendor code is read from here. */
export const META_ERROR_FIELD = "error.code"

/**
 * The throttling codes (4 app, 17 user, 32 Page API, 613 custom, 80001 Pages, 80002 Instagram, 80006 Messenger), answered as HTTP 400. The wait the vendor gives is in the HEADER
 * `X-Business-Use-Case-Usage` (`estimated_time_to_regain_access`, minutes), which `retryAfterPath` (a path of the body) cannot read: a flat wait stands in until the engine reads the header.
 */
export const META_TRANSIENT = {
    "4": { retryAfterSeconds: 300 },
    "17": { retryAfterSeconds: 300 },
    "32": { retryAfterSeconds: 300 },
    "613": { retryAfterSeconds: 300 },
    "80001": { retryAfterSeconds: 300 },
    "80002": { retryAfterSeconds: 300 },
    "80006": { retryAfterSeconds: 300 },
} as const

/** The Lead Ads throttle (Business Use Case 80005) joins the list on the lead operations. */
export const META_TRANSIENT_LEADS = { ...META_TRANSIENT, "80005": { retryAfterSeconds: 300 } } as const

/** 190 an invalid or expired token, 102 an invalid session, 200 a permission missing (the codes the pages above list). */
export const META_AUTH_CODES = { "190": "auth_failed", "102": "auth_failed", "200": "auth_failed" } as const
