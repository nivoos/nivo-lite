import type { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SocialCommentReceived, SocialCommentReceivedData } from "../social/events/comment-received.event.ts"
import { MetaComment } from "./rows.ts"
import { commentEventOf } from "./events.ts"

/**
 * `meta.page.comment`: a comment under a post of the Facebook Page (the `feed` field, item `comment`; an add, an edit or a removal), as the family event `social.comment.received`. `isOwn` is true when the
 * author is the Page itself. The subject is `social-thread:<rootId>`. `contact` is NOT declared: it needs a top-level text member of the event, and the family holds the author in a nested object (see README).
 */
export class MetaPageComment implements Trigger<typeof MetaComment, typeof SocialCommentReceivedData> {
    readonly key = "meta.page.comment"
    readonly version = 1
    readonly title = { vi: "Có bình luận mới trên Trang Facebook", en: "Facebook Page comment received" }
    readonly row = MetaComment
    readonly event = SocialCommentReceivedData
    readonly provider = "meta"
    readonly dataType = { providerVersion: 1, key: "meta.comment" }
    readonly keyMember = "eventKey"
    readonly subjectKind = "social-thread"
    readonly subjectMember = "rootId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    readonly family = SocialCommentReceived

    translate(row: z.infer<typeof MetaComment>, _reach: TriggerReach): TriggerEvent<z.infer<typeof SocialCommentReceivedData>> | null {
        return commentEventOf(row, "facebook")
    }
}
