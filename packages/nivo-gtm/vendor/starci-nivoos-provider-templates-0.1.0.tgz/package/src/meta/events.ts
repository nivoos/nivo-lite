import type { z } from "zod"
import type { TriggerEvent } from "@starci/nivoos-sdk"
import type { SocialCommentReceivedData } from "../social/events/comment-received.event.ts"
import type { SocialMessageReceivedData } from "../social/events/message-received.event.ts"
import type { SocialLeadReceivedData } from "../social/events/lead-received.event.ts"
import type { MetaComment, MetaLead, MetaMessage } from "./rows.ts"

type Comment = z.infer<typeof MetaComment>
type Message = z.infer<typeof MetaMessage>
type Lead = z.infer<typeof MetaLead>

/** The family event of a kept comment, keyed `<accountId>:<commentId>:<verb>`; null when the row is of the other channel. `accountId` is the id of the Page (or Instagram account) here; the engine replaces it with the NIVO account id when it writes the family event, so no package sees a vendor id there. */
export const commentEventOf = (row: Comment, channel: Comment["channel"]): TriggerEvent<z.infer<typeof SocialCommentReceivedData>> | null =>
    row.channel !== channel
        ? null
        : {
              id: `${row.accountId}:${row.commentId}:${row.verb}`,
              data: {
                  provider: "meta",
                  accountId: row.accountId,
                  verb: row.verb,
                  commentId: row.commentId,
                  postId: row.postId,
                  ...(row.parentId === undefined ? {} : { parentId: row.parentId }),
                  rootId: row.rootId,
                  author: { id: row.authorId, ...(row.authorName === undefined ? {} : { name: row.authorName }), ...(row.authorHandle === undefined ? {} : { handle: row.authorHandle }) },
                  isOwn: row.isOwn,
                  text: row.text,
                  sentAt: row.sentAt,
              },
          }

/** The family event of a kept message, keyed `<accountId>:<messageId>`; null when the row is of the other channel. */
export const messageEventOf = (row: Message, channel: Message["channel"]): TriggerEvent<z.infer<typeof SocialMessageReceivedData>> | null =>
    row.channel !== channel
        ? null
        : {
              id: `${row.accountId}:${row.messageId}`,
              data: {
                  provider: "meta",
                  accountId: row.accountId,
                  messageId: row.messageId,
                  senderId: row.senderId,
                  text: row.text,
                  ...(row.ref === undefined ? {} : { ref: row.ref }),
                  ...(row.adId === undefined ? {} : { adId: row.adId }),
                  sentAt: row.sentAt,
              },
          }

/** The family event of a kept lead, keyed `<accountId>:<leadId>`. */
export const leadEventOf = (row: Lead): TriggerEvent<z.infer<typeof SocialLeadReceivedData>> => ({
    id: `${row.accountId}:${row.leadId}`,
    data: { provider: "meta", accountId: row.accountId, leadId: row.leadId, formId: row.formId, ...(row.adId === undefined ? {} : { adId: row.adId }), sentAt: row.sentAt },
})
