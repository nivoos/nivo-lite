import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { member } from "../shared/json.ts"
import { MetaLead } from "./rows.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT_LEADS } from "./wire.ts"

export const LeadsPollInput = z.strictObject({ from: z.string(), to: z.string(), limit: z.number().int().min(1).max(100) })
export const LeadsPollOutput = z.strictObject({
    items: z.array(z.strictObject({ key: z.string().min(1), value: MetaLead, at: z.string() })),
    fetched: z.number().int().min(0),
    oldestAt: z.string().optional(),
})

type Refusal = "auth_failed"
type Item = z.infer<typeof LeadsPollOutput>["items"][number]

/** The most forms read in one pass: the form list plus one read of leads per form stays inside the 10 calls one run may make. */
const FORMS_MAX = 8

/**
 * `meta.leads.poll`: the fallback for the `leadgen` webhook (a delivery lost, or the app not yet subscribed). It lists the Page's lead forms (`GET /{page}/leadgen_forms`), then reads the leads of each
 * since `from` (`GET /{form}/leads` with a `time_created` filter, the filter syntax is from memory, see README) and answers the leads in the engine's poll shape, oldest first, under the lead id (the key the
 * webhook uses, so a lead seen both ways is one row). Needs `leads_retrieval` and `pages_manage_ads`.
 */
export class MetaLeadsPoll implements Operation<typeof LeadsPollInput, typeof LeadsPollOutput, JsonObject, Refusal> {
    readonly key = "meta.leads.poll"
    readonly version = 1
    readonly title = { vi: "Nhận khách tiềm năng mới", en: "Poll for new leads" }
    readonly input = LeadsPollInput
    readonly output = LeadsPollOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT_LEADS } as const

    run(input: z.infer<typeof LeadsPollInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof LeadsPollOutput> {
        const account = reach.account() as { readonly pageId: string }
        const since = Math.floor(Date.parse(input.from) / 1000)
        const until = Date.parse(input.to)
        const forms = member(reach.http({ method: "GET", path: `/${account.pageId}/leadgen_forms`, query: { fields: "id", limit: FORMS_MAX } }).json, "data")
        const items: Array<Item> = []
        for (const form of (Array.isArray(forms) ? forms : []).slice(0, FORMS_MAX)) {
            const formId = member(form, "id")
            if (typeof formId !== "string") continue
            const leads = member(
                reach.http({
                    method: "GET",
                    path: `/${formId}/leads`,
                    query: { fields: "id,created_time,ad_id,form_id", limit: input.limit, filtering: JSON.stringify([{ field: "time_created", operator: "GREATER_THAN", value: since }]) },
                }).json,
                "data",
            )
            for (const lead of Array.isArray(leads) ? leads : []) {
                const leadId = member(lead, "id")
                const created = member(lead, "created_time")
                const adId = member(lead, "ad_id")
                if (typeof leadId !== "string" || typeof created !== "string" || !(Date.parse(created) <= until)) continue
                items.push({ key: leadId, at: created, value: { leadId, formId, ...(typeof adId === "string" && adId !== "" ? { adId } : {}), accountId: account.pageId, sentAt: created } })
            }
        }
        const ordered = items.sort((left, right) => Date.parse(left.at) - Date.parse(right.at)).slice(0, input.limit)
        const oldest = ordered[0]?.at
        return { items: ordered, fetched: ordered.length, ...(oldest === undefined ? {} : { oldestAt: oldest }) }
    }
}
