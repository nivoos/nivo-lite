import type { z } from "zod"
import type { Trigger, TriggerEvent, TriggerReach } from "@starci/nivoos-sdk"
import { SocialCommentReceived, SocialCommentReceivedData } from "../social/events/comment-received.event.ts"
import { MetaComment } from "./rows.ts"
import { commentEventOf } from "./events.ts"

/**
 * `meta.ig.comment`: a comment under a media of the linked Instagram account (the `comments` field, set in the app dashboard; Live mode, and Advanced Access for an account the app does not own), as the
 * family event `social.comment.received`. The webhook reports new comments only, so the verb is always `add`. Payload shape from memory (see README).
 */
export class MetaIgComment implements Trigger<typeof MetaComment, typeof SocialCommentReceivedData> {
    readonly key = "meta.ig.comment"
    readonly version = 1
    readonly title = { vi: "Có bình luận mới trên Instagram", en: "Instagram comment received" }
    readonly row = MetaComment
    readonly event = SocialCommentReceivedData
    readonly provider = "meta"
    readonly dataType = { providerVersion: 1, key: "meta.comment" }
    readonly keyMember = "eventKey"
    readonly subjectKind = "social-thread"
    readonly subjectMember = "rootId"
    readonly switchOnByDefault = true
    readonly vias = ["webhook"] as const
    readonly family = SocialCommentReceived

    translate(row: z.infer<typeof MetaComment>, _reach: TriggerReach): TriggerEvent<z.infer<typeof SocialCommentReceivedData>> | null {
        return commentEventOf(row, "instagram")
    }
}
