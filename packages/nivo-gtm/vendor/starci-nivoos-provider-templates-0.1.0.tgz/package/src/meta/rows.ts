import { z } from "zod"
import type { DataTypes, ReceivedRowOf } from "@starci/nivoos-sdk"
import { isObject, member } from "../shared/json.ts"

/**
 * A kept comment under a post of the Page (`facebook`, the `feed` field) or of its Instagram account (`instagram`, the `comments` field). `accountId` is the id of the Page (or of the Instagram
 * account) the comment is under. `eventKey` is `<commentId>:<verb>`, so an edit and a removal of the same comment are rows of their own and a re-delivery is one row.
 */
export const MetaComment = z.strictObject({
    eventKey: z.string().min(1),
    channel: z.enum(["facebook", "instagram"]),
    accountId: z.string().min(1),
    commentId: z.string().min(1),
    postId: z.string().min(1),
    parentId: z.string().min(1).optional(),
    rootId: z.string().min(1),
    verb: z.enum(["add", "edit", "remove"]),
    authorId: z.string().min(1),
    authorName: z.string().optional(),
    authorHandle: z.string().optional(),
    isOwn: z.boolean(),
    text: z.string(),
    sentAt: z.string().min(1),
})

/** A kept direct message (Messenger, or Instagram messaging) or an entry through a link (`ref`): the message id is the key; an entry with no message is kept under a key made of the sender and the time. */
export const MetaMessage = z.strictObject({
    messageId: z.string().min(1),
    channel: z.enum(["messenger", "instagram"]),
    accountId: z.string().min(1),
    senderId: z.string().min(1),
    text: z.string(),
    ref: z.string().min(1).optional(),
    adId: z.string().min(1).optional(),
    sentAt: z.string().min(1),
})

/** A kept Lead Ads lead, by the id only: the answers are read with `meta.lead.get`. */
export const MetaLead = z.strictObject({
    leadId: z.string().min(1),
    formId: z.string().min(1),
    adId: z.string().min(1).optional(),
    accountId: z.string().min(1),
    sentAt: z.string().min(1),
})

export const MetaData = {
    "meta.comment": { value: MetaComment, keyMembers: ["eventKey"], occurredAtMember: "sentAt" },
    "meta.message": { value: MetaMessage, keyMembers: ["messageId"], occurredAtMember: "sentAt" },
    "meta.lead": { value: MetaLead, keyMembers: ["leadId"], occurredAtMember: "sentAt" },
} as const satisfies DataTypes

export type MetaRow = ReceivedRowOf<typeof MetaData>

/** The public fields of the account the delivery is for. */
export interface MetaAccountFacts {
    readonly pageId: string
    readonly igUserId?: string | undefined
}

const textOf = (value: unknown): string | undefined => (typeof value === "string" && value !== "" ? value : typeof value === "number" && Number.isFinite(value) ? String(value) : undefined)

/** An instant from a count of seconds or milliseconds; null for anything that is not a date. */
const instantOf = (value: unknown, milliseconds: boolean): string | null => {
    if (typeof value !== "number" || !Number.isFinite(value)) return null
    const at = milliseconds ? value : value * 1000
    return Math.abs(at) < 8.64e12 ? new Date(at).toISOString() : null
}

const VERBS: Readonly<Record<string, "add" | "edit" | "remove">> = { add: "add", edit: "edit", edited: "edit", remove: "remove" }

/** The row of a Facebook `feed` change that is a comment (an add, an edit or a removal); null for a post, a share, a like or a hide. */
const facebookComment = (change: unknown, account: MetaAccountFacts, now: string): MetaRow | null => {
    const value = member(change, "value")
    if (member(change, "field") !== "feed" || member(value, "item") !== "comment") return null
    const verb = VERBS[textOf(member(value, "verb")) ?? ""]
    const commentId = textOf(member(value, "comment_id"))
    const postId = textOf(member(value, "post_id"))
    if (verb === undefined || commentId === undefined || postId === undefined) return null
    const from = member(value, "from")
    const parentId = textOf(member(value, "parent_id"))
    const authorId = textOf(member(from, "id")) ?? "unknown"
    const name = textOf(member(from, "name"))
    const message = member(value, "message")
    return {
        type: "meta.comment",
        key: `${commentId}:${verb}`,
        value: {
            eventKey: `${commentId}:${verb}`,
            channel: "facebook",
            accountId: account.pageId,
            commentId,
            postId,
            ...(parentId === undefined || parentId === postId ? {} : { parentId }),
            rootId: parentId === undefined || parentId === postId ? commentId : parentId,
            verb,
            authorId,
            ...(name === undefined ? {} : { authorName: name }),
            isOwn: authorId === account.pageId,
            text: typeof message === "string" ? message : "",
            sentAt: instantOf(member(value, "created_time"), false) ?? now,
        },
    }
}

/** The row of an Instagram `comments` change (the webhook reports new comments only). */
const instagramComment = (change: unknown, account: MetaAccountFacts, entryId: string | undefined, entryTime: unknown, now: string): MetaRow | null => {
    const value = member(change, "value")
    if (member(change, "field") !== "comments") return null
    const commentId = textOf(member(value, "id"))
    const postId = textOf(member(member(value, "media"), "id"))
    if (commentId === undefined || postId === undefined) return null
    const from = member(value, "from")
    const parentId = textOf(member(value, "parent_id"))
    const authorId = textOf(member(from, "id")) ?? "unknown"
    const handle = textOf(member(from, "username"))
    const text = member(value, "text")
    const accountId = account.igUserId ?? entryId ?? account.pageId
    return {
        type: "meta.comment",
        key: `${commentId}:add`,
        value: {
            eventKey: `${commentId}:add`,
            channel: "instagram",
            accountId,
            commentId,
            postId,
            ...(parentId === undefined ? {} : { parentId }),
            rootId: parentId ?? commentId,
            verb: "add",
            authorId,
            ...(handle === undefined ? {} : { authorHandle: handle }),
            isOwn: authorId === accountId,
            text: typeof text === "string" ? text : "",
            sentAt: instantOf(entryTime, false) ?? now,
        },
    }
}

/** The row of a Page `leadgen` change: the lead's id and its form, never its answers. */
const leadRow = (change: unknown, account: MetaAccountFacts, now: string): MetaRow | null => {
    const value = member(change, "value")
    if (member(change, "field") !== "leadgen") return null
    const leadId = textOf(member(value, "leadgen_id"))
    const formId = textOf(member(value, "form_id"))
    if (leadId === undefined || formId === undefined) return null
    const adId = textOf(member(value, "ad_id"))
    return {
        type: "meta.lead",
        key: leadId,
        value: { leadId, formId, ...(adId === undefined ? {} : { adId }), accountId: account.pageId, sentAt: instantOf(member(value, "created_time"), false) ?? now },
    }
}

/** The row of one `messaging` item: a message (an echo of the Page's own message is skipped), or an entry through a link carrying a `ref`; null for a read, a delivery, a reaction or an item with neither. */
const messageRow = (item: unknown, account: MetaAccountFacts, instagram: boolean, entryId: string | undefined, now: string): MetaRow | null => {
    const senderId = textOf(member(member(item, "sender"), "id"))
    if (senderId === undefined) return null
    const message = member(item, "message")
    if (isObject(message) && message["is_echo"] === true) return null
    const timestamp = member(item, "timestamp")
    const referral = member(item, "referral") ?? member(message, "referral") ?? member(member(item, "postback"), "referral")
    const ref = textOf(member(referral, "ref"))
    const adId = textOf(member(referral, "ad_id"))
    const mid = textOf(member(message, "mid"))
    if (mid === undefined && ref === undefined) return null
    const messageId = mid ?? `ref:${senderId}:${typeof timestamp === "number" ? String(timestamp) : "0"}`
    const words = member(message, "text")
    return {
        type: "meta.message",
        key: messageId,
        value: {
            messageId,
            channel: instagram ? "instagram" : "messenger",
            accountId: instagram ? (account.igUserId ?? entryId ?? account.pageId) : account.pageId,
            senderId,
            text: typeof words === "string" ? words : "",
            ...(ref === undefined ? {} : { ref }),
            ...(adId === undefined ? {} : { adId }),
            sentAt: instantOf(timestamp, true) ?? now,
        },
    }
}

/**
 * The rows of one delivery. A delivery is `{ object: "page" | "instagram", entry: [{ id, time, changes: [...], messaging: [...] }] }` and carries up to 1000 changes: every comment, lead and message in it
 * is a row of its own, and anything else (a like, a share, a read receipt) is left out. The shapes are the ones the vendor's pages describe and, where they do not, the ones its examples show (see README).
 */
export const rowsOfDelivery = (body: unknown, account: MetaAccountFacts, now: string): ReadonlyArray<MetaRow> | null => {
    if (!isObject(body)) return null
    const object = body["object"]
    const entries = body["entry"]
    if ((object !== "page" && object !== "instagram") || !Array.isArray(entries)) return null
    const rows: Array<MetaRow> = []
    for (const entry of entries) {
        const entryId = textOf(member(entry, "id"))
        const changes = member(entry, "changes")
        for (const change of Array.isArray(changes) ? changes : []) {
            const row = object === "page" ? (facebookComment(change, account, now) ?? leadRow(change, account, now)) : instagramComment(change, account, entryId, member(entry, "time"), now)
            if (row !== null) rows.push(row)
        }
        const messaging = member(entry, "messaging")
        for (const item of Array.isArray(messaging) ? messaging : []) {
            const row = messageRow(item, account, object === "instagram", entryId, now)
            if (row !== null) rows.push(row)
        }
    }
    return rows
}
