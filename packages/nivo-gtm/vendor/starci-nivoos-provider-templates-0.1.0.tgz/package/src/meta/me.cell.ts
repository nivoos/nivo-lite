import { z } from "zod"
import type { JsonObject, Operation, OperationReach } from "@starci/nivoos-sdk"
import { member } from "../shared/json.ts"
import { META_AUTH_CODES, META_ERROR_FIELD, META_TRANSIENT } from "./wire.ts"

export const MeInput = z.strictObject({})
export const MeOutput = z.strictObject({ pageId: z.string(), name: z.string(), igUserId: z.string().optional() })

type Refusal = "auth_failed"

/** `meta.me`: reads the Page the token belongs to, with the Instagram account linked to it (`instagram_business_account`). The connect test of the provider. */
export class MetaMe implements Operation<typeof MeInput, typeof MeOutput, JsonObject, Refusal> {
    readonly key = "meta.me"
    readonly version = 1
    readonly title = { vi: "Kiểm tra Trang Facebook", en: "Check the Facebook Page" }
    readonly input = MeInput
    readonly output = MeOutput
    readonly semantics = { mutates: false }
    readonly provider = "meta"
    readonly http = true
    readonly needs = ["pageToken"] as const
    readonly refusals = ["auth_failed"] as const
    readonly wire = { errorField: META_ERROR_FIELD, errorCodes: META_AUTH_CODES, transientCodes: META_TRANSIENT } as const

    run(_input: z.infer<typeof MeInput>, reach: OperationReach<JsonObject, Refusal>): z.infer<typeof MeOutput> {
        const account = reach.account() as { readonly pageId: string }
        const answer = reach.http({ method: "GET", path: `/${account.pageId}`, query: { fields: "id,name,instagram_business_account" } })
        const pageId = member(answer.json, "id")
        const name = member(answer.json, "name")
        if (typeof pageId !== "string" || typeof name !== "string") return reach.byStatus()
        const ig = member(member(answer.json, "instagram_business_account"), "id")
        return { pageId, name, ...(typeof ig === "string" ? { igUserId: ig } : {}) }
    }
}
