# provider-templates

The providers a workspace connects an account to, authored with the nivoos SDK. One folder per provider under `src/<key>/`; `src/provider-templates.package.ts`
lists them. `npm run build` writes `seed/provider-templates@<version>.json`; `npm run check` fails when the committed seed differs from a fresh build.

A provider folder holds `<key>.provider.cell.ts`, one `*.cell.ts` per operation and trigger, `logo.svg` (or `.png`, at most 64 KB), a `README.md` that cites
every vendor fact to the vendor's current public docs page, and the recorded fixtures under `be/src/tests/fixtures/e2e/providers/<key>/`. To start a new
one: `nivoos provider add <key>` (or `--from <existing provider key>` to copy one).

| Provider key | Auth way | Webhook | Docs cited |
| --- | --- | --- | --- |
| `google` | OAuth 2.0 (Sheets) | none | developers.google.com/identity/protocols/oauth2/web-server |
| `google-drive` | OAuth 2.0 (Drive) | none | developers.google.com/identity/protocols/oauth2/web-server |
| `mail` | IMAP/SMTP credentials | none (polled) | rfc-editor.org/rfc/rfc8314, rfc5322 |
| `payos` | API key + checksum key | copy | payos.vn/docs/api |
| `sepay` | API token + HMAC webhook secret | copy | developer.sepay.vn/en/sepay-webhooks |
| `telegram` | bot token in path | set via operation | core.telegram.org/bots/api |
| `zalo` | OA access token | see its README | developers.zalo.me |
