# @starci/nivoos-cli (the author CLI)

`nivoos` (the bin of `@starci/nivoos-cli`) builds a package written with [`@starci/nivoos-sdk`](../nivoos-sdk/README.md) into its seed document, checks that the committed seed is current, seals the package's
credentials (sealed with SOPS + age, in the package) and deploys the package to a nivoos instance with your API key.

```
npm i -D @starci/nivoos-cli @starci/nivoos-sdk zod typescript
npx nivoos package build src/<key>.package.ts --out seed
```

Node 22.18 or newer (the package entry is a TypeScript file Node runs by stripping types). `nivoos --help` lists every command and the environment variables the CLI reads.

## A business repository

A business (a shop, a web-hosting company, a marketing site) is its own repository. nivoos itself holds no business logic: the engine, the SDK, this CLI, the
provider templates and the console are installed from npm, never copied or linked from the nivoos repository. The worked example of the shape below is `packages/flower-shop` of the
nivoos repository.

| What | Holds |
| --- | --- |
| `package.json` | the scripts, the pinned dependencies and the `nivoos` block that maps an environment to an instance |
| `tsconfig.json` | type-checks the sources; the build refuses a package that does not type-check |
| `.gitignore` | `node_modules` and `*.secrets.env` (`nivoos package secrets init` adds the second; a plaintext secrets file is refused anyway) |
| `.sops.yaml` | committed: the age **recipient**, the public half of the founder's key. It is the check value that tells a typed key is the right one |
| `secrets/<env>.sops.yaml` | committed: the credentials of `dev` and `prod`, one SOPS file each, every value sealed (AES-256-GCM), the data key wrapped to the recipient, a file MAC |
| `secrets.env.template` | generated, committed: the name of every secret, never a value (the account classes declare names only) |
| `seed/<key>@<version>.json` | generated, committed: the ONE seed document, the reviewed artifact |
| `src/<package key file>` | `package-key`, a file that writes the package key once |
| `src/<key>.package.ts` | the entry: the default export `{ package, cells, workspaces, agents?, workflows?, brainPacks? } satisfies Package` |
| `src/<key>.workspace.ts` | the Workspace class: its agents, object types and brain documents |
| `src/agents/<agent>/` | the agent class, its account classes, its workflows, cells and steps |
| `src/providers/<key>/` | a provider only this business uses (a catalogue provider comes from `@starci/nivoos-provider-templates`) |
| `src/brain/<document>.md` | a brain document the workspace class lists |

Package manifest (replace `<key>`; pin exact versions):

```json
{
  "name": "<business>",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "scripts": {
    "build": "nivoos package build src/<key>.package.ts --out seed",
    "check": "nivoos package check src/<key>.package.ts --out seed",
    "typecheck": "tsc --noEmit -p tsconfig.json"
  },
  "dependencies": {
    "@starci/nivoos-sdk": "0.1.0",
    "@starci/nivoos-provider-templates": "0.1.0",
    "zod": "4.6.7"
  },
  "devDependencies": {
    "@types/node": "22.20.4",
    "@starci/nivoos-cli": "0.1.0",
    "typescript": "5.9.3"
  },
  "nivoos": {
    "instances": {
      "dev": "http://127.0.0.1:3501",
      "prod": "https://<the production api of the instance>"
    }
  }
}
```

- `@starci/nivoos-cli` and `@starci/nivoos-sdk` move together: the seed document is `nivoos/seed@1` and a change of that format is a major of both. Raise both in one commit and rebuild the seed;
  the check script then proves the committed seed is the one the new SDK writes. The seed is a function of the sources, the SDK and the CLI, so a seed built from an installed `@starci/nivoos-cli`
  equals the one built inside the nivoos repository.
- `"type": "module"` keeps Node from reparsing the sources and printing a warning on every run. A decorator (`@NivoObjectType`) is compiled by the CLI itself.
- `@starci/nivoos-provider-templates` is for a business that uses a provider the catalogue holds (Telegram, Zalo, SePay, PayOS, Google, mail). A provider class or an event schema is imported from
  its compiled file, `@starci/nivoos-provider-templates/<provider>/<file>` (the path under its `src` folder, without the extension): Node cannot strip types from a TypeScript file under
  `node_modules`. The providers are deployed once per instance by the platform; the business package only names them.

`tsconfig.json` (stand-alone; a repository on the StarCi harness extends the `package-cjs` file of `@starci/tsconfig` instead):

```json
{
  "compilerOptions": {
    "target": "ES2023",
    "lib": ["ES2023"],
    "types": ["node"],
    "module": "nodenext",
    "moduleResolution": "nodenext",
    "strict": true,
    "noEmit": true,
    "allowImportingTsExtensions": true,
    "isolatedModules": true,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "resolveJsonModule": true
  },
  "include": ["src/**/*.ts"],
  "exclude": ["node_modules", "seed"]
}
```

Start a package from skeletons: `nivoos workspace add <key>`, `nivoos agent add <key>`, `nivoos workflow add <key> --agent <agent key>`, `nivoos provider add <key> [--from <provider template key>]`
(typed files that build as written; each prints the import and list line you add to the entry).

## Build, check, secrets

| Command | Does |
| --- | --- |
| `nivoos package build <entry> --out seed` | type-checks, compiles each cell's entry methods, writes the seed and refreshes `secrets.env.template` |
| `nivoos package check <entry> --out seed` | exit 1 when the committed seed or template differs from a fresh build (run it in CI and before every push) |
| `nivoos package secrets init <entry>` | writes the template and ignores `*.secrets.env` in git |
| `nivoos package boundary [--repo <dir>]... [--list <file>] [--package <dir>] [--verbose] [--strict]` | the package boundary check, below |

## The package boundary

A business package holds business logic only; retry, time, ids, transport, counting, approval and refusals belong to the engine. `nivoos package boundary` reads every
`packages/<name>/src` (a folder with a `src/*.package.ts`) of the repository you stand in, or of each `--repo <dir>` (repeat it; `--list <file>` is a JSON array of
repository paths), and prints per package `rule  file:line  message`, where the message names the engine capability to use instead, then the counts. Exit 1 on any
error; `--strict` also fails on info findings; `--verbose` lists the info findings. A rule is an error once its engine capability is on dev and an info finding until
then; the table is `CAPABILITIES` in `packages/nivoos-cli/src/boundary/rules.ts`.

```
npx nivoos package boundary --repo <first-repo> --repo <second-repo>
```

Rules: `no-try-catch`, `no-clock` (`Date.now()`, `new Date()`), `no-timers`, `no-direct-http` (use a provider operation), `no-hand-retry`, `no-hashed-id`, `no-zone-offset`,
`no-query-to-count`, `no-throw-error`, `no-refusal-data`, `no-swallow-value-taken`, `no-intent-key-fallback`, `no-input-role-check`, `no-hard-wait`, `no-console`, `no-as-never`.

In a business repository the same engine runs as an hfs project check, so `starci app check --gate hfs` is the one local command. `ext/manifest.json` declares
`{ "id": "package-boundary", "run": "ext/checks/package-boundary.mjs" }` and the file is a few lines:

```js
import { createRequire } from "node:module"
import { fileURLToPath } from "node:url"
const { checkPackages, discoverPackages, formatReport } = createRequire(import.meta.url)("@starci/nivoos-cli")
const root = fileURLToPath(new URL("../..", import.meta.url))
// package-specific parameters by package folder: allow (rule id -> globs where it does not apply), exclude, disable,
// ratchet (rule id -> errors the package still has: up to that many pass as known, one more fails, fewer asks to lower it)
const PARAMETERS = {}
const packages = discoverPackages(root).map((pack) => ({ ...pack, ...(PARAMETERS[pack.name] ?? {}) }))
const report = checkPackages({ root, packages })
console.log(formatReport(report))
process.exit(report.errors > 0 ? 1 : 0)
```

## Secrets and accounts

Accounts are declared in code, secrets never. An agent lists account classes, one file each:

```ts
export class ZaloMain implements ProviderAccount<typeof ZaloProvider> {
    readonly key = "zalo-main"                       // the account's name; its id derives from it
    readonly provider = ZaloProvider
    readonly title = { vi: "Zalo OA", en: "Zalo OA" }
    readonly fields = {}                             // public account fields: each env("NAME"), read from the environment at deploy
    readonly secrets = { oaSecretKey: secret("ZALO_MAIN_OA_SECRET_KEY"), accessToken: secret("ZALO_MAIN_ACCESS_TOKEN") }   // sealed, listed in the template, never in code
}
```

The template lists every secret name (one comment each, no value). The values live **in the package, encrypted**, with [SOPS](https://github.com/getsops/sops) and [age](https://age-encryption.org).
The founder owns the key; **the key is never stored anywhere** (not on disk, not in an environment variable, not in a flag). The package holds only its public half.

### Folder layout

```
<business>/
  .sops.yaml                  # creation_rules with the age recipient (committed): the check value of the key
  <env>.sops.yaml             # in the secrets folder, one for dev and one for prod: NAME: ENC[AES256_GCM,data:...,iv:...,tag:...,type:str] ... sops: {age, lastmodified, mac, version}
  secrets.env.template        # names only
```

The files are the real SOPS format: the `sops` binary reads what this CLI writes and the CLI reads what `sops` writes (`sops -d` reads the key from its own age key variable; see the sops docs).
The age wrapping is the maintained `age-encryption` library and each value is sealed with node:crypto AES-256-GCM exactly as SOPS does; there is no crypto primitive of ours and no `sops` binary dependency
(`npx nivoos` works on a machine without it; the round-trip spec runs against the binary where it is installed).

### The key

| Command | Does |
| --- | --- |
| `nivoos key init` | a random X25519 identity: the recipient goes into `.sops.yaml`; the secret key is **shown once** on screen and never written to disk. Put it in your password manager |
| `nivoos secrets set <KEY> --env dev|prod` | hidden key prompt, hidden value prompt; seals the value into `secrets/<env>.sops.yaml` |
| `nivoos secrets edit --env dev|prod [<entry.ts>]` | hidden key prompt, then a hidden value prompt for each secret (every name already in the file, and with an entry every name the package declares); empty keeps the value |
| `nivoos key change` | hidden old key and new key (or empty: generate one, shown once): opens every secrets file in memory, re-seals each under a **new data key** for the new recipient, writes all files and `.sops.yaml` all or nothing |
| `nivoos key reset` | the key is lost, no old key needed: type the package name to confirm; deletes every secrets file, runs `key init`, lists the credential names to enter again |

Every command that needs the key **verifies it first**: it derives the recipient from the typed key and compares it with `.sops.yaml`. A malformed key stops with SOPS_KEY_INVALID; a valid key that is not the package's stops with
SOPS_KEY_NOT_RECIPIENT. Nothing is decrypted before that check. A secrets file whose value or name list was edited by hand fails the file MAC (SOPS_MAC_MISMATCH).

**After `key change` or `key reset`: revoke and reissue the credentials at the providers.** Git history keeps the old ciphertext, and anyone who ever held the old key can still open it. Changing the key protects the future, not the past.

### Deploy

```
npx nivoos package deploy src/<key>.package.ts --env dev                   # asks for the key, hidden
printf '%s' "$KEY" | npx nivoos package deploy ... --env prod --sops-key-stdin --yes   # a script: the first line of stdin
```

The deploy reads `secrets/<env>.sops.yaml`, decrypts in memory only, seals every value to the instance's public key (`nivoos-seal@1`, only envelopes are sent; an instance refuses a clear value) and zeroes its buffers.
The key is never accepted as a flag value or an environment variable. The CLI refuses, before any request: a stale template, a missing or unknown name, a key that is not the package's, and **any plaintext
a secrets.env file or a file named like "*.secrets.env" inside the package** (`package check` refuses it too, and reports a secrets file sealed to another recipient than `.sops.yaml`).
`--secrets <file>` remains only for the harness and CI: a throwaway dotenv file (`# env: dev|prod` line) **outside** the package folder, never tracked by git.

## Apply the seed to a workspace: dev stack and production

The built seed is the reviewed artifact; the instance applies the document `nivoos package deploy` sends (rebuilt from the same sources; idempotent by publisher, key, version and hash,
so the same deploy twice is `unchanged`). One door, both environments.

1. **An API key, once per environment.** A signed-in owner issues one in the console; the instance's master key is for the platform's own packages. Store it (read from stdin, never argv):

   ```
   npx nivoos auth set --env dev < key-file
   npx nivoos auth status --env dev
   ```

   `auth status` prints the instance URL, the first 10 characters of the key and your publisher id. A CI job passes the key with `--api-key` or the API-key environment variable
   (`nivoos --help` names it). The stored key lives in your user config folder, never in the repository.
2. **Dev stack.** The instance is the dev stack of nivoos (`http://127.0.0.1:3501`, or the tunnel host its owner gives you). The providers the business names are already deployed there by the platform.

   ```
   npx nivoos package deploy src/<key>.package.ts --env dev
   ```

   The package's Workspace class makes its workspace under a derived id (you become its owner) and installs its agents. The receipt lists workspaces and agents created or kept, cells created,
   unchanged or refused (with a code), accounts by name and the brain jobs; the exit code is 1 on any refusal. An account that needs a vendor login (OAuth, a bot) is connected in the console afterwards.
3. **Production.** The same command with `--env prod`, an https URL in `nivoos.instances.prod`, the prod key and the prod secrets file (the one under secrets named prod.sops.yaml). A prod deploy states the instance, the package and what it seeds
   and waits for a typed yes; a non-interactive run needs `--yes`. Deploy only a commit whose check is green.
4. **A standalone agent or workflow** (an agent into an existing workspace, a workflow into an existing agent): `nivoos list --env dev` prints every workspace and agent your key has a seat in, with
   ids, to copy into `parent = { workspace: "<uuid>" }`.

`nivoos brain status --env dev` shows how far the brain documents of your workspaces are indexed.

## What a business repository never does

No engine code, no `@nivoos/*` source copied in, no link to a checkout of nivoos, no secret value in git, no business rule in nivoos. A rule a customer changes is a node setting with a default.

## Releasing these packages (maintainers of nivoos)

`@starci/nivoos-sdk`, `@starci/nivoos-cli` and `@starci/nivoos-provider-templates` are published from the nivoos repository by the harness's release verb (`starci release publish`, a dry run that prints the plan; `--execute`
publishes with the owner's yes): raise `version` in a package's manifest, and the exact pins of its dependents, in the commit that changes it. A version already on npm is skipped, a dependency goes before
its dependent (sdk, provider-templates, cli).
