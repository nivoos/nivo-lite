# @starci/nivoos-cli (the author CLI)

`nivoos` (the bin of `@starci/nivoos-cli`) builds a package written with [`@starci/nivoos-sdk`](../nivoos-sdk/README.md) into its seed document, checks that the committed seed is current, seals the package's
secrets on your machine and deploys the package to a nivoos instance with your API key.

```
npm i -D @starci/nivoos-cli @starci/nivoos-sdk zod typescript
npx nivoos package build src/<key>.package.ts --out seed
```

Node 22.18 or newer (the package entry is a TypeScript file Node runs by stripping types). `nivoos --help` lists every command and the environment variables the CLI reads.

## A business repository

A business (a shop, a web-hosting company, a marketing site) is its own repository. nivoos itself holds no business logic: the engine, the SDK, this CLI, the
provider templates and the console are installed from npm, never copied or linked from the nivoos repository. The worked example of the shape below is `packages/flower-shop` of the
nivoos repository.

| What | Holds |
| --- | --- |
| `package.json` | the scripts, the pinned dependencies and the `nivoos` block that maps an environment to an instance |
| `tsconfig.json` | type-checks the sources; the build refuses a package that does not type-check |
| `.gitignore` | `node_modules` and `*.secrets.env` (`nivoos package secrets init` adds the second) |
| `secrets.env.template` | generated, committed: the name of every secret, never a value |
| `seed/<key>@<version>.json` | generated, committed: the ONE seed document, the reviewed artifact |
| `src/<package key file>` | `package-key`, a file that writes the package key once |
| `src/<key>.package.ts` | the entry: the default export `{ package, cells, workspaces, agents?, workflows?, brainPacks? } satisfies Package` |
| `src/<key>.workspace.ts` | the Workspace class: its agents, object types and brain documents |
| `src/agents/<agent>/` | the agent class, its account classes, its workflows, cells and steps |
| `src/providers/<key>/` | a provider only this business uses (a catalogue provider comes from `@starci/nivoos-provider-templates`) |
| `src/brain/<document>.md` | a brain document the workspace class lists |

Package manifest (replace `<key>`; pin exact versions):

```json
{
  "name": "<business>",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "scripts": {
    "build": "nivoos package build src/<key>.package.ts --out seed",
    "check": "nivoos package check src/<key>.package.ts --out seed",
    "typecheck": "tsc --noEmit -p tsconfig.json"
  },
  "dependencies": {
    "@starci/nivoos-sdk": "0.1.0",
    "@starci/nivoos-provider-templates": "0.1.0",
    "zod": "4.6.7"
  },
  "devDependencies": {
    "@types/node": "22.20.4",
    "@starci/nivoos-cli": "0.1.0",
    "typescript": "5.9.3"
  },
  "nivoos": {
    "instances": {
      "dev": "http://127.0.0.1:3501",
      "prod": "https://<the production api of the instance>"
    }
  }
}
```

- `@starci/nivoos-cli` and `@starci/nivoos-sdk` move together: the seed document is `nivoos/seed@1` and a change of that format is a major of both. Raise both in one commit and rebuild the seed;
  the check script then proves the committed seed is the one the new SDK writes. The seed is a function of the sources, the SDK and the CLI, so a seed built from an installed `@starci/nivoos-cli`
  equals the one built inside the nivoos repository.
- `"type": "module"` keeps Node from reparsing the sources and printing a warning on every run. A decorator (`@NivoObjectType`) is compiled by the CLI itself.
- `@starci/nivoos-provider-templates` is for a business that uses a provider the catalogue holds (Telegram, Zalo, SePay, PayOS, Google, mail). A provider class or an event schema is imported from
  its compiled file, `@starci/nivoos-provider-templates/<provider>/<file>` (the path under its `src` folder, without the extension): Node cannot strip types from a TypeScript file under
  `node_modules`. The providers are deployed once per instance by the platform; the business package only names them.

`tsconfig.json` (stand-alone; a repository on the StarCi harness extends the `package-cjs` file of `@starci/tsconfig` instead):

```json
{
  "compilerOptions": {
    "target": "ES2023",
    "lib": ["ES2023"],
    "types": ["node"],
    "module": "nodenext",
    "moduleResolution": "nodenext",
    "strict": true,
    "noEmit": true,
    "allowImportingTsExtensions": true,
    "isolatedModules": true,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "resolveJsonModule": true
  },
  "include": ["src/**/*.ts"],
  "exclude": ["node_modules", "seed"]
}
```

Start a package from skeletons: `nivoos workspace add <key>`, `nivoos agent add <key>`, `nivoos workflow add <key> --agent <agent key>`, `nivoos provider add <key> [--from <provider template key>]`
(typed files that build as written; each prints the import and list line you add to the entry).

## Build, check, secrets

| Command | Does |
| --- | --- |
| `nivoos package build <entry> --out seed` | type-checks, compiles each cell's entry methods, writes the seed and refreshes `secrets.env.template` |
| `nivoos package check <entry> --out seed` | exit 1 when the committed seed or template differs from a fresh build (run it in CI and before every push) |
| `nivoos package secrets init <entry>` | writes the template and ignores `*.secrets.env` in git |

## Secrets and accounts

Accounts are declared in code, secrets never. An agent lists account classes, one file each:

```ts
export class ZaloMain implements ProviderAccount<typeof ZaloProvider> {
    readonly key = "zalo-main"                       // the account's name; its id derives from it
    readonly provider = ZaloProvider
    readonly title = { vi: "Zalo OA", en: "Zalo OA" }
    readonly fields = {}                             // public account fields: each env("NAME"), read from the environment at deploy
    readonly secrets = { oaSecretKey: secret("ZALO_MAIN_OA_SECRET_KEY"), accessToken: secret("ZALO_MAIN_ACCESS_TOKEN") }   // sealed, listed in the template, never in code
}
```

The template lists every secret name (one comment each, no value). To deploy, copy it to a git-ignored `<name>.dev.secrets.env` or `<name>.prod.secrets.env`, set the `# env: dev` or
`# env: prod` line, fill the values. The CLI refuses, before any request: a stale template, a secrets file git tracks, an env line that contradicts `--env`, names that are missing or unknown.
Values are sealed on your machine (`nivoos-seal@1`, the instance's public key) and only envelopes are sent; an instance refuses a clear value. Where the values live is the business
repository's decision (its own secret store): a deploy script reads them into the file and deletes it.

## Apply the seed to a workspace: dev stack and production

The built seed is the reviewed artifact; the instance applies the document `nivoos package deploy` sends (rebuilt from the same sources; idempotent by publisher, key, version and hash,
so the same deploy twice is `unchanged`). One door, both environments.

1. **An API key, once per environment.** A signed-in owner issues one in the console; the instance's master key is for the platform's own packages. Store it (read from stdin, never argv):

   ```
   npx nivoos auth set --env dev < key-file
   npx nivoos auth status --env dev
   ```

   `auth status` prints the instance URL, the first 10 characters of the key and your publisher id. A CI job passes the key with `--api-key` or the API-key environment variable
   (`nivoos --help` names it). The stored key lives in your user config folder, never in the repository.
2. **Dev stack.** The instance is the dev stack of nivoos (`http://127.0.0.1:3501`, or the tunnel host its owner gives you). The providers the business names are already deployed there by the platform.

   ```
   npx nivoos package deploy src/<key>.package.ts --env dev --secrets <name>.dev.secrets.env
   ```

   The package's Workspace class makes its workspace under a derived id (you become its owner) and installs its agents. The receipt lists workspaces and agents created or kept, cells created,
   unchanged or refused (with a code), accounts by name and the brain jobs; the exit code is 1 on any refusal. An account that needs a vendor login (OAuth, a bot) is connected in the console afterwards.
3. **Production.** The same command with `--env prod`, an https URL in `nivoos.instances.prod`, the prod key and the prod secrets file. A prod deploy states the instance, the package and what it seeds
   and waits for a typed yes; a non-interactive run needs `--yes`. Deploy only a commit whose check is green.
4. **A standalone agent or workflow** (an agent into an existing workspace, a workflow into an existing agent): `nivoos list --env dev` prints every workspace and agent your key has a seat in, with
   ids, to copy into `parent = { workspace: "<uuid>" }`.

`nivoos brain status --env dev` shows how far the brain documents of your workspaces are indexed.

## What a business repository never does

No engine code, no `@nivoos/*` source copied in, no link to a checkout of nivoos, no secret value in git, no business rule in nivoos. A rule a customer changes is a node setting with a default.

## Releasing these packages (maintainers of nivoos)

`@starci/nivoos-sdk`, `@starci/nivoos-cli` and `@starci/nivoos-provider-templates` are published from the nivoos repository by the harness's release verb (`starci release publish`, a dry run that prints the plan; `--execute`
publishes with the owner's yes): raise `version` in a package's manifest, and the exact pins of its dependents, in the commit that changes it. A version already on npm is skipped, a dependency goes before
its dependent (sdk, provider-templates, cli).
