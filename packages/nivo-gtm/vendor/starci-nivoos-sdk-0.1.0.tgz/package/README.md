# @starci/nivoos-sdk

The author SDK of nivoos. A business writes its agents, workflows, cells, providers, object types and brain as typed classes (one class per cell, Zod at every
boundary, a `run` that writes the happy path), and `nivoos package build` turns the package into ONE seed document (`nivoos/seed@1`) that an instance applies.

This package is the library: interfaces, the package and workflow types, the compiler and `buildSeed`. The command is the CLI, `nivoos` (`npm i -D @starci/nivoos-cli`).

```ts
import { NodeRun, type Node, type NodeReach } from "@starci/nivoos-sdk"
```

| Subpath | Holds | Used by |
| --- | --- | --- |
| `@starci/nivoos-sdk` | the interfaces (`Node`, `Operation`, `Capability`, `Trigger`, `Provider`), `Workflow`, `Agent`, `Workspace`, `Package`, `buildSeed`, `idOf` | the author's code, the CLI |
| `@starci/nivoos-sdk/seal` | `nivoos-seal@1` (libsodium sealed box) | the CLI (secrets sealed on the author's machine), the console, the engine |
| `@starci/nivoos-sdk/workbench` | the bridge a workbench app imports | an agent's workbench app (Vite + React) |
| `@starci/nivoos-sdk/workbench/protocol` | the postMessage protocol | the console |

Peer dependency: `zod` (4.x, the one your package imports). `react`, `react-dom` and `@heroui/react` are optional peers of a workbench app only.

How to start a business repository, build, check, and apply the seed to a workspace: the `@starci/nivoos-cli` package README (`packages/nivoos-cli/README.md`).

The version follows the seed format: a change of `nivoos/seed@1` is a major.
